package com.viettel.pushnotify;

import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.viettel.synchronize.common.Config;
import com.viettel.synchronize.common.Constant;
import com.viettel.synchronize.util.DataUtils;
import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import com.viettel.synchronize.util.HibernateUtil;
import com.viettel.synchronize.util.MongodbConnection;
import static java.nio.charset.StandardCharsets.ISO_8859_1;
import static java.nio.charset.StandardCharsets.UTF_8;
import java.util.ArrayList;
import java.util.List;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author liemnt10
 * @since 03/2018
 */
public class PushNotifyScheduler implements Job {

    private static final Logger LOGGER = Logger.getLogger(PushNotifyScheduler.class);

    @Override
    public void execute(JobExecutionContext jec) throws JobExecutionException {
        LOGGER.info("Proccesing read Push Notify ... ");

        System.out.println("Chay vao PushNotify .....");
//        Calendar c = Calendar.getInstance();
//        c.add(Calendar.DATE, -1);
//        Date date = c.getTime();
        int orgId;
        List<String> lstOrgId = DataUtils.splitId(Config.orgIds);

        byte[] ptext = Config.contentNotify.getBytes(ISO_8859_1);
        String strContent = new String(ptext, UTF_8);
        
        for (String strId : lstOrgId) { //Lay ra cai ID Org
            orgId = Integer.parseInt(strId);
            pushNotifytoUser(orgId, Config.titleNotify, strContent, Config.dataNotify);
        }

        //Voi truong hop truyen vao Mang EmpCode
        if (Config.empCodes != null && !Config.empCodes.isEmpty()) {
            List<String> lstEmpCodes = DataUtils.splitId(Config.empCodes);
            for (String empCode : lstEmpCodes) {
                pushNotifytoUser(empCode, Config.titleNotify, strContent, Config.dataNotify);
            }
        }
    }

    private void pushNotifytoUser(int orgId, String title, String content, String data) {

        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            //Lay cac User co OrgId truyen vao
            SQLQuery query = session.createSQLQuery(
                    " SELECT u.id, u.employeeCode, u.email  "
                    + " FROM   dh_user u "
                    + "        Inner join dh_vhr_employee e on u.employeeId = e.employeeId "
                    + " WHERE u.email IS NOT NULL and LENGTH(u.email) > 1 "
                    //+ "       AND u.employeeCode = '204965'  "  //-> de test toi 1 nguoi nao do
                    + "       AND e.organizationId = :orgId ");
            query.setParameter("orgId", orgId);
            List list = new ArrayList();
            list = query.list();
            getUsertoPush(list, title, content, data);

        } catch (Exception e) {
            LOGGER.info("");
            System.out.println("" + e);
        }
        LOGGER.info("Finish processing execute Push Notify to User by Org.");
        System.out.println("Finish processing execute Push Notify to User by Org.");

    }

    private void pushNotifytoUser(String empCode, String title, String content, String data) {

        try {
            JSONObject userInfo = getListDeviceByEmployeeCode(empCode);

            if (userInfo.containsKey("listDevice")) {
                org.json.simple.JSONArray tokens = (org.json.simple.JSONArray) userInfo.get("listDevice");
                if (tokens != null && tokens.size() > 0) {
                    for (int j = 0; j < tokens.size(); j++) {
                        JSONObject deviceInfo = (JSONObject) tokens.get(j);
                        Long type = (Long) deviceInfo.get("type");
                        String deviceToken = (String) deviceInfo.get("token");
                        if (type == 1) {// android
                            requestSOAPRequest(Constant.SERVER_KEY_PUSH, deviceToken, Constant.TYPE_ANDROID, title, content, data);
                        } else if (type == 2) { // ios
                            requestSOAPRequest(Constant.SERVER_KEY_PUSH, deviceToken, Constant.TYPE_IOS, title, content, data);
                        }
                    }
                }
            }

        } catch (Exception e) {
            LOGGER.info("");
            System.out.println("" + e);
        }
        LOGGER.info("Finish processing execute Push Notify Direct to User.");
        System.out.println("Finish processing execute Push Notify Direct to User.");

    }

    public void getUsertoPush(List list, String title, String content, String data) throws Exception {

        int uId;

//        Map<String, Object[]> dataAndroid = new TreeMap<String, Object[]>();
//        Map<String, Object[]> dataIos = new TreeMap<String, Object[]>();
//        boolean isUseAndroid = false;
//        boolean isUseIos = false;
        for (int i = 0; i < list.size(); i++) {
            Object[] obj = (Object[]) list.get(i);
            uId = (Integer) obj[0];
//            String employeeCode = (String) obj[1];
//            String email = (String) obj[2];
            JSONObject userInfo = getListDeviceByUserId(uId);

            if (userInfo.containsKey("listDevice")) {
                org.json.simple.JSONArray tokens = (org.json.simple.JSONArray) userInfo.get("listDevice");
                if (tokens != null && tokens.size() > 0) {
                    for (int j = 0; j < tokens.size(); j++) {
                        JSONObject deviceInfo = (JSONObject) tokens.get(j);
                        Long type = (Long) deviceInfo.get("type");
                        String deviceToken = (String) deviceInfo.get("token");
                        if (type == 1) {// android
                            requestSOAPRequest(Constant.SERVER_KEY_PUSH, deviceToken, Constant.TYPE_ANDROID, title, content, data);
                        } else if (type == 2) { // ios
                            requestSOAPRequest(Constant.SERVER_KEY_PUSH, deviceToken, Constant.TYPE_IOS, title, content, data);
                        }
                    }
                }
            }
        }
    }

    public org.json.simple.JSONObject getListDeviceByUserId(int userId) {

        org.json.simple.JSONObject userInfo = new org.json.simple.JSONObject();

        BasicDBObject matchFields = new BasicDBObject();
        matchFields.put("userId", new BasicDBObject("$eq", userId));
        BasicDBObject match = new BasicDBObject("$match", matchFields);

        BasicDBObject projectFields = new BasicDBObject();
        projectFields.put("_id", 1);
        projectFields.put("userId", 1);
        projectFields.put("listDevice", 1);

        BasicDBObject project = new BasicDBObject("$project", projectFields);

        AggregationOutput output = MongodbConnection.getInstance().getUserBusinessStatConnection().aggregate(match, project);
        JSONParser jsonParser = new JSONParser();
        for (DBObject res : output.results()) {
            try {
                userInfo = (org.json.simple.JSONObject) jsonParser.parse(res.toString());
            } catch (ParseException ex) {

            }
        }
        return userInfo;
    }

    public org.json.simple.JSONObject getListDeviceByEmployeeCode(String employeeCode) {
        org.json.simple.JSONObject userInfo = new org.json.simple.JSONObject();
        BasicDBObject matchFields = new BasicDBObject();

        matchFields.put("employeeCode", new BasicDBObject("$eq", employeeCode));
        BasicDBObject match = new BasicDBObject("$match", matchFields);
        BasicDBObject projectFields = new BasicDBObject();
        projectFields.put("_id", 1);
        projectFields.put("userId", 1);
        projectFields.put("listDevice", 1);

        BasicDBObject project = new BasicDBObject("$project", projectFields);
        AggregationOutput output = MongodbConnection.getInstance().getUserBusinessStatConnection().aggregate(match, project);
        JSONParser jsonParser = new JSONParser();
        for (DBObject res : output.results()) {
            try {
                userInfo = (org.json.simple.JSONObject) jsonParser.parse(res.toString());
            } catch (ParseException ex) {
                System.out.println("Loi" + ex);
            }
        }
        return userInfo;
    }

    public static void requestSOAPRequest(String serverKey, String token, String type, String title, String body, String data) throws SOAPException, Exception {
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();

        // Send SOAP Message to SOAP Server
        String url = "http://10.60.105.242:8888/FCMWebservice";
        SOAPMessage soapMess = createSOAPRequestPush(serverKey, token, type, title, body, data);
        SOAPMessage soapResponse = soapConnection.call(soapMess, url);

        System.out.print("Request SOAP Message:");
        soapResponse.writeTo(System.out);
        soapConnection.close();
    }

    private static SOAPMessage createSOAPRequestPush(String serverKey, String token, String type, String title, String body, String data) throws Exception {
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();

        String serverURI = "http://ws.fcm.push.marvel.com/";
        if (data == null || data.isEmpty()) {
            data = "{}";
        }
        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("ws", serverURI);
        // SOAP Body
        SOAPBody soapBody = envelope.getBody();
        SOAPElement soapBodyElem = soapBody.addChildElement("push", "ws");
        SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("serverKey");
        soapBodyElem1.addTextNode(serverKey);
        SOAPElement soapBodyElem2 = soapBodyElem.addChildElement("appKey");
        soapBodyElem2.addTextNode(token);
        SOAPElement soapBodyElem3 = soapBodyElem.addChildElement("type");
        soapBodyElem3.addTextNode(type);
        SOAPElement soapBodyElem4 = soapBodyElem.addChildElement("icon");
        soapBodyElem4.addTextNode("0");
        SOAPElement soapBodyElem11 = soapBodyElem.addChildElement("sound");
        soapBodyElem11.addTextNode("default");
        SOAPElement soapBodyElem5 = soapBodyElem.addChildElement("title");
        soapBodyElem5.addTextNode(title);
        SOAPElement soapBodyElem6 = soapBodyElem.addChildElement("body");
        soapBodyElem6.addTextNode(body);
        SOAPElement soapBodyElem10 = soapBodyElem.addChildElement("data");
        soapBodyElem10.addTextNode(data);
        SOAPElement soapBodyElem7 = soapBodyElem.addChildElement("username");
        soapBodyElem7.addTextNode("username");
        SOAPElement soapBodyElem8 = soapBodyElem.addChildElement("password");
        soapBodyElem8.addTextNode("password");
        SOAPElement soapBodyElem9 = soapBodyElem.addChildElement("transid");
        soapBodyElem9.addTextNode("2");

        MimeHeaders headers = soapMessage.getMimeHeaders();
        headers.addHeader("SOAPAction", serverURI + "push");

        soapMessage.saveChanges();

        /* Print the request message */
        System.out.print("Request SOAP Message:");
        soapMessage.writeTo(System.out);
        System.out.println();

        return soapMessage;
    }
}
