package com.viettel.pushnotify;

/**
 *
 * @author liemnt10
 * @since 03/2018
 */
public class PushNotifyModel {

    private String contentNotify;

    public String getLoginName() {
        return contentNotify;
    }

    public void setLoginName(String content) {
        this.contentNotify = content;
    }

}
