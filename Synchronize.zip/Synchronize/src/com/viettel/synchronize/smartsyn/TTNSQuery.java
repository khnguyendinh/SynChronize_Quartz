/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.synchronize.smartsyn;

import com.viettel.synchronize.common.Config;
import com.viettel.synchronize.database.hibernate.DhVhrOrganization;
import com.viettel.synchronize.util.HibernateUtil;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONException;
import org.json.JSONObject;
import com.viettel.synchronize.util.HttpUtil;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.json.JSONArray;
import org.json.XML;

/**
 *
 * @author haivh2
 */
public class TTNSQuery {

    private static String baseUrl = Config.urlServiceVhr;
    private static String accessTokenUrl = Config.accessTokenUrl;
    private static String refreshTokenUrl = "oauth/token?grant_type=refresh_token&client_id=" + Config.client_id + "&client_secret=" + Config.client_secret + "&refresh_token=";

//    private static String baseUrl = "http://10.60.5.245:8855/WebService/";
//    private static String baseUrl = "http://10.58.71.138:8765/TTNSWebService/";
//    private static final String baseUrl = "http://118.70.185.166:8571/TTNSWebService/";
    private static volatile String accessToken = "";
    private static volatile String refreshToken = "";
    private static final org.apache.log4j.Logger LOGGER = org.apache.log4j.Logger.getLogger("TTNSQuery");

    private static String httpGet(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            if (conn.getResponseCode() != 200) {
                return "error";
            }
            // Buffer the result into a string
            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }
            rd.close();

            conn.disconnect();
            return sb.toString();
        } catch (Exception e) {
            LOGGER.error(e);
            return null;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    public static void getAccessToken() {
//        LOGGER.info("URL request: " + baseUrl);
        String urlStr = baseUrl + "oauth/token";
        LOGGER.info("URL request: " + urlStr);
        HashMap params = new HashMap();
        params.put("grant_type", "password");
        params.put("client_id", Config.client_id);
        params.put("client_secret", Config.client_secret);
        params.put("username", Config.username);
        params.put("password", Config.password);
        LOGGER.info("request params: " + new JSONObject(params).toString());
        String result = HttpUtil.postRequest(urlStr, params);
        LOGGER.info("Result request: " + result);
        try {
            if (!"error".equals(result)) {
                JSONObject jsonData = new JSONObject(result);
                if (jsonData.length() > 0) {
                    accessToken = jsonData.getString("access_token");
                    refreshToken = jsonData.getString("refresh_token");
                }
            }
        } catch (JSONException ex) {
            LOGGER.info(ex);
        }

    }

    public static void refreshAccessToken() {
        String urlStr = baseUrl + refreshTokenUrl + refreshToken;
        String result = httpGet(urlStr);
        try {
            if (result != "error") {
                JSONObject jsonData = new JSONObject(result);
                if (jsonData.length() > 0) {
                    accessToken = jsonData.getString("access_token");
                    refreshToken = jsonData.getString("refresh_token");
                }
            } else {
                getAccessToken();
            }
        } catch (JSONException ex) {
            LOGGER.info(ex);
        }
    }

    public static String getResultFromVHRParam(String extraUrl, Map<String, String> mapParam) {

        String result = "";
        try {
            if ("".equals(accessToken)) {
                getAccessToken();
            }
            String urlStr = baseUrl + extraUrl;
            HttpURLConnection connect = HttpUtil.sendGetRequest(urlStr, accessToken, mapParam);
//            System.out.println(connect.getResponseCode());
            switch (connect.getResponseCode()) {
                case 200://Ok
                    result = HttpUtil.readRespone();
                    break;
                case 401://Authenticate fail
                    refreshAccessToken();
                    HttpUtil.sendGetRequest(urlStr, accessToken, mapParam);
                    result = HttpUtil.readRespone();
                    break;
                default:
                    break;
            }
        } catch (IOException ex) {
            LOGGER.error("getResultFromVHRParam" + ex);
        }
        HttpUtil.disconnect();
        return result;

    }
    
    public static Object getOrgInfo(int orgId) {
        Session session = null;
            try {
                //Liemtn10 mo session Hibernate de lay du lieu cua Object co ColumName truyen vao
                session = HibernateUtil.getSessionFactory().openSession();
            } catch (HibernateException ex) {
                
            }
        try {
                if (session != null) {
                    //Liemnt10: Query ra de lay
                    String queryStr = String.format("from %s where %s=:dbColumnName", "DhVhrOrganization", "organizationId");
//                    Query query = session.createQuery("from " + objectClassName + " where " + dbColumnName + "=:dbColumnName");
                    Query query = session.createQuery(queryStr);
                    query.setParameter("dbColumnName", orgId);
                    List list = query.list();
                    if (!list.isEmpty()) {
                       Object row = list.get(0);
                        return row;
                    }
                }

            } catch (Exception ex) {
                
                
            }finally {
                if (session != null) {
                    session.close();
                }
               
            }
        return null;
    }

    public static String getResultFromVHRNotParam(String extraUrl) {

        String result = "";
        try {
            if ("".equals(accessToken)) {
                getAccessToken();
            }
            String urlStr = baseUrl + extraUrl;
            HttpURLConnection connect = HttpUtil.sendGetRequest(urlStr, accessToken);
            switch (connect.getResponseCode()) {
                case 200://Ok
                    result = HttpUtil.readRespone();
                    break;
                case 401://Authenticate fail
                    refreshAccessToken();
                    HttpUtil.sendGetRequest(urlStr, accessToken);
                    result = HttpUtil.readRespone();
                    break;
            }
        } catch (IOException ex) {
            LOGGER.error(ex);

        }
        HttpUtil.disconnect();
        return result;

    }
    
    public static JSONObject requestSOAPRequestOrgGhr(String date) throws SOAPException, IOException {
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();
        String url = "http://10.30.132.248:8988/ghr/GHRWebService";
        SOAPMessage soapMess = createSOAPRequestGhr(date);
        SOAPMessage soapResponse = soapConnection.call(soapMess, url);
        soapResponse.writeTo(System.out);
        soapConnection.close();
        SOAPBody element = soapResponse.getSOAPBody(); // Whatever
        DOMSource source = new DOMSource(element);
        StringWriter stringResult = new StringWriter();
        try {
            TransformerFactory.newInstance().newTransformer().transform(source, new StreamResult(stringResult));
        } catch (TransformerConfigurationException ex) {
            //Exceptions.printStackTrace(ex);
        } catch (TransformerException ex) {
            //Exceptions.printStackTrace(ex);
        }
        String message = stringResult.toString(); 
        JSONObject jsonObj = XML.toJSONObject(message);
        JSONObject jsonBody = jsonObj.getJSONObject("S:Body");
        JSONObject response = jsonBody.getJSONObject("ns2:getListOrganizationUpdatedResponse");
        JSONObject jsReturn = response.getJSONObject("return");
        return jsReturn;
    }
    
     private static SOAPMessage createSOAPRequestGhr(String date) throws SOAPException, IOException{
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();
        String serverURI = "http://ghr.viettel.com/";

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("ghr", serverURI);
        SOAPBody soapBody = envelope.getBody();
        SOAPElement soapBodyElem = soapBody.addChildElement("getListOrganizationUpdated", "ghr");
        SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("actor");
        SOAPElement soapBodyElem2 = soapBodyElem1.addChildElement("loginName");
        soapBodyElem2.addTextNode("ghr");
        SOAPElement soapBodyElem3 = soapBodyElem1.addChildElement("passwordEncrypt");
        soapBodyElem3.addTextNode("ghr#123");
        SOAPElement soapBodyElem4 = soapBodyElem.addChildElement("orgParentId");
        soapBodyElem4.addTextNode("1000004");
        SOAPElement soapBodyElem5 = soapBodyElem.addChildElement("sysDate");
        soapBodyElem5.addTextNode("");
        MimeHeaders headers = soapMessage.getMimeHeaders();
        headers.addHeader("SOAPAction", serverURI  + "getListOrganizationUpdated");

        soapMessage.saveChanges();

        /* Print the request message */
        System.out.print("Request SOAP Message:");
        soapMessage.writeTo(System.out);
        System.out.println();

        return soapMessage;
     }
     
     public static JSONObject requestSOAPRequestEmployeeGhr(String date) throws SOAPException, IOException {
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();
        String url = "http://10.30.132.248:8988/ghr/GHRWebService";
        SOAPMessage soapMess = createSOAPRequestGhrEmployee(date);
        SOAPMessage soapResponse = soapConnection.call(soapMess, url);
        //soapResponse.writeTo(System.out);
        soapConnection.close();
        SOAPBody element = soapResponse.getSOAPBody(); // Whatever
        DOMSource source = new DOMSource(element);
        StringWriter stringResult = new StringWriter();
        try {
            TransformerFactory.newInstance().newTransformer().transform(source, new StreamResult(stringResult));
        } catch (TransformerConfigurationException ex) {
            //Exceptions.printStackTrace(ex);
        } catch (TransformerException ex) {
            //Exceptions.printStackTrace(ex);
        }
        String message = stringResult.toString(); 
        JSONObject jsonObj = XML.toJSONObject(message);
        JSONObject jsonBody = jsonObj.getJSONObject("S:Body");
        JSONObject response = jsonBody.getJSONObject("ns2:getListEmployeesResponse");
        JSONObject jsReturn = response.getJSONObject("return");
        return jsReturn;
    }
     
     private static SOAPMessage createSOAPRequestGhrEmployee(String date) throws SOAPException, IOException{
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();
        String serverURI = "http://ghr.viettel.com/";

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("ghr", serverURI);
        SOAPBody soapBody = envelope.getBody();
        SOAPElement soapBodyElem = soapBody.addChildElement("getListEmployees", "ghr");
        SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("actor");
        SOAPElement soapBodyElem2 = soapBodyElem1.addChildElement("loginName");
        soapBodyElem2.addTextNode("ghr");
        SOAPElement soapBodyElem3 = soapBodyElem1.addChildElement("passwordEncrypt");
        soapBodyElem3.addTextNode("ghr#123");
        SOAPElement soapBodyElem4 = soapBodyElem.addChildElement("orgParentId");
        soapBodyElem4.addTextNode("1000004");
        SOAPElement soapBodyElem5 = soapBodyElem.addChildElement("sysDate");
        soapBodyElem5.addTextNode("");
        SOAPElement soapBodyElem6 = soapBodyElem.addChildElement("employeeCode");
        soapBodyElem6.addTextNode("");
        MimeHeaders headers = soapMessage.getMimeHeaders();
        headers.addHeader("SOAPAction", serverURI  + "getListEmployees");

        soapMessage.saveChanges();

        /* Print the request message */
        System.out.print("Request SOAP Message:");
        //soapMessage.writeTo(System.out);
        //System.out.println();

        return soapMessage;
     }
     
     
}
