/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.synchronize.smartsyn;

import com.viettel.synchronize.common.Config;
import com.viettel.synchronize.util.HttpUtil;
//import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
//import org.json.simple.JSONArray;

/**
 *
 * @author haivh2
 */
public class VofficeQuery {
     private static String baseUrl = "http://10.60.108.222:8087/smartoffice/api/v1/voffice";
     private static String accessTokenUrl = baseUrl + "/get_access_token";
     private static String listMeetingUrl = baseUrl + "/list_meeting";
     private static JSONObject tokenJson = new JSONObject();
     private static final org.apache.log4j.Logger LOGGER = org.apache.log4j.Logger.getLogger("VofficeQuery");
     public static void getAccessToken() {
//        LOGGER.info("URL request: " + baseUrl);
        JSONObject jo = new JSONObject();
        String username = "010993";
        String password = "222222a@";
        jo.put("username", username);
        jo.put("password", password);
        String respond = HttpUtil.postRequestByJson(accessTokenUrl, jo);
        JSONObject res = new JSONObject(respond);
        tokenJson = res.getJSONObject("data");
        System.out.println(respond);
    }
     
    public static String getListMeetingVoffice(String dateTime){
        JSONObject jo = new JSONObject(tokenJson.toString());
        jo.put("pageSize",10);
        jo.put("fromDate", dateTime);
        String respond = HttpUtil.postRequestByJson(listMeetingUrl, jo);
        System.out.println(respond);
        return respond;
    }
     
    public static void main(String[] args){
        if(!tokenJson.has("access_token"))
            getAccessToken();
        String respond = getListMeetingVoffice("16/02/2017 14:09:00");
        JSONObject jo = new JSONObject(respond);
        JSONArray data = jo.getJSONArray("data");
        for (int i = 0; i < data.length(); i ++) {
            JSONObject meeting = data.getJSONObject(i);
            Long meetingId = meeting.getLong("meetingId");
            String startTime = meeting.getString("startTime");
            String endTime = meeting.getString("endTime");
            String subject = meeting.getString("subject");
            String content = subject;
            if(meeting.has("sumary"))
                content = meeting.getString("sumary");
            org.joda.time.format.DateTimeFormatter formatter = DateTimeFormat.forPattern("dd/MM/yyyy HH:mm:ss");
            DateTime startDate = formatter.parseDateTime(startTime);
            DateTime endDate = formatter.parseDateTime(endTime);
            Long startTimestamp = startDate.getMillis();
            Long endTimestamp = endDate.getMillis();
        }
    }
}

