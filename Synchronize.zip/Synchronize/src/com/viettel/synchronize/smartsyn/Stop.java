package com.viettel.synchronize.smartsyn;

import com.viettel.synchronize.vhgs.MMProcessManager;
import org.apache.log4j.Logger;
import org.quartz.JobKey;
import org.quartz.SchedulerException;
import org.quartz.TriggerKey;

/**
 *
 * @author liemnt10
 */
public class Stop {

    private final static Logger LOGGER = Logger.getLogger(Stop.class);

    public static void main(String[] args) throws SchedulerException {
        LOGGER.info("Synchronize has been stopped by wrapper !\n");

        //stop all workers - comment lai vi 2 phan nay khong su dung o dau
        //WorkerManager.getInstance().stopAllWorkers();
        //Start.appWorkerExecutor.shutdownNow();
        //delete Job, trigger
        
        /*
        Start.scheduler.unscheduleJob(TriggerKey.triggerKey(Start.JOB_SYNCHRONIZE_NAME, Start.JOB_SYNCHRONIZE_GROUP));
        Start.scheduler.deleteJob(JobKey.jobKey(Start.JOB_SYNCHRONIZE_NAME, Start.JOB_SYNCHRONIZE_GROUP));

        Start.scheduler.unscheduleJob(TriggerKey.triggerKey(Start.JOB_SYNCHRONIZE_SETTING_NAME, Start.JOB_SYNCHRONIZE_SETTING_GROUP));
        Start.scheduler.deleteJob(JobKey.jobKey(Start.JOB_SYNCHRONIZE_SETTING_NAME, Start.JOB_SYNCHRONIZE_SETTING_GROUP));
        
        Start.scheduler.unscheduleJob(TriggerKey.triggerKey(Start.JOB_LOG_KPI_NAME, Start.JOB_LOG_KPI_GROUP));
        Start.scheduler.deleteJob(JobKey.jobKey(Start.JOB_LOG_KPI_NAME, Start.JOB_LOG_KPI_GROUP));
        */
//        Start.scheduler.unscheduleJob(TriggerKey.triggerKey(Start.JOB_PUSH_NOTIFY_NAME, Start.JOB_PUSH_NOTIFY_GROUP));
//        Start.scheduler.deleteJob(JobKey.jobKey(Start.JOB_PUSH_NOTIFY_NAME, Start.JOB_PUSH_NOTIFY_GROUP));
        
        Start.scheduler.shutdown(true);

        MMProcessManager.getInstance().stop();
    }
}
