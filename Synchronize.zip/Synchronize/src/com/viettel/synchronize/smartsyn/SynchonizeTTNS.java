package com.viettel.synchronize.smartsyn;

import com.viettel.synchronize.common.Config;
import com.viettel.synchronize.database.hibernate.DhVhrEmployee;
import com.viettel.synchronize.database.hibernate.DhVhrOrganization;
import com.viettel.synchronize.database.hibernate.DhUser;
import com.viettel.synchronize.util.HibernateUtil;
import com.viettel.vhr.service.EmployeeBean;

import com.viettel.vhr.service.OrganizationBean;
import com.viettel.vhr.service.VhrActor;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import javax.xml.ws.BindingProvider;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import com.viettel.synchronize.util.DataUtils;
import com.viettel.synchronize.util.LocDauTiengVietUtl;
import java.text.ParseException;

/**
 *
 * @author truongbx3, liemnt10
 */
public class SynchonizeTTNS implements Job {

    private static final Logger LOGGER = Logger.getLogger(SynchonizeTTNS.class);

    public void execute(JobExecutionContext context)
            throws JobExecutionException {
        LOGGER.info("Proccesing Syschonize TTNS ... ");
        Session session = HibernateUtil.getSessionFactory().openSession();
//        try {

        /* Liemnt10: Tam thoi dong lai viec lay Organization - 
               //  Dong bo Employee se truyen OrgId = null - de lay tat cac Employee co su thay doi 
            
            Query query = session.createSQLQuery(" Select a.organizationId From dh_vhr_organization a Where a.effectiveEndDate is null And " //Cho effectiveEndDate xem lai
                    + " a.organizationId not IN (\n"
                    + "         select DISTINCT(b.parentId) from dh_vhr_organization b \n"
                    + ")  ");

            List result = query.list();
            List<Long> lstInteger = new ArrayList<>();
            for (int i = 0; i < result.size(); i++) {
                int abc = (Integer) result.get(i);
                lstInteger.add(Long.parseLong(String.valueOf(abc)));
            }
//            session.close();
           
            int i = 0;
            System.out.println(" Tong so " + lstInteger.size());
            for (Long orgId : lstInteger) {
                i++;
                //System.out.println("---------------------------------- Stt: = " + i + " / tren tong Organization: " + lstInteger.size());
                LOGGER.info("---------------------------------- Stt: = " + i + " / tren tong Organization: " + lstInteger.size());
                syncEmployeeVHR(orgId);
            }
            //syncEmployeeVHR();
            LOGGER.info("Da dong bo xong bang Employee ...");
            syncOrganizationVHR();
         */
        // Moi la chi can nhu sau
        //Dong bo Employee - User
        // syncEmployeeVHR(0L);
        //Dong bo Org
        LOGGER.info("Finished syn Employee .................... ");
        LOGGER.info("Start syn Employee ....................... ");
        syncOrganizationVHR();

//        } 
//        catch (Exception e) {
//            //rollback .....
//            LOGGER.info("Error occur: " + e);
//        } finally {
        if (session != null) {
            session.close();
        }
        //StatisticManager.getInstance().getStatisticModel().incNoTransactionMySQL(this.getClass());
//        }
    }

    /**
     * Dong bo thong tin nhan vien - Lay danh sach nhan vien - Cap nhat toi
     * database smart_office
     */
    public static void syncEmployeeVHR(Long orgId) {

        LOGGER.info("Proccesing Employee with Organization ID: " + orgId);
        String vhrAcc = Config.vhrAcc;
        String vhrPass = Config.vhrPass;
        String avatarUrl = Config.avatarUrl;

        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        String synDate = sdfDate.format(date);

        VhrActor vhrActor = new VhrActor();
        vhrActor.setPassword(vhrPass);
        vhrActor.setUserName(vhrAcc);

        Session session1 = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session1.beginTransaction();

        LOGGER.info("Lay danh sach Employee....");
        long startTime = System.currentTimeMillis();

        List<EmployeeBean> employeeBeans = getListEmployees(vhrActor, null, null, "01/01/2014"); // Exam : synDate "20/06/2016"

        LOGGER.info("Tong so nhan vien lay duoc: " + employeeBeans.size());
        LOGGER.info("Thoi gian lay danh sach nhan vien: " + (System.currentTimeMillis() - startTime));
        //convert chuan format date de insert vao CSDL 
        SimpleDateFormat sdfDate2 = new SimpleDateFormat("yyyy-MM-dd");
        // Cap nhat danh sach nhan vien toi db smart office
        int i = 0;
        try {
            for (EmployeeBean employeeBean : employeeBeans) {
                i++;
                DhVhrEmployee dhVhrEmployee = new DhVhrEmployee();
                dhVhrEmployee.setAccountNumber(employeeBean.getAccountNumber());
                dhVhrEmployee.setBank(employeeBean.getBank());
                dhVhrEmployee.setBankBranch(employeeBean.getBankBranch());
                dhVhrEmployee.setCollectCallCode(employeeBean.getCollectCallCode());
                dhVhrEmployee.setCurrentAddress(employeeBean.getCurrentAddress());
                dhVhrEmployee.setProfileImagePath(avatarUrl + employeeBean.getEmployeeId() + ".jpg");
                if (employeeBean.getDateOfBirth() != null) {
                    Date dateOfBirth = sdfDate2.parse(employeeBean.getDateOfBirth());
                    dhVhrEmployee.setDateOfBirth(dateOfBirth);
                }
                dhVhrEmployee.setEmail(employeeBean.getEmail());
                dhVhrEmployee.setEmployeeCode(employeeBean.getEmployeeCode());
                dhVhrEmployee.setEmployeeId(DataUtils.convertLongToInt(employeeBean.getEmployeeId(), 0));
                //Print ra Console - Khi nao test thi mo. Deploy thi Comment lai
                //     System.out.println("employIds : " + employeeBean.getEmployeeId());
                //     System.out.println("address : " + employeeBean.getCurrentAddress());

                //ghi vao Log - Vi 30 phut 1 lan chay, nen thu xem co nhung ai thay doi
                LOGGER.info("employId =  : " + employeeBean.getEmployeeId());
                LOGGER.info("employee Name = : " + employeeBean.getFullName());

                dhVhrEmployee.setFullName(employeeBean.getFullName());
                dhVhrEmployee.setGender(DataUtils.convertLongToInt(employeeBean.getGender(), 0));
                // Chuan hoa mobile number
                if (employeeBean.getMobileNumber() != null) {
                    dhVhrEmployee.setMobileNumber(DataUtils.standardizeMobileNumber(employeeBean.getMobileNumber()));
                    dhVhrEmployee.setMobileNumber2(DataUtils.standardizeMobileNumber2(employeeBean.getMobileNumber()));
                }

                dhVhrEmployee.setPositionId(DataUtils.convertLongToInt(employeeBean.getPositionId(), 0));
                dhVhrEmployee.setPositionName(employeeBean.getPositionName());
                dhVhrEmployee.setSaleCode(employeeBean.getSaleCode());
                dhVhrEmployee.setSoldierLevel(employeeBean.getSoldierLevel());
                dhVhrEmployee.setTelephoneNumber(employeeBean.getTelephoneNumber());
                dhVhrEmployee.setOrganizationId(DataUtils.convertLongToInt(employeeBean.getOrganizationId(), 0));
//                dhVhrEmployee.setStatus(employeeBean.getStatus());
                if (dhVhrEmployee.getEmployeeId() != 0) {
                    dhVhrEmployee.setActive(0);
                }

                session1.saveOrUpdate(dhVhrEmployee);
//              if (i % 50 == 0) {
//                  session.flush();
//                  session.clear();
//              }
                //Dong bo dh_User
                synUser(employeeBean);
            }

            transaction.commit();

            LOGGER.info("--------- Success ------- :" + orgId);
            Thread.sleep(100L);
        } catch (ParseException ex) {
            transaction.rollback();
            LOGGER.error("Insert employee error - at Organization ID:" + orgId);
        } catch (InterruptedException ex) {
            transaction.rollback();
            LOGGER.error("Insert employee error - at Organization ID:" + orgId);
        } finally {
            if (session1 != null) {
                session1.close();
            }
            //StatisticManager.getInstance().getStatisticModel().incNoTransactionMySQL(this.getClass());
            LOGGER.info("-------------------------- Close:" + orgId);
        }
    }

    /**
     * synUser : dong bo dh_User
     *
     * @param employeeBean
     */
    private static void synUser(EmployeeBean employeeBean) {
        LOGGER.info("Synchronize dh_User with employeeCode: " + employeeBean.getEmployeeCode() + "(" + employeeBean.getEmail() + ")");

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        //convert chuan format date de insert vao CSDL 
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");

        try {
            byte defaultValue = 0;
            byte defaultValue1 = 1;
            byte defaultValue2 = 2;

            DhUser dhUser = new DhUser();
//            dhUser.setEmployeeId(employeeBean.getEmployeeId());
            dhUser.setEmployeeCode(employeeBean.getEmployeeCode());
            dhUser.setFullname(employeeBean.getFullName());
            dhUser.setFullnameAscii(LocDauTiengVietUtl.perform(employeeBean.getFullName()));
            dhUser.setEmail(employeeBean.getEmail());
            dhUser.setPhoneNumber(DataUtils.standardizeMobileNumber(employeeBean.getMobileNumber()));
            // Dang thieu may cai nay
//            dhUser.setAvatar(profileImagePath); 
            //dhUser.setAvatarSmall(avatarSmall);
            //dhUser.setAvatar90(avatar90);
            //dhUser.setAvatar150(avatar150);

            //Phan nay chu y. TTNS se co luc de 1 map 1 voi User, do do khong phai If ben duoi
            if (employeeBean.getGender() == 1) {
                dhUser.setSex(2);
            } else {
                dhUser.setSex(1);
            }
            if (employeeBean.getDateOfBirth() != null) {
                Date dateOfBirth = sdfDate.parse(employeeBean.getDateOfBirth());
                dhUser.setBirthday(dateOfBirth);
            }
//            dhUser.setMarrial(0);
            dhUser.setMarrialWith(0);

            String username1; // username = phan dau email
            if (employeeBean.getEmail().contains("@viettel.com.vn")) {
                String[] listEmail = employeeBean.getEmail().split("@");
                username1 = listEmail[0];
            } else {
                username1 = employeeBean.getEmail();
            }
            dhUser.setUsername(username1);
            dhUser.setType(defaultValue);
            dhUser.setEmailActivation(true);
            Date date = new Date();
            dhUser.setRegisterDate(date);
            dhUser.setLastVisitDate(date);
            dhUser.setServer(0);

            dhUser.setPrivacyViewProfile(defaultValue);
            dhUser.setPrivacyViewOnlineStatus(defaultValue);
            dhUser.setPrivacyViewStatusMsg(defaultValue);
            dhUser.setPrivacyViewAvatar(defaultValue);
            //dhUser.setPrivacyViewCommentLike(defaultValue2);
            dhUser.setPrivacyPostProfile(defaultValue);
            dhUser.setPrivacyComment(defaultValue2);
            dhUser.setPrivacyReceiveMessage(defaultValue);
            dhUser.setPrivacyVisitHomePage(defaultValue1);
            dhUser.setPrivacyShowPreview(true);
            dhUser.setPrivacyAllowFindWifi(true);
            //dhUser.setPrivacyAllowFindViaEmail(true);
            //dhUser.setPrivacyAllowFindViaFacebook(true); 
            dhUser.setPluginUrlToPhoto(false);
            dhUser.setPluginPhotoZoom(false);
            dhUser.setBrowser(false);
            //dhUser.setOnXu();
            dhUser.setOnline(defaultValue);
            dhUser.setChatServer(0);
            dhUser.setApplicationState(1);
//            dhUser.setApplicationCurrentStateTime(DataUtils.getSysTimestamp());
            dhUser.setLastDevice(3);
            dhUser.setPlatform(defaultValue);
            //dhUser.setCallHasRingbackTone();
            //dhUser.setPushNotiFriendRequest(); 
            //dhUser.setFacebookUserId();
            //dhUser.setProvince();
            dhUser.setPlatformVersion("");
            dhUser.setAppVersion("");
            dhUser.setScreenSize("");
            dhUser.setDeviceName("");
            dhUser.setAudioCodecs("");
            dhUser.setCountryCode("84"); //Tam thoi fix VN 84
            dhUser.setRegisterIp("10.60.105.4");
//            dhUser.setModified(DataUtils.getSysTimestamp());

            session.saveOrUpdate(dhUser);

            //transaction.commit(); //Commit o day thi dc dong nao la an dong do
        } catch (ParseException ex) {
            transaction.rollback();
            LOGGER.error("Insert User error - at employee ID:" + employeeBean.getEmpTypeId());
        } finally {
            //if (session != null) {
            session.close();
            //}
            //StatisticManager.getInstance().getStatisticModel().incNoTransactionMySQL(this.getClass());
            LOGGER.info("Closed at employee ID :" + employeeBean.getEmpTypeId());
        }
    }

    /**
     * Dong bo thong tin to chuc - Lay danh sach to chuc - cap nhat danh sach to
     * chuc toi db SmartOffice
     */
    private static void syncOrganizationVHR() {
        String vhrAcc = Config.vhrAcc;
        String vhrPass = Config.vhrPass;

        VhrActor vhrActor = new VhrActor();
        vhrActor.setPassword(vhrPass);
        vhrActor.setUserName(vhrAcc);

        long startTime = System.currentTimeMillis();
        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        String synDate = sdfDate.format(date);
        LOGGER.info("Get organization ngay: " + synDate);

        //Lay danh sach to chuc theo ngay hien tai
        List<OrganizationBean> organizations = getListOrganizationUpdated(vhrActor, "01/10/2015", null);

        LOGGER.info("Tong so to chuc lay duoc: " + organizations.size());
        LOGGER.info("Thoi gian lay danh sach to chuc: " + (System.currentTimeMillis() - startTime));

        // Cap nhat danh sach to chuc toi db SmartOffice
        if (organizations.size() > 0) {

            Session session = HibernateUtil.getSessionFactory().openSession();
            Transaction transaction = session.beginTransaction();
            int i = 0;
            try {

                for (OrganizationBean organization : organizations) {
                    i++;
                    System.out.println("Thu tu i: " + i);
                    DhVhrOrganization dhVhrOrganization = new DhVhrOrganization();
                    if (organization.getCode() != null) {
                        dhVhrOrganization.setCode(organization.getCode());
                    }
                    LOGGER.info("EffectiveEndDate(): " + organization.getEffectiveEndDate());
                    if (organization.getEffectiveEndDate() != null) {
                        dhVhrOrganization.setEffectiveEndDate(DataUtils.convertStringToTime(organization.getEffectiveEndDate()));
                    }
                    if (organization.getEffectiveStartDate() != null) {
                        dhVhrOrganization.setEffectiveStartDate(DataUtils.convertStringToTime(organization.getEffectiveStartDate()));
                    }
                    String name = " ";
                    if (organization.getName() != null) {
                        name = organization.getName();
                    }
                    dhVhrOrganization.setName(name);
                    System.out.println("Name Organization: " + name);

                    dhVhrOrganization.setNumOfNonPartyMember(DataUtils.convertLongToInt(organization.getNumOfNonPartyMember(), 0));
                    dhVhrOrganization.setNumOfPartyMember(DataUtils.convertLongToInt(organization.getNumOfPartyMember(), 0));
                    dhVhrOrganization.setOrderNumber(DataUtils.convertLongToInt(organization.getOrderNumber(), 0));
                    dhVhrOrganization.setOrgLevelManage(DataUtils.convertLongToInt(organization.getOrderNumber(), 0));
                    dhVhrOrganization.setOrgType(organization.getOrgType());
                    dhVhrOrganization.setOrganizationId(DataUtils.convertLongToInt(organization.getOrganizationId(), 0));
                    dhVhrOrganization.setParentId(DataUtils.convertLongToInt(organization.getParentId(), 0));
                    dhVhrOrganization.setPath(organization.getPath());
                    session.saveOrUpdate(dhVhrOrganization);
                    if (i % 50 == 0) {
                        session.flush();
                        session.clear();
                    }
                }
                transaction.commit();
            } catch (ParseException | HibernateException ex) {
                LOGGER.error("Insert error: ", ex);
            } finally {
                //if (session != null) {
                session.close();
                //}
                //StatisticManager.getInstance().getStatisticModel().incNoTransactionMySQL(this.getClass());
            }
        }
    }

    /**
     * Get all employees
     *
     * @param actor
     * @param employeeCode
     * @param organizationId
     * @param synTime
     * @return returns java.util.List<com.viettel.vhr.service.EmployeeBean>
     */
    private static java.util.List<com.viettel.vhr.service.EmployeeBean> getListEmployees(com.viettel.vhr.service.VhrActor actor, java.lang.String employeeCode, java.lang.Long organizationId, java.lang.String synTime) {
        List<EmployeeBean> listEmployees = new ArrayList<>();
        try {
            com.viettel.vhr.service.VHRWebService_Service service = new com.viettel.vhr.service.VHRWebService_Service(new URL(Config.vhrUrl));

            com.viettel.vhr.service.VHRWebService port = service.getPort(com.viettel.vhr.service.VHRWebService.class);
            ((BindingProvider) port).getRequestContext().put("javax.xml.ws.client.connectionTimeout", "6000000");
            ((BindingProvider) port).getRequestContext().put("Content-type", "text/xml;charset=utf-8");
            listEmployees = port.getListEmployees(actor, employeeCode, organizationId, synTime);

            //check and remove duplicate
//            try {
            List<EmployeeBean> result = new ArrayList<>();
            Set<Long> set1 = new HashSet<>();

            for (EmployeeBean employee : listEmployees) {
                long employeeId = employee.getEmployeeId();
                if (set1.add(employeeId)) {
                    result.add(employee);
                } else {
                    LOGGER.warn("duplicate employeeId: " + employeeId);
                }
            }
            return result;
//            } 
//            catch (Exception e) {
//                LOGGER.warn("removing duplicate employee has erros: " + e);
//            }

        } catch (MalformedURLException ex) {
            java.util.logging.Logger.getLogger(SynchonizeTTNS.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listEmployees;
    }

    /**
     * Get info of employee
     *
     * @param actor
     * @param employeeCode
     * @param synTime
     * @return returns java.util.List<com.viettel.vhr.service.EmployeeBean>
     */
    private static java.util.List<com.viettel.vhr.service.EmployeeBean> getEmployeeInfo(com.viettel.vhr.service.VhrActor actor, java.lang.String employeeCode, java.lang.String synTime) {
        try {
            com.viettel.vhr.service.VHRWebService_Service service = new com.viettel.vhr.service.VHRWebService_Service(new URL(Config.vhrUrl));
            com.viettel.vhr.service.VHRWebService port = service.getVHRWebServicePort();
            return port.getEmployeeInfo(actor, employeeCode, synTime);
        } catch (MalformedURLException ex) {
            java.util.logging.Logger.getLogger(SynchonizeTTNS.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new ArrayList<>();
    }

    /**
     * Get list Org updated
     *
     * @param actor
     * @param modifyDate
     * @param orgTypeCode
     * @return returns java.util.List<com.viettel.vhr.service.OrganizationBean>
     */
    private static java.util.List<com.viettel.vhr.service.OrganizationBean> getListOrganizationUpdated(com.viettel.vhr.service.VhrActor actor, java.lang.String modifyDate, java.lang.String orgTypeCode) {
        try {
            com.viettel.vhr.service.VHRWebService_Service service = new com.viettel.vhr.service.VHRWebService_Service(new URL("http://192.168.176.216:8888/vhr/VHRWebService?wsdl"));

            com.viettel.vhr.service.VHRWebService port = service.getPort(com.viettel.vhr.service.VHRWebService.class);
            ((BindingProvider) port).getRequestContext().put("javax.xml.ws.client.connectionTimeout", "6000000");
            ((BindingProvider) port).getRequestContext().put("Content-type", "text/xml;charset=utf-8");

            //Set timeout until the response is received
            return port.getListOrganizationUpdated(actor, modifyDate, orgTypeCode);
        } catch (MalformedURLException ex) {
            java.util.logging.Logger.getLogger(SynchonizeTTNS.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new ArrayList<>();
    }

//    public static void main(String[] args) {
//        syncEmployeeVHR(null);
////        syncOrganizationVHR();
//    }
}
