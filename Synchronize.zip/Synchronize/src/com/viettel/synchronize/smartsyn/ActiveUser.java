/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.synchronize.smartsyn;

import com.viettel.synchronize.database.hibernate.DhUser;
import com.viettel.synchronize.util.HibernateUtil;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import com.viettel.synchronize.util.LocDauTiengVietUtl;
import com.viettel.synchronize.util.UserRelationship;

/**
 *
 * @author truongbx3
 */
public class ActiveUser implements Job {

    private static final Logger LOGGER = Logger.getLogger(ActiveUser.class);

    @Override
    public void execute(JobExecutionContext jec) throws JobExecutionException {

        Session session = HibernateUtil.getSessionFactory().openSession();

        SQLQuery query = session.createSQLQuery("select gender,fullName,email,mobileNumber,employeeId,employeeCode, profileImagePath, dateOfBirth   "
                + "                              from dh_vhr_employee where active=0 and email is not null and status=1"); //liemt10 status =1 lam viec, 2 nghi viec
        query.setFirstResult(0);
        query.setMaxResults(50);
        List list2 = query.list();
        List<Integer> lstEmployId = new ArrayList<>();
//        try {

        if (!list2.isEmpty()) {
            Transaction transaction = session.beginTransaction();
            for (int i = 0; i < list2.size(); i++) {
                Object[] row = (Object[]) list2.get(i);
                int gender = (int) row[0];
                String fullname = (String) row[1];
                String email = (String) row[2];
                String mobileNumber = (String) row[3];
                int employeeId = (int) row[4];
                String employeeCode = (String) row[5];
                String profileImagePath = (String) row[6];
                Date birthDay = (Date) row[7];
                lstEmployId.add(employeeId);

                int sex;
                if (gender == 1) {
                    sex = 2;
                } else {
                    sex = 1;
                }

                String[] phone;
                if (mobileNumber != null) {
                    phone = splitPhoneNumber(mobileNumber);
                } else {
                    phone = new String[]{"", ""};
                }

                if (email == null) {
                    email = "";
                }

                String username1; // username = phan dau email
                if (email.contains("@viettel.com.vn")) {
                    String[] listEmail = email.split("@");
                    username1 = listEmail[0];
                } else {
                    username1 = email;
                }

                DhUser user = new DhUser();

                LOGGER.info("insert user: " + username1);

                user.setUsername(username1.toLowerCase());
                user.setEmail(email);
                user.setEmployeeCode(employeeCode);
                user.setEmployeeId(employeeId);

                user.setCountryCode(phone[0]);
                user.setPhoneNumber(phone[1]);
                user.setFullname(fullname);
                user.setFullnameAscii(LocDauTiengVietUtl.perform(fullname));
                user.setSex(sex);
                user.setRegisterDate(new Date());
                user.setLastVisitDate(new Date());
                user.setModified((int) (System.currentTimeMillis() / 1000));

                LOGGER.info("set default.");
                //default
                user.setPrivacyViewProfile((byte) UserRelationship.PRIVACY_EVERYONE);
                user.setPrivacyPostProfile((byte) UserRelationship.PRIVACY_FRIENDS_ONLY);
                user.setPrivacyComment((byte) UserRelationship.PRIVACY_FRIENDS_ONLY);
                user.setPrivacyReceiveMessage((byte) UserRelationship.PRIVACY_EVERYONE);
                user.setPrivacyVisitHomePage((byte) 1);
                user.setPrivacyShowPreview(true);
                user.setPrivacyAllowFindWifi(true);

                LOGGER.info("insert avatar.");
                //AnhTT87
                user.setAvatar(profileImagePath);
                user.setAvatarSmall(profileImagePath);
                user.setAvatar90(profileImagePath);
                user.setAvatar150(profileImagePath);
                user.setBirthday(birthDay);
                session.save(user);
            }

            // update active
            updateActive(lstEmployId, session);
            transaction.commit();
            lstEmployId.clear();
        } else {
            LOGGER.info("list is empty.");
        }

//        } 
//        catch (Exception ex) {
//            LOGGER.error(ex.getCause().getMessage());
//        } 
//        finally{
//            if(session != null){
//                session.close();
//            }
////            StatisticManager.getInstance().getStatisticModel().incNoTransactionMySQL(this.getClass());
//        }
        if (session != null) {
            session.close();
        }
    }

    private String[] splitPhoneNumber(String phoneNumber) {
        String countryCode;// = "";

//		phoneNumber = phoneNumber.replace(",", "");
//		phoneNumber = phoneNumber.replace(".", "");
//		phoneNumber = phoneNumber.replace(" ", "");
//
//		if (phoneNumber.startsWith("00")) {//00xxxx
//			phoneNumber = phoneNumber.substring(2, phoneNumber.length());
//		} else if (phoneNumber.startsWith("0")) {//0xxxx
//			phoneNumber = "84" + phoneNumber.substring(1, phoneNumber.length());
//			countryCode = "84";
//		} else if (phoneNumber.startsWith("+")) {//+xxxx
//		} else {//xxxxx
//			phoneNumber = "84" + phoneNumber;
//			countryCode = "84";
//		}
        countryCode = "84";
        return new String[]{countryCode, phoneNumber};
    }

    public void updateActive(List<Integer> lstId, Session session) {
        StringBuffer sql = new StringBuffer();
        sql.append("  update   dh_vhr_employee e ");
        sql.append("  SET     e.active = 1  ");
        sql.append("    where  e.employeeId in (:idx0) ");
        SQLQuery query = session.createSQLQuery(sql.toString());
        query.setParameterList("idx0", lstId);
        int num = query.executeUpdate();
        LOGGER.info(" so luong cap nhat active trong bang employee " + num);
        LOGGER.info(" so luong active trong bang user  " + lstId.size());
//        session.close();
    }

    public static String md5(String str) {
        try {
            if (str == null) {
                return "";
            }
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] array = md.digest(str.getBytes());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < array.length; ++i) {
                sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException ex) {
            LOGGER.error(ex);
            return "";
        }
    }
}
