package com.viettel.synchronize.smartsyn;

import com.viettel.logkpi.LogKpiScheduler;
import com.viettel.synchronize.common.Config;
import com.viettel.synchronize.vhgs.MMProcessManager;
import org.apache.log4j.Logger;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import zkclient.ProcessWatcher;

/**
 *
 * @author
 */
public class Start extends ProcessWatcher {

    //public static String url;
    private static final org.apache.log4j.Logger LOGGER = Logger.getLogger(Start.class);
    public static final String JOB_SYNCHRONIZE_NAME = "SynchonizeTTNS";
    public static final String JOB_SYNCHRONIZE_GROUP = "SynGroup1";

    public static final String JOB_SYNCHRONIZE_SETTING_NAME = "SynchonizeTTNSSetting";
    public static final String JOB_SYNCHRONIZE_SETTING_GROUP = "SynGroupSetting";

    public static final String JOB_LOG_KPI_NAME = "LogKpiScheduler";
    public static final String JOB_LOG_KPI_GROUP = "LogKpiSchedulerGroup";

    //public static ExecutorService appWorkerExecutor;
    private static volatile JobDetail job;
    private static volatile Trigger trigger;
    private static volatile JobDetail jobSetting;
    private static volatile Trigger triggerSetting;
    private static volatile JobDetail jobLogKpi;
    private static volatile Trigger triggerLogKpi;

    static volatile Scheduler scheduler;
    private static String urlWSWorkDayType = "api/v1/timeKeeping/workDayType";
    private static String urlWSListWorkPlace = "api/v1/register/inout/workplace?";
    private static String urlWSListReasonOut = "api/v1/register/inout/reason?";
    private static String urlWSListWifiDevice = "api/v1/timeKeeping/device?";

    private static Start manager;

//    public static void main(String[] args) {
//        try {
//            Config.loadConfig();
//            //HA start
//            LOGGER.info("Begin start ...........................");
//            manager = new Start();
//            manager.setGroupName(Config.groupName);
//            manager.setHost(Config.threadName);
//            manager.setMemberName(Config.memberName);
//            manager.setZooHost(Config.zooHost);
//            //manager.setZooConnectInterval(Long.valueOf(Config.zooConnectInterval));
//            manager.connect();
//            LOGGER.info("End start...........................");
//            //HA end
//        } catch (IOException | InterruptedException | KeeperException ex) {
//            LOGGER.error(Start.class.getName() + " " + ex);
//        }
//    }
    public static void main(String[] args) {
        LOGGER.info("Main - Starting Synchronize ... ");
        Config.loadConfig();
        try {
            System.out.println("Bat dau chay ...");
                
            //Dong Bo Thong tin nhan su
       
            job = JobBuilder.newJob(SynchonizeVHRBusinessData.class)
                    .withIdentity(JOB_SYNCHRONIZE_NAME, JOB_SYNCHRONIZE_GROUP).build();
            trigger = TriggerBuilder
                    .newTrigger()
                    .withIdentity(JOB_SYNCHRONIZE_NAME, JOB_SYNCHRONIZE_GROUP)
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(5)).build();
                    //.withSchedule(CronScheduleBuilder.dailyAtHourAndMinute(Config.hoursOfVHR, Config.minutesOfVHR)).build();
            
            //Liemnt10: Update thong tin Log KPI
           LOGGER.info("Chay KPI log...");
//            jobLogKpi = JobBuilder.newJob(LogKpiScheduler.class)
//                    .withIdentity(JOB_LOG_KPI_NAME, JOB_LOG_KPI_GROUP).build();
//            triggerLogKpi = TriggerBuilder
//                    .newTrigger()
//                    .withIdentity(JOB_LOG_KPI_NAME, JOB_LOG_KPI_GROUP)
//                   // .withSchedule(CronScheduleBuilder.dailyAtHourAndMinute(Config.hoursOfLogKpi, Config.minutesOfLogKpi)).build();
//                    .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(30)).build();

            // schedule it
            scheduler = new StdSchedulerFactory().getScheduler();
            scheduler.start();// int second

            scheduler.scheduleJob(job, trigger);
           // scheduler.scheduleJob(jobLogKpi, triggerLogKpi);

        } catch (SchedulerException ex) {
            LOGGER.info("Error in Synchronize : " + ex);
        }

    }

    @Override
    public void doStart() {
        LOGGER.info("doStart - Starting Synchronize ... ");
        Config.loadConfig();
//            LOGGER.info("End Synchronize ... ");
//            LOGGER.info("Start syncWorkDayType ... ");
//            SynchonizeVHRSettingData.syncWorkDayType(urlWSWorkDayType);
//            LOGGER.info("End syncWorkDayType ... ");
//
//            LOGGER.info("Start syncListWorkPlace ... ");
//            SynchonizeVHRSettingData.syncListWorkPlace(urlWSListWorkPlace);
//            LOGGER.info("End syncListWorkPlace ... ");
//
//            LOGGER.info("Start syncListReasonOut ... ");
//            SynchonizeVHRSettingData.syncListReasonOut(urlWSListReasonOut);
//            LOGGER.info("End syncListReasonOut ... ");
//
//            LOGGER.info("Start syncListWifiDeviceFirstTime ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceFirstTime(urlWSListWifiDevice);
//            LOGGER.info("End syncListWifiDeviceFirstTime ... ");
//
//            LOGGER.info("Start syncListWifiDeviceInsert ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceInsert(urlWSListWifiDevice);
//            LOGGER.info("End syncListWifiDeviceInsert ... ");
//
//            LOGGER.info("Start syncListWifiDeviceUpdate ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceUpdate(urlWSListWifiDevice);
//            LOGGER.info("End syncListWifiDeviceUpdate ... ");
//
//            LOGGER.info("Start syncListWifiDeviceDelete ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceDelete(urlWSListWifiDevice);
//            LOGGER.info("End syncListWifiDeviceDelete ... ");
//        } catch (ParseException e) {
//            LOGGER.info("Error in Synchronize : " + e);
//        }
        try {
            
            jobSetting = JobBuilder.newJob(SynchonizeVHRSettingData.class)
                    .withIdentity(JOB_SYNCHRONIZE_SETTING_NAME, JOB_SYNCHRONIZE_SETTING_GROUP).build();
            triggerSetting = TriggerBuilder
                    .newTrigger()
                    .withIdentity(JOB_SYNCHRONIZE_SETTING_NAME, JOB_SYNCHRONIZE_SETTING_GROUP)
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInHours(Config.duration_SyncData_ByHour))
                    .build();
                    
            job = JobBuilder.newJob(SynchonizeVHRBusinessData.class)
                    .withIdentity(JOB_SYNCHRONIZE_NAME, JOB_SYNCHRONIZE_GROUP).build();
            trigger = TriggerBuilder
                    .newTrigger()
                    .withIdentity(JOB_SYNCHRONIZE_NAME, JOB_SYNCHRONIZE_GROUP)
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInHours(Config.duration_SyncData_ByHour))
                    .build();
            //CronScheduleBuilder.dailyAtHourAndMinute(23,59)).modifiedByCalendar("myHolidays").build();duration_SyncData_ByHour
            // .withIntervalInSeconds(30).repeatForever())

            scheduler = new StdSchedulerFactory().getScheduler();

            //PhuongTH5: tam comment chua chay job nao dinh ky
//            scheduler.scheduleJob(jobSetting, triggerSetting);
//            scheduler.scheduleJob(job, trigger);
            // schedule it
            scheduler.start();// int second

            LOGGER.info("Start tien trinh giam sat server");
            MMProcessManager.getInstance().start();
        } catch (SchedulerException ex) {
            LOGGER.info("Error in Synchronize : " + ex);
        }
    }
}
