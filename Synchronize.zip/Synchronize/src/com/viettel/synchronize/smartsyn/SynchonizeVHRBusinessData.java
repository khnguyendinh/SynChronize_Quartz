package com.viettel.synchronize.smartsyn;

import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import org.joda.time.DateTime;
import com.viettel.synchronize.common.Config;
import com.viettel.synchronize.database.hibernate.DhUser;
import com.viettel.synchronize.database.hibernate.DhVhrEmployee;
import com.viettel.synchronize.database.hibernate.DhVhrOrganization;
import com.viettel.synchronize.util.HibernateUtil;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.json.simple.parser.JSONParser;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import com.viettel.synchronize.util.LocDauTiengVietUtl;
import com.viettel.synchronize.util.MongodbConnection;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import javax.imageio.ImageIO;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Transaction;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import com.viettel.synchronize.util.DataUtils;
import java.awt.Graphics2D;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import javax.xml.soap.SOAPException;
import org.apache.commons.codec.binary.Base64;
import org.hibernate.Query;
import org.json.simple.JSONObject;

/**
 *
 * @author HuyVT2
 */
public class SynchonizeVHRBusinessData implements Job {

    private static final Logger LOGGER = Logger.getLogger(SynchonizeVHRBusinessData.class);
    private static String urlWSWorkDayType = "api/v1/timeKeeping/workDayType";
    private static String urlWSListWorkPlace = "api/v1/register/inout/workplace?";
    private static String urlWSListReasonOut = "api/v1/register/inout/reason?";
    private static String urlWSListWifiDevice = "api/v1/timeKeeping/device?";
    private static String urlVHREmployee = "api/v1/employee?";
     private static String urlVHREmployee1 = "api/v1/employee/";
    private static String urlVHROrg = "api/v1/organization?";
    private static String urlGHROrg = "api/v1/organization/data?";
    private static String urlVHRAvatar = "api/v1/employee/avata?";
    private static String urlPosition = "api/v1/position/";

    public void execute(JobExecutionContext context)throws JobExecutionException {
        LOGGER.info("Proccesing Syschonize TTNS ... ");
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {

//            LOGGER.info("Starting Synchronize ... ");
//            Config.loadConfig();
//            LOGGER.info("End Synchronize ... ");
//            LOGGER.info("Start syncWorkDayType ... ");
//            SynchonizeVHRSettingData.syncWorkDayType(urlWSWorkDayType);
//            LOGGER.info("End syncWorkDayType ... ");
//
//            LOGGER.info("Start syncListWorkPlace ... ");
//            SynchonizeVHRSettingData.syncListWorkPlace(urlWSListWorkPlace);
//            LOGGER.info("End syncListWorkPlace ... ");
//
//            LOGGER.info("Start syncListReasonOut ... ");
//            SynchonizeVHRSettingData.syncListReasonOut(urlWSListReasonOut);
//            LOGGER.info("End syncListReasonOut ... ");
//
//            LOGGER.info("Start syncListWifiDeviceFirstTime ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceFirstTime(urlWSListWifiDevice);
//            LOGGER.info("End syncListWifiDeviceFirstTime ... ");
//
//            LOGGER.info("Start syncListWifiDeviceInsert ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceInsert(urlWSListWifiDevice);
//            LOGGER.info("End syncListWifiDeviceInsert ... ");
//
//            LOGGER.info("Start syncListWifiDeviceUpdate ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceUpdate(urlWSListWifiDevice);
//            LOGGER.info("End syncListWifiDeviceUpdate ... ");
//
//            LOGGER.info("Start syncListWifiDeviceDelete ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceDelete(urlWSListWifiDevice);
//            LOGGER.info("End syncListWifiDeviceDelete ... ");
//            LOGGER.info("Start syncVHREmployeeData All ... "); chi chay 1 lan
//            SynchonizeVHRBusinessData.syncVHREmployeeData(urlVHREmployee, "ALL");
//            LOGGER.info("End syncVHREmployeeData All... ");
            
            LOGGER.info("Start syncVHROrganizationData INSERT ... " + new DateTime().toString());
            //SynchonizeVHRBusinessData.syncVHROrganizationData(urlVHROrg, "INSERT"); // Da test syncTime --> ok
            //SynchonizeVHRBusinessData.syncGHROrganizationData(urlGHROrg, "ALL"); // Da test syncTime --> ok
            
            LOGGER.info("End syncVHROrganizationData INSERT... " + new DateTime().toString());
//
//            LOGGER.info("Start syncVHROrganizationData UPDATE ... " + new DateTime().toString());
//            SynchonizeVHRBusinessData.syncVHROrganizationData(urlVHROrg, "UPDATE"); // Da test syncTime --> ok
//            LOGGER.info("End syncVHROrganizationData UPDATE... " + new DateTime().toString());
//            
            LOGGER.info("Start syncVHREmployeeData Insert ... " + new DateTime().toString());
            SynchonizeVHRBusinessData.syncGHREmployeeData(urlGHROrg, "ALL"); // Da test syncTime --> ok
//            SynchonizeVHRBusinessData.syncVHREmployeeData(urlVHREmployee, "INSERT"); //Da test syncTime --> ok
            LOGGER.info("End syncVHREmployeeData Insert... " + new DateTime().toString());
//
//            LOGGER.info("Start syncVHREmployeeData Update ... " + new DateTime().toString());
//            SynchonizeVHRBusinessData.syncVHREmployeeData(urlVHREmployee, "UPDATE"); // Da test syncTime --> ok
//            LOGGER.info("End syncVHREmployeeData Update... " + new DateTime().toString());
             
//            LOGGER.info("Start get all avatar Update ... ");
            //SynchonizeVHRBusinessData.updateAllAvatarUser();// Da test syncTime --> ok
//            LOGGER.info("End get all avatar Update... ");
              //deleteTempFileDownload();
        } catch (Exception e) {
            //rollback .....
            LOGGER.info("Error occur: " + e);
        } finally {
            if (session != null) {
                session.close();
            }
            //StatisticManager.getInstance().getStatisticModel().incNoTransactionMySQL();
        }
    }

    public static DateTime convertTimeStamptoDateTime(long time) {
        DateTime date = new DateTime(time);
        return date;
    }

    public static void main(String[] args) throws org.json.simple.parser.ParseException, JSONException, java.text.ParseException, FileNotFoundException, IOException {

//        double perFull = (double) 320 / 359;
//        System.out.println(perFull);
//        BufferedImage img = decodeToImage(imgBase64);
       //   updateAllAvatarUser();

    }

    public static String encodeToString(BufferedImage image, String type) {
        String imageString = null;
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        try {
//            ImageIO.write(image, type, bos);
//            byte[] imageBytes = bos.toByteArray();
////            BASE64Encoder encoder = new BASE64Encoder();
////            imageString = encoder.encode(imageBytes);
//            imageString = Base64.getEncoder().encodeToString(imageBytes);
//            bos.close();
//        } catch (IOException e) {
//            LOGGER.error("Loi encodeToString:" + e);
//        }
        return imageString;
    }

    public static BufferedImage decodeToImage(String imageString) {

        BufferedImage image = null;
        byte[] imageByte;
        try {
//            BASE64Decoder decoder = new BASE64Decoder();
//            imageByte = decoder.decodeBuffer(imageString);
//            imageByte = Base64.getDecoder().decode(imageString);
            imageByte = Base64.decodeBase64(imageString);
            ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
            image = ImageIO.read(bis);
            bis.close();
        } catch (IOException ex){
            LOGGER.error("Loi decodeToImage:" + ex);
        }catch (Exception e) {
            LOGGER.error("Loi decodeToImage:" + e);
        }
        return image;
    }

    public static Long getLastSyncTimeVHR(String vhrSyncData, String vhrType) {

        BasicDBObject matchFields = new BasicDBObject();

        if (vhrSyncData == "ORG") {
            matchFields.put("_id", new BasicDBObject("$eq", "VHR_ORG"));
        } else if (vhrSyncData == "USER") {
            matchFields.put("_id", new BasicDBObject("$eq", "VHR_USER"));
        } else if (vhrSyncData == "SETTING") {
            matchFields.put("_id", new BasicDBObject("$eq", "VHR_SETTING"));
        }
        BasicDBObject match = new BasicDBObject("$match", matchFields);
        BasicDBObject projectFields = new BasicDBObject();
        projectFields.put("_id", 0);
        if(vhrType == "UPDATE")
            projectFields.put("lastSyncTimeUpdate", 1);
        else if (vhrType == "INSERT")
            projectFields.put("lastSyncTimeInsert", 1);
        else
            projectFields.put("lastSyncTime", 1);
        BasicDBObject project = new BasicDBObject("$project", projectFields);
        AggregationOutput output = MongodbConnection.getInstance().getVHRTimeSyncConnection().aggregate(match, project);
        JSONParser jsonParser = new JSONParser();
        if (output == null) {
            return 0l;
        }
        Long temp = 0l;
        for (DBObject result : output.results()) {
            try {
                org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject) jsonParser.parse(result.toString());
                //temp = (Long) jsonObject.get("lastSyncTime");
                if(vhrType == "UPDATE")
                    temp = (Long) jsonObject.get("lastSyncTimeUpdate");
                else if (vhrType == "INSERT")
                    temp = (Long) jsonObject.get("lastSyncTimeInsert");
                else
                    temp = (Long) jsonObject.get("lastSyncTime");
            } catch (ParseException ex) {
                LOGGER.error(SynchonizeVHRBusinessData.class.getName() + " " + ex);
            }
        }
        return temp;
    }

    public static int getTotalPageVHREmployee(String urlVHREmployee, String vhrType, long timeSync) throws ParseException {
        HashMap map = new HashMap();
        map.put("type", vhrType);
        map.put("syncTime", "" + timeSync);
        map.put("page", "0");
        map.put("per_page", "30");
        map.put("sort", "employeeCode");
        String strVHREmployee = TTNSQuery.getResultFromVHRParam(urlVHREmployee, map);
        JSONParser jsonParser = new JSONParser();
        Long totalPages = 0l;
        if (strVHREmployee != null && !strVHREmployee.isEmpty() && strVHREmployee.length() > 0) {
            org.json.simple.JSONObject jsonO = (org.json.simple.JSONObject) jsonParser.parse(strVHREmployee);
            org.json.simple.JSONObject jsonMetadata = (org.json.simple.JSONObject) jsonO.get("metadata");
            totalPages = (Long) jsonMetadata.get("totalPages");
        }
        return Integer.valueOf(totalPages.intValue());
    }

    public static int getTotalPageVHROrg(String urlVHROrg, String vhrType, long timeSync) throws ParseException {
        HashMap map = new HashMap();
        map.put("type", vhrType);
        map.put("syncTime", "" + timeSync);
        map.put("page", "0");
        map.put("per_page", "30");
        String strVHREmployee = TTNSQuery.getResultFromVHRParam(urlVHROrg, map);
        JSONParser jsonParser = new JSONParser();
        Long totalPages = 0l;
        if (strVHREmployee != null && !strVHREmployee.isEmpty() && strVHREmployee.length() > 0) {
            org.json.simple.JSONObject jsonO = (org.json.simple.JSONObject) jsonParser.parse(strVHREmployee);
            org.json.simple.JSONObject jsonMetadata = (org.json.simple.JSONObject) jsonO.get("metadata");
            totalPages = (Long) jsonMetadata.get("totalPages");
        }
        return Integer.valueOf(totalPages.intValue());
    }
    
     public static void syncGHREmployeeData(String urlGHROrg, String vhrType) throws ParseException {
        try {
            String timeSync = "";
            if (vhrType == "ALL") {
                timeSync = "";
            } 
            
            org.json.JSONObject strVHREmployee = TTNSQuery.requestSOAPRequestEmployeeGhr(timeSync);
            org.json.JSONArray jArr = strVHREmployee.getJSONArray("responseEmployeeBean");
            String str = jArr.toString();
            long timeUpdate = System.currentTimeMillis() / 1000;
            JSONParser jsonParser = new JSONParser();
            org.json.simple.JSONArray jsonAr = (org.json.simple.JSONArray) jsonParser.parse(str);
            syncDhGhrEmployeePerPage(jsonAr, timeUpdate);
            //updateDhUser(jsonAr, timeUpdate,"ghr");
        } catch (SOAPException ex) {
            java.util.logging.Logger.getLogger(SynchonizeVHRBusinessData.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(SynchonizeVHRBusinessData.class.getName()).log(Level.SEVERE, null, ex);
        }       
        
    }
    
    public static void syncGHROrganizationData(String urlGHROrg, String vhrType) throws ParseException {
        try {
            String timeSync = "";
            if (vhrType == "ALL") {
                timeSync = "";
            } 
            
            org.json.JSONObject strVHREmployee = TTNSQuery.requestSOAPRequestOrgGhr(timeSync);
            org.json.JSONArray jArr = strVHREmployee.getJSONArray("responseOrganizationBean");
            String str = jArr.toString();
            long timeUpdate = System.currentTimeMillis() / 1000;
            JSONParser jsonParser = new JSONParser();
            org.json.simple.JSONArray jsonAr = (org.json.simple.JSONArray) jsonParser.parse(str);
            syncDhGhrOrganizationPerPage(jsonAr, timeUpdate);
        } catch (SOAPException ex) {
            java.util.logging.Logger.getLogger(SynchonizeVHRBusinessData.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(SynchonizeVHRBusinessData.class.getName()).log(Level.SEVERE, null, ex);
        }       
        
    }

    public static void syncVHROrganizationData(String urlVHROrg, String vhrType) throws ParseException {
        long timeSync;
        if (vhrType == "ALL") {
            timeSync = 0;
        } else {
            timeSync = getLastSyncTimeVHR("ORG",vhrType) * 1000;
        }
        //timeSync = 1480550400000L;
        int total = getTotalPageVHROrg(urlVHROrg, vhrType, timeSync);
//        int total = 3;
        long timeUpdate = System.currentTimeMillis() / 1000;
        int countSyncRow = 0;
        for (int j = 0; j < total; j++) {
            System.out.println("Page ---:" + j);
            HashMap map = new HashMap();
            map.put("type", vhrType);
            map.put("syncTime", "" + timeSync);
            map.put("page", String.valueOf(j));
            map.put("per_page", "30");
            String strVHREmployee = TTNSQuery.getResultFromVHRParam(urlVHROrg, map);
            JSONParser jsonParser = new JSONParser();
            if (strVHREmployee != null && !strVHREmployee.isEmpty() && strVHREmployee.length() > 0) {
                org.json.simple.JSONObject jsonO = (org.json.simple.JSONObject) jsonParser.parse(strVHREmployee);
                org.json.simple.JSONArray jArrContent = (org.json.simple.JSONArray) jsonO.get("content");
                LOGGER.info("Page ---------  : " + j);
                if (vhrType == "ALL" || vhrType == "INSERT" || vhrType == "UPDATE") {
                    if (jArrContent != null && jArrContent.size() > 0) {
                        countSyncRow = countSyncRow + syncDhVhrOrganizationPerPage(jArrContent, timeUpdate);
                    }
                }
            }
        }
        if (total > 0) {
            BasicDBObject set = new BasicDBObject();
            BasicDBObject searchQuery = new BasicDBObject().append("_id", "VHR_ORG");
            set.append("lastSyncTime", timeUpdate);
            if (vhrType == "ALL") {
                set.append("count_ALL_VHR_ORG", countSyncRow);
            } else if (vhrType == "INSERT") {
                set.append("count_INSERT_VHR_ORG", countSyncRow);
                set.append("lastSyncTimeInsert", timeUpdate);
            } else if (vhrType == "UPDATE") {
                set.append("count_UPDATE_VHR_ORG", countSyncRow);
                set.append("lastSyncTimeUpdate", timeUpdate);
            }
            BasicDBObject update = new BasicDBObject();
            update.put("$set", set);
            MongodbConnection.getInstance().getVHRTimeSyncConnection().update(searchQuery, update);
        }
    }

    public static void syncVHREmployeeData(String urlVHREmployee, String vhrType) throws ParseException {
        long timeSync;
        int countSyncRow = 0;
        int countSyncAvatarRow = 0;
        if (vhrType == "ALL") {
            timeSync = 0;
        } else {
            timeSync = getLastSyncTimeVHR("USER",vhrType) * 1000;
        }
        int total = getTotalPageVHREmployee(urlVHREmployee, vhrType, timeSync);
//        int total = 3;
        long timeUpdate = System.currentTimeMillis() / 1000;
        for (int j = 0; j < total; j++) {
            HashMap map = new HashMap();
            map.put("type", vhrType);
            map.put("syncTime", "" + timeSync);
            map.put("page", String.valueOf(j));
            map.put("per_page", "30");
            map.put("sort", "employeeCode");
            String strVHREmployee = TTNSQuery.getResultFromVHRParam(urlVHREmployee, map);
            JSONParser jsonParser = new JSONParser();
            if (strVHREmployee != null && !strVHREmployee.isEmpty() && strVHREmployee.length() > 0) {
                org.json.simple.JSONObject jsonO = (org.json.simple.JSONObject) jsonParser.parse(strVHREmployee);
                org.json.simple.JSONArray jArrContent = (org.json.simple.JSONArray) jsonO.get("content");
                LOGGER.info("Page ---------  : " + j);
                if (vhrType == "ALL" || vhrType == "INSERT" || vhrType == "UPDATE") {
                    if (jArrContent != null && jArrContent.size() > 0) {
                        countSyncRow = countSyncRow + syncDhVhrEmployeePerPage(jArrContent, timeUpdate);
                        //countSyncAvatarRow = countSyncAvatarRow + syncAvatarUserPerPage(jArrContent, timeUpdate);
                        if (vhrType == "UPDATE") {
                            updateDhUser(jArrContent, timeUpdate,"vhr");
                        } else {
                            countSyncAvatarRow = countSyncAvatarRow + syncAvatarUserPerPage(jArrContent, timeUpdate);
                            insertDhUser(jArrContent, timeUpdate,"vhr");
                        }
                    }
                }
            }
        }
        if (total > 0) {
            BasicDBObject set = new BasicDBObject();
            BasicDBObject searchQuery = new BasicDBObject().append("_id", "VHR_USER");
            set.append("lastSyncTime", timeUpdate);
            if (vhrType == "ALL") {
                set.append("count_ALL_VHR_USER", countSyncRow);
            } else if (vhrType == "INSERT") {
                set.append("count_INSERT_VHR_USER", countSyncRow);
                set.append("count_INSERT_AVATAR", countSyncAvatarRow);
                set.append("lastSyncTimeInsert", timeUpdate);
            } else if (vhrType == "UPDATE") {
                set.append("count_UPDATE_VHR_USER", countSyncRow);
                set.append("count_UPDATE_AVATAR", countSyncAvatarRow);
                set.append("lastSyncTimeUpdate", timeUpdate);
            }
            BasicDBObject update = new BasicDBObject();
            update.put("$set", set);
            MongodbConnection.getInstance().getVHRTimeSyncConnection().update(searchQuery, update);
            LOGGER.info("update last sync time ---------  : " + timeUpdate);
        }

    }
    
    public static int syncDhGhrOrganizationPerPage(org.json.simple.JSONArray jContent, long timeUpdate) {
        Session session1 = null;
        int count = 0;
        try {
            SimpleDateFormat sdfDate2 = new SimpleDateFormat("dd/MM/yyyy");
            session1 = HibernateUtil.getSessionFactory().openSession();
            Transaction transaction = session1.beginTransaction();
            for (Object object : jContent) {
                try {

                    DhVhrOrganization dhVhrOrganization = new DhVhrOrganization();
                    org.json.simple.JSONObject eJson = (org.json.simple.JSONObject) object;
                    if ((Long) eJson.get("organizationId") != null) {
                        dhVhrOrganization.setOrganizationId(DataUtils.convertLongToInt((Long) eJson.get("organizationId"), 0));
                        count += 1;
                    }
                    LOGGER.info("Synchronize dhVhrOrganization with organizationId: " + (Long) eJson.get("organizationId"));
                    String orgCode = (String) eJson.get("code");
                    if (orgCode != null) {
                        if (orgCode.length() > 11) {
                            dhVhrOrganization.setCode(orgCode.substring(0, 11));
                        } else {
                            dhVhrOrganization.setCode((String) eJson.get("code"));
                        }

                    }
                    if ((String) eJson.get("effectiveEndDate") != null) {

                        Date effectiveEndDate = sdfDate2.parse((String) eJson.get("effectiveEndDate"));
                        dhVhrOrganization.setEffectiveEndDate(effectiveEndDate);

                    }
                    if ((String) eJson.get("effectiveStartDate") != null) {

                        Date effectiveStartDate = sdfDate2.parse((String) eJson.get("effectiveStartDate"));
                        dhVhrOrganization.setEffectiveStartDate(effectiveStartDate);

                    }
                    String name = " ";
                    if ((String) eJson.get("name") != null) {
                        name = (String) eJson.get("name");
                    }
                    LOGGER.info("Synchronize dhVhrOrganization with organizationId: " + name);
                    dhVhrOrganization.setName(name);
                    dhVhrOrganization.setNumOfNonPartyMember(0);
                    dhVhrOrganization.setNumOfPartyMember(0);
                    dhVhrOrganization.setOrderNumber(DataUtils.convertLongToInt((Long) eJson.get("orderNumber"), 0));
                    dhVhrOrganization.setOrgLevelManage(DataUtils.convertLongToInt((Long) eJson.get("orgLevel"), 0));
                    dhVhrOrganization.setOrgType(String.valueOf((Long) eJson.get("orgTypeId")));
                    dhVhrOrganization.setParentId(DataUtils.convertLongToInt((Long) eJson.get("parentId"), 0));
                    dhVhrOrganization.setPath((String) eJson.get("path"));
                    dhVhrOrganization.setLastSyncTime(timeUpdate);

                    try {
                        if ((Long) eJson.get("organizationId") != null) {
                            session1.saveOrUpdate(dhVhrOrganization);
                        }

                    } catch (Exception e) { //Tranh bi loi duplicate do du lieu test
                        LOGGER.error(" session1.saveOrUpdate - Bi duplication OrgId:" + e);
                        count -= 1;
                    }
                } catch (java.text.ParseException ex) {
                    LOGGER.error(SynchonizeVHRBusinessData.class.getName() + "------------Bi duplication EmployeeId: " + ex);
                    count -= 1;
                }
            }
            transaction.commit();

        } catch (HibernateException ex) {
            LOGGER.error("Insert error: ", ex);
        } finally {
            if (session1 != null) {
                session1.close();
                LOGGER.info("-------------------------- Close:");
            }
        }
        return count;
    }

    public static int syncDhVhrOrganizationPerPage(org.json.simple.JSONArray jContent, long timeUpdate) {
        Session session1 = null;
        int count = 0;
        try {
            SimpleDateFormat sdfDate2 = new SimpleDateFormat("yyyy-MM-dd");
            session1 = HibernateUtil.getSessionFactory().openSession();
            Transaction transaction = session1.beginTransaction();
            for (Object object : jContent) {
                try {

                    DhVhrOrganization dhVhrOrganization = new DhVhrOrganization();
                    org.json.simple.JSONObject eJson = (org.json.simple.JSONObject) object;
                    if ((Long) eJson.get("organizationId") != null) {
                        dhVhrOrganization.setOrganizationId(DataUtils.convertLongToInt((Long) eJson.get("organizationId"), 0));
                        count += 1;
                    }
                    LOGGER.info("Synchronize dhVhrOrganization with organizationId: " + (Long) eJson.get("organizationId"));
                    String orgCode = (String) eJson.get("code");
                    if (orgCode != null) {
                        if (orgCode.length() > 11) {
                            dhVhrOrganization.setCode(orgCode.substring(0, 11));
                        } else {
                            dhVhrOrganization.setCode((String) eJson.get("code"));
                        }

                    }
                    if ((Long) eJson.get("effectiveEndDate") != null) {

                        Date effectiveEndDate = sdfDate2.parse(String.valueOf(convertTimeStamptoDateTime((Long) eJson.get("effectiveEndDate"))));
                        dhVhrOrganization.setEffectiveEndDate(effectiveEndDate);

                    }
                    if ((Long) eJson.get("effectiveStartDate") != null) {

                        Date effectiveStartDate = sdfDate2.parse(String.valueOf(convertTimeStamptoDateTime((Long) eJson.get("effectiveStartDate"))));
                        dhVhrOrganization.setEffectiveStartDate(effectiveStartDate);

                    }
                    String name = " ";
                    if ((String) eJson.get("name") != null) {
                        name = (String) eJson.get("name");
                    }
                    LOGGER.info("Synchronize dhVhrOrganization with organizationId: " + name);
                    dhVhrOrganization.setName(name);
                    dhVhrOrganization.setNumOfNonPartyMember(0);
                    dhVhrOrganization.setNumOfPartyMember(0);
                    dhVhrOrganization.setOrderNumber(DataUtils.convertLongToInt((Long) eJson.get("orgOrder"), 0));
                    dhVhrOrganization.setOrgLevelManage(DataUtils.convertLongToInt((Long) eJson.get("orgLevel"), 0));
                    dhVhrOrganization.setOrgType(String.valueOf((Long) eJson.get("orgTypeId")));
                    dhVhrOrganization.setParentId(DataUtils.convertLongToInt((Long) eJson.get("orgParentId"), 0));
                    dhVhrOrganization.setPath((String) eJson.get("path"));
                    dhVhrOrganization.setLastSyncTime(timeUpdate);

                    try {
                        if ((Long) eJson.get("organizationId") != null) {
                            session1.saveOrUpdate(dhVhrOrganization);
                        }

                    } catch (Exception e) { //Tranh bi loi duplicate do du lieu test
                        LOGGER.error(" session1.saveOrUpdate - Bi duplication OrgId:" + e);
                        count -= 1;
                    }
                } catch (java.text.ParseException ex) {
                    LOGGER.error(SynchonizeVHRBusinessData.class.getName() + "------------Bi duplication EmployeeId: " + ex);
                    count -= 1;
                }
            }
            transaction.commit();

        } catch (HibernateException ex) {
            LOGGER.error("Insert error: ", ex);
        } finally {
            if (session1 != null) {
                session1.close();
                LOGGER.info("-------------------------- Close:");
            }
        }
        return count;
    }
    
    public static int syncDhGhrEmployeePerPage(org.json.simple.JSONArray jContent, long timeUpdate) {
        Session session1 = null;
        int count = 0;
        try {
            String avatarUrl = Config.avatarUrl;
            SimpleDateFormat sdfDate2 = new SimpleDateFormat("dd/MM/yyyy");
            session1 = HibernateUtil.getSessionFactory().openSession();
            Transaction transaction = session1.beginTransaction();
            for (Object object : jContent) {
                try {
                    org.json.simple.JSONObject eJson = (org.json.simple.JSONObject) object;
                    //LOGGER.info("---json :" + eJson);
                    Long epId = (Long) eJson.get("employeeId");
                    if(epId != 33113)
                        continue;
                    DhVhrEmployee dhVhrEmployee = new DhVhrEmployee();
                    if ((Long) eJson.get("organizationId") != null) {
                        dhVhrEmployee.setOrganizationId(DataUtils.convertLongToInt((Long) eJson.get("organizationId"), 0));
                        Long orgId = (Long) eJson.get("organizationId");
                        DhVhrOrganization orgs = (DhVhrOrganization) TTNSQuery.getOrgInfo(DataUtils.convertLongToInt(orgId,0));
                        if(orgs == null)
                            continue;
                    }
                    dhVhrEmployee.setAccountNumber("11111111111111");
                    dhVhrEmployee.setBank("MB Bank");
                    dhVhrEmployee.setBankBranch("Hoan Kiem Branch");
                    dhVhrEmployee.setCollectCallCode((String) eJson.get("collectCallCode"));
//                    dhVhrEmployee.setCurrentAddress((String) eJson.get("currentAddress"));
                    dhVhrEmployee.setCurrentAddress(" "); // chuyen thanh mac dinh theo comment của a HoangPX
                    dhVhrEmployee.setProfileImagePath(avatarUrl + (Long) eJson.get("employeeId") + ".jpg");
                    if (eJson.containsKey("dateOfBirth")) {
                        Date dateOfBirth = sdfDate2.parse((String) eJson.get("dateOfBirth"));
                        dhVhrEmployee.setDateOfBirth(dateOfBirth);
                    }
                    dhVhrEmployee.setEmail(String.valueOf(eJson.get("email")));
                    if (String.valueOf( eJson.get("employeeCode")) != null) {
                        String empCode = String.valueOf( eJson.get("employeeCode"));
                        if(empCode.length() >= 6)
                            continue;
                        
                        dhVhrEmployee.setEmployeeCode(String.valueOf( eJson.get("employeeCode")));
                    } else {
                        dhVhrEmployee.setEmployeeCode("-1");
                    }
                    if ((Long) eJson.get("employeeId") != null) {
                        dhVhrEmployee.setEmployeeId(DataUtils.convertLongToInt((Long) eJson.get("employeeId"), 0));
                        count += 1;
                    }
//                    LOGGER.info("employId =  : " + (Long) eJson.get("employeeId"));
//                LOGGER.info("employee Name = : " + (String) eJson.get("fullName"));
                    if ((String) eJson.get("fullName") != null) {
                        dhVhrEmployee.setFullName((String) eJson.get("fullName"));
                    } else {
                        dhVhrEmployee.setFullName(" ");
                    }
                    if ((Long) eJson.get("gender") != null) {
                        dhVhrEmployee.setGender(DataUtils.convertLongToInt((Long) eJson.get("gender"), -1));
                    } else {
                        dhVhrEmployee.setGender(-1);
                    }
                    if (String.valueOf(eJson.get("mobileNumber")) != null) {
                        dhVhrEmployee.setMobileNumber(String.valueOf(eJson.get("mobileNumber")));
                        dhVhrEmployee.setMobileNumber2(String.valueOf(eJson.get("mobileNumber")));
                    }
                    Long postionId = (Long) eJson.get("positionId");
                    if ((Long) eJson.get("positionId") != null) {
                        dhVhrEmployee.setPositionId(DataUtils.convertLongToInt((Long) eJson.get("positionId"), -1));
                    } else {
                        dhVhrEmployee.setPositionId(-1);
                    }
                    if(eJson.containsKey("positionName"))
                        dhVhrEmployee.setPositionName((String) eJson.get("positionName"));
                    else
                        dhVhrEmployee.setPositionName("");
                    //dhVhrEmployee.setPositionName((String) eJson.get("positionName"));
                    // get position name
                    //String positionName = TTNSQuery.getResultFromVHRNotParam(urlPosition + postionId);
                    //JSONParser jsonParser = new JSONParser();
//                    if (positionName != null && !positionName.isEmpty() && positionName.length() > 0) {
//                            org.json.simple.JSONObject jsonO = (org.json.simple.JSONObject) jsonParser.parse(positionName);
//                            String pName = (String) jsonO.get("positionName");
//                            LOGGER.info("Position Name ---------  : " + pName);
//                            dhVhrEmployee.setPositionName(pName);
//                    }else{
//                        dhVhrEmployee.setPositionName("");
//                    }
                    
                    dhVhrEmployee.setSaleCode("");
                    if ((Long) eJson.get("soldierLevelId") != null) {
                        dhVhrEmployee.setSoldierLevel(String.valueOf((Long) eJson.get("soldierLevelId")));
                    }
                    dhVhrEmployee.setTelephoneNumber("0000000000");
                    if ((Long) eJson.get("organizationId") != null) {
                        dhVhrEmployee.setOrganizationId(DataUtils.convertLongToInt((Long) eJson.get("organizationId"), 0));
                        Long orgId = (Long) eJson.get("organizationId");
                        DhVhrOrganization orgs = (DhVhrOrganization) TTNSQuery.getOrgInfo(DataUtils.convertLongToInt(orgId,0));
                        if(orgs == null)
                            continue;
                    } else {
                        dhVhrEmployee.setOrganizationId(0);
                    }
                    if ((Long) eJson.get("status") != null) {
                        dhVhrEmployee.setStatus((Long) eJson.get("status"));
                    } else {
                        dhVhrEmployee.setStatus(-1l);
                    }
                    if ((Long) eJson.get("isActive") != null) {
                        dhVhrEmployee.setActive(DataUtils.convertLongToInt((Long) eJson.get("isActive"), -1));
                    } else {
                        dhVhrEmployee.setActive(-1);
                    }
                    dhVhrEmployee.setLastSyncTime(timeUpdate);
                   // if(DataUtils.convertLongToInt((Long) eJson.get("employeeId"),0) != 6011860)
                        session1.saveOrUpdate(dhVhrEmployee);
                    LOGGER.info("-------------------------- sync dh_vhr_employee: " + String.valueOf( eJson.get("employeeCode")) + "--" + count);
                } catch (java.text.ParseException ex) {
                    LOGGER.error(SynchonizeVHRBusinessData.class.getName() + " syncDhVhrEmployee------------Bi duplication EmployeeId: " + ex);
                    count -= 1;
                }
            }
            transaction.commit();
        } catch (Exception ex) {
            LOGGER.error("Insert error: ", ex);
        } finally {
            LOGGER.info("-------------------------- Close: syncDhVhrEmployee");
            if (session1 != null) {
                session1.close();
            }
        }
        return count;
    }
    
    public static int syncDhVhrEmployeePerPage(org.json.simple.JSONArray jContent, long timeUpdate) {
        Session session1 = null;
        int count = 0;
        try {
            String avatarUrl = Config.avatarUrl;
            SimpleDateFormat sdfDate2 = new SimpleDateFormat("yyyy-MM-dd");
            session1 = HibernateUtil.getSessionFactory().openSession();
            Transaction transaction = session1.beginTransaction();
            for (Object object : jContent) {
                try {
                    org.json.simple.JSONObject eJson = (org.json.simple.JSONObject) object;
                    DhVhrEmployee dhVhrEmployee = new DhVhrEmployee();
                    dhVhrEmployee.setAccountNumber("11111111111111");
                    dhVhrEmployee.setBank("MB Bank");
                    dhVhrEmployee.setBankBranch("Hoan Kiem Branch");
                    dhVhrEmployee.setCollectCallCode((String) eJson.get("collectCallCode"));
//                    dhVhrEmployee.setCurrentAddress((String) eJson.get("currentAddress"));
                    dhVhrEmployee.setCurrentAddress(" "); // chuyen thanh mac dinh theo comment của a HoangPX
                    dhVhrEmployee.setProfileImagePath(avatarUrl + (Long) eJson.get("employeeId") + ".jpg");
                    if ((Long) eJson.get("dateOfBirth") != null) {
                        Date dateOfBirth = sdfDate2.parse(String.valueOf(convertTimeStamptoDateTime((Long) eJson.get("dateOfBirth"))));
                        dhVhrEmployee.setDateOfBirth(dateOfBirth);
                    }
                    dhVhrEmployee.setEmail((String) eJson.get("email"));
                    if ((String) eJson.get("employeeCode") != null) {
                        dhVhrEmployee.setEmployeeCode((String) eJson.get("employeeCode"));
                    } else {
                        dhVhrEmployee.setEmployeeCode("-1");
                    }
                    if ((Long) eJson.get("employeeId") != null) {
                        dhVhrEmployee.setEmployeeId(DataUtils.convertLongToInt((Long) eJson.get("employeeId"), 0));
                        count += 1;
                    }
//                    LOGGER.info("employId =  : " + (Long) eJson.get("employeeId"));
//                LOGGER.info("employee Name = : " + (String) eJson.get("fullName"));
                    if ((String) eJson.get("fullName") != null) {
                        dhVhrEmployee.setFullName((String) eJson.get("fullName"));
                    } else {
                        dhVhrEmployee.setFullName(" ");
                    }
                    if ((Long) eJson.get("gender") != null) {
                        dhVhrEmployee.setGender(DataUtils.convertLongToInt((Long) eJson.get("gender"), -1));
                    } else {
                        dhVhrEmployee.setGender(-1);
                    }
                    if ((String) eJson.get("mobileNumber") != null) {
                        dhVhrEmployee.setMobileNumber(DataUtils.standardizeMobileNumber((String) eJson.get("mobileNumber")));
                        dhVhrEmployee.setMobileNumber2(DataUtils.standardizeMobileNumber2((String) eJson.get("mobileNumber")));
                    }
                    Long postionId = (Long) eJson.get("positionId");
                    if ((Long) eJson.get("positionId") != null) {
                        dhVhrEmployee.setPositionId(DataUtils.convertLongToInt((Long) eJson.get("positionId"), -1));
                    } else {
                        dhVhrEmployee.setPositionId(-1);
                    }
                    
                    //dhVhrEmployee.setPositionName((String) eJson.get("positionName"));
                    // get position name
                    String positionName = TTNSQuery.getResultFromVHRNotParam(urlPosition + postionId);
                    JSONParser jsonParser = new JSONParser();
                    if (positionName != null && !positionName.isEmpty() && positionName.length() > 0) {
                            org.json.simple.JSONObject jsonO = (org.json.simple.JSONObject) jsonParser.parse(positionName);
                            String pName = (String) jsonO.get("positionName");
                            LOGGER.info("Position Name ---------  : " + pName);
                            dhVhrEmployee.setPositionName(pName);
                    }else{
                        dhVhrEmployee.setPositionName("");
                    }
                    
                    dhVhrEmployee.setSaleCode((String) eJson.get("saleCode"));
                    if ((Long) eJson.get("soldierLevelId") != null) {
                        dhVhrEmployee.setSoldierLevel(String.valueOf((Long) eJson.get("soldierLevelId")));
                    }
                    dhVhrEmployee.setTelephoneNumber("0000000000");
                    if ((Long) eJson.get("organizationId") != null) {
                        dhVhrEmployee.setOrganizationId(DataUtils.convertLongToInt((Long) eJson.get("organizationId"), 0));
                    } else {
                        dhVhrEmployee.setOrganizationId(0);
                    }
                    if ((Long) eJson.get("status") != null) {
                        dhVhrEmployee.setStatus((Long) eJson.get("status"));
                    } else {
                        dhVhrEmployee.setStatus(-1l);
                    }
                    if ((Long) eJson.get("isActive") != null) {
                        dhVhrEmployee.setActive(DataUtils.convertLongToInt((Long) eJson.get("isActive"), -1));
                    } else {
                        dhVhrEmployee.setActive(-1);
                    }
                    dhVhrEmployee.setLastSyncTime(timeUpdate);

                    session1.saveOrUpdate(dhVhrEmployee);
                } catch (java.text.ParseException ex) {
                    LOGGER.error(SynchonizeVHRBusinessData.class.getName() + " syncDhVhrEmployee------------Bi duplication EmployeeId: " + ex);
                    count -= 1;
                }
            }
            transaction.commit();
        } catch (Exception ex) {
            LOGGER.error("Insert error: ", ex);
        } finally {
            LOGGER.info("-------------------------- Close:");
            if (session1 != null) {
                session1.close();
            }
        }
        return count;
    }

    public static void resizeImage(BufferedImage inputImage,String outputImagePath, double percent) {
        try {
            int scaledWidth = (int) (inputImage.getWidth() * percent);
            int scaledHeight = (int) (inputImage.getHeight() * percent);
            BufferedImage outputImage = new BufferedImage(scaledWidth,
                    scaledHeight, BufferedImage.TYPE_INT_RGB);

            // scales the input image to the output image
            Graphics2D g2d = outputImage.createGraphics();
            g2d.drawImage(inputImage, 0, 0, scaledWidth, scaledHeight, null);
            g2d.dispose();

            // extracts extension of output file
            String formatName = outputImagePath.substring(outputImagePath
                    .lastIndexOf(".") + 1);

            // writes to output file
            ImageIO.write(outputImage, "jpg", new File(outputImagePath));
        } catch (IOException e) {
            LOGGER.error("Can not resize : " + outputImagePath + " " + e );
        }
        catch( Exception ex){
            LOGGER.error("Can not resize : " + outputImagePath + " " + ex);
        }

    }

    public static int syncAvatarUserPerPage(org.json.simple.JSONArray jContent, long timeUpdate) {
        int countAvatar = 0;
        // dong bo avatar
        for (Object object : jContent) {
            org.json.simple.JSONObject eJson = (org.json.simple.JSONObject) object;
            int status = DataUtils.convertLongToInt((Long) eJson.get("status"), 0);
            if (eJson.get("employeeId") != null && status == 1) {
                try {
                    long empId = (Long) eJson.get("employeeId");
                    HashMap map = new HashMap();
                    map.put("employee_id", "" + empId);
                    LOGGER.info(" update Avatar --- employeeId: " + empId + " -------------------------- ");
                    String strAvatarEmployee = TTNSQuery.getResultFromVHRParam(urlVHRAvatar, map);
                    JSONParser jsonParser = new JSONParser();
                    if (strAvatarEmployee != null && !strAvatarEmployee.isEmpty() && strAvatarEmployee.length() > 0) {
                        org.json.simple.JSONObject jsonO = (org.json.simple.JSONObject) jsonParser.parse(strAvatarEmployee);
                        String sAvatarImage = (String) jsonO.get("entity");
                        long rsStatus = (Long) jsonO.get("status");
                        if (rsStatus == 200) {
                            if (sAvatarImage.length() > 0) {
                                String avatarNormalUrl = Config.avatarNormalUrl;
                                String avatarBigUrl = Config.avatarBigUrl;
                                String avatarOrginalUrl = Config.avatarOrginalUrl;
                                String[] imageFile = sAvatarImage.split(";base64,");
                                String sMetaData = imageFile[0]; //data:image/jpeg
                                String sAvatarImageFinal = imageFile[1];
                                String[] sTypeImage = sMetaData.split("/");
                                String typeImage = sTypeImage[1];
                                if (sAvatarImageFinal != null && sAvatarImageFinal.length() > 0) {
                                    BufferedImage img1 = decodeToImage(sAvatarImageFinal);
                                    if (img1 != null) {
                                        if (img1.getWidth() > 400) {
                                            double perFull = (double) 1024 / img1.getWidth();
                                            double perSmall = (double) 150 / img1.getWidth();
                                            resizeImage(img1, avatarNormalUrl + empId + ".jpg", perSmall); // anh small
                                            resizeImage(img1, avatarBigUrl + empId + ".jpg", perFull);// anh big
                                            resizeImage(img1, avatarOrginalUrl + empId + ".jpg", 1.0); // luu anh goc sau nay can thi dung lai
                                        } else {
                                            resizeImage(img1, avatarNormalUrl + empId + ".jpg", 0.9); // anh small
                                            resizeImage(img1, avatarBigUrl + empId + ".jpg", 1.0);// anh big
                                            resizeImage(img1, avatarOrginalUrl + empId + ".jpg", 1.0); // luu anh goc sau nay can thi dung lai
                                        }
                                    }

// Code theo lib cu
//                                    int scaledWidth = (int) (img1.getWidth() * percent);
//                                    int scaledHeight = (int) (img1.getHeight() * percent);
//                                    ImageType iType = ImageType.getType(typeImage);
//                                    Image img = new Image(img1, iType);
//                                    if (img.getWidth() > 320) {
//                                        Image resizedSmall = img.getResizedToWidth(100);
//                                        Image resizedBigger = img.getResizedToWidth(320);
//                                    img.softenAndSave(resizedSmall, 1f, 0f, avatarNormalUrl + empId); //anh small
//                                    img.softenAndSave(resizedBigger, 1f, 0f, avatarBigUrl + empId); // anh big
//                                    img.writeToJPG(new File(avatarOrginalUrl + empId + ".jpg"), 1f); // luu anh goc sau nay can thi dung lai
//                                        resizedSmall.dispose();
//                                        resizedBigger.dispose();
//                                        countAvatar += 1;
//                                    } else {
//                                        img.writeToJPG(new File(avatarNormalUrl + empId + ".jpg"), 1f);
//                                        img.writeToJPG(new File(avatarBigUrl + empId + ".jpg"), 1f);
//                                        img.writeToJPG(new File(avatarOrginalUrl + empId + ".jpg"), 1f); // luu anh goc sau nay can thi dung lai
//                                        countAvatar += 1;
//                                    }
                                }
                            }
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.info( SynchonizeVHRBusinessData.class.getName() + " error Avatar" + ex + "-------------------------- Close:");
                    LOGGER.error(SynchonizeVHRBusinessData.class.getName() + " error Avatar" + ex);
                }
            }
        }
        return countAvatar;
    }
    
    private static void updateAllUserWrongPhoneNumber(){
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        SQLQuery query2 = session.createSQLQuery(" SELECT  employeeId  FROM dh_user WHERE LENGTH(phoneNumber) <= 10 and phoneNumber != 0");
        List list2 = new ArrayList();
        list2 = query2.list();
        Iterator it = list2.iterator();
        int empId;
        try {
        while (it.hasNext()){
            empId = (int) it.next();
            String strEmployee = TTNSQuery.getResultFromVHRNotParam(urlVHREmployee1 + empId);
            JSONParser jsonParser = new JSONParser();
            if (strEmployee != null && !strEmployee.isEmpty() && strEmployee.length() > 0){
                try {
                    org.json.simple.JSONObject eJson = (org.json.simple.JSONObject) jsonParser.parse(strEmployee);
                    String mobileNumber = (String)eJson.get("mobileNumber");
                    String email = (String)eJson.get("email");
                    
                    // update phone number
                    try {
                        Query q = session.createSQLQuery("update dh_user set phoneNumber=:mobileNumber where employeeId=:empId");
                        q.setParameter("mobileNumber", DataUtils.standardizeMobileNumber(mobileNumber));
                        q.setParameter("empId",  empId);
                        int result = q.executeUpdate();
                        LOGGER.info("Update phone number for email :" + email + " phone: " + DataUtils.standardizeMobileNumber(mobileNumber) + "--- result: " + result);
                       // session.getTransaction().commit();
                        //session.saveOrUpdate(dhUser);
                    } catch (Exception e) { //Tranh bi loi duplicate do du lieu test
                        LOGGER.error("Bi duplication EmployeeId:" + (Long) eJson.get("employeeId") + " " + e);
                    }
                } catch (ParseException ex) {
                    java.util.logging.Logger.getLogger(SynchonizeVHRBusinessData.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        transaction.commit();
        } catch (HibernateException ex) {
            transaction.rollback();
            LOGGER.error("Insert employee error: " + ex);
        } finally {
            if (session != null) {
                session.close();
            }
            LOGGER.info("-------------------------- Close:");
        }
    }
    
    private static void updateAllAvatarUser(){
        Session session = HibernateUtil.getSessionFactory().openSession();
        SQLQuery query2 = session.createSQLQuery(" SELECT employeeId  FROM  dh_vhr_employee");
        List list2 = new ArrayList();
        list2 = query2.list();
        Iterator it = list2.iterator();
        int empId;
        try{
        while (it.hasNext()) {
            empId = (int) it.next();
            HashMap map = new HashMap();
            map.put("employee_id", "" + empId);
            String strAvatarEmployee = TTNSQuery.getResultFromVHRParam(urlVHRAvatar, map);
            JSONParser jsonParser = new JSONParser();
            if (strAvatarEmployee != null && !strAvatarEmployee.isEmpty() && strAvatarEmployee.length() > 0) {
                org.json.simple.JSONObject jsonO = (org.json.simple.JSONObject) jsonParser.parse(strAvatarEmployee);
                String sAvatarImage = (String) jsonO.get("entity");
                long rsStatus = (Long) jsonO.get("status");
                if (rsStatus == 200) {
                    if (sAvatarImage.length() > 0) {
                        String avatarNormalUrl = Config.avatarNormalUrl;
                        String avatarBigUrl = Config.avatarBigUrl;
                        String avatarOrginalUrl = Config.avatarOrginalUrl;
                        String[] imageFile = sAvatarImage.split(";base64,");
                        String sMetaData = imageFile[0]; //data:image/jpeg
                        String sAvatarImageFinal = imageFile[1];
                        String[] sTypeImage = sMetaData.split("/");
                        String typeImage = sTypeImage[1];
                        if (sAvatarImageFinal != null && sAvatarImageFinal.length() > 0) {
                            BufferedImage img1 = decodeToImage(sAvatarImageFinal);
                            if (img1 != null) {
                                if (img1.getWidth() > 400) {
                                    double perFull = (double) 1024 / img1.getWidth();
                                    double perSmall = (double) 150 / img1.getWidth();
                                    resizeImage(img1, avatarNormalUrl + empId + ".jpg", perSmall); // anh small
                                    resizeImage(img1, avatarBigUrl + empId + ".jpg", perFull);// anh big
                                    resizeImage(img1, avatarOrginalUrl + empId + ".jpg", 1.0); // luu anh goc sau nay can thi dung lai
                                } else {
                                    resizeImage(img1, avatarNormalUrl + empId + ".jpg", 0.8); // anh small
                                    resizeImage(img1, avatarBigUrl + empId + ".jpg", 1.0);// anh big
                                    resizeImage(img1, avatarOrginalUrl + empId + ".jpg", 1.0); // luu anh goc sau nay can thi dung lai
                                }
                            }
                        }
                    }
                }
                LOGGER.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX - update avatar: " + empId);
            }
        }
    }catch (Exception ex) {
                LOGGER.error(SynchonizeVHRBusinessData.class.getName() + " " + ex);
    }
    finally{
            if (session != null) {
                session.close();
            }
        }
        
  }
    
    private static void deleteTempFileDownload() throws IOException{
        BasicDBObject tempFile = new BasicDBObject();
        tempFile.put("_id",1);
        tempFile.put("userId",1);
        tempFile.put("messageId", 1);
        tempFile.put("pathUrl", 1);
        tempFile.put("fileName", 1);
        tempFile.put("module", 1);
        tempFile.put("createdDate", 1);
        BasicDBObject project = new BasicDBObject("$project", tempFile);
        AggregationOutput output = MongodbConnection.getInstance().getUserTempFileDownload().aggregate(project);
        JSONParser jsonParser = new JSONParser();
        List<JSONObject> lstObjectDB = new ArrayList<>();
        for (DBObject result : output.results()) {
            try {
                JSONObject jsonObject = (JSONObject) jsonParser.parse(result.toString());
                String pathUrl = (String) jsonObject.get("pathUrl");
                Path path = Paths.get(pathUrl);
                try {
                    Files.delete(path);
                }catch (NoSuchFileException x) {
                    System.err.format("%s: no such" + " file or directory%n", path);
                }
            }catch (ParseException ex) {
               
            }
        }
    }
    
    private static void getMeetingVoffice(String employee){
        VofficeQuery.getAccessToken();
    }
    
    private static void updateDhUser(org.json.simple.JSONArray jContent, long timeUpdate, String type) {
        LOGGER.info("Start update user ghr--------");
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        SimpleDateFormat sdfDate ;
         if(type == "vhr")
            sdfDate = new SimpleDateFormat("yyyy-MM-dd");
        else
            sdfDate = new SimpleDateFormat("dd/MM/yyyy");
        String avatarUrl = Config.avatarUrl;
        String fullAvatarUrl = Config.fullAvatarUrl;

        try {
            byte defaultValue = 0;
            byte defaultValue1 = 1;
            byte defaultValue2 = 2;
            for (Object object : jContent) {
                org.json.simple.JSONObject eJson = (org.json.simple.JSONObject) object;
                String employeeCode1 = String.valueOf( eJson.get("employeeCode"));
                if("180073".equals(employeeCode1)){
                    LOGGER.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX - da tim thay employeeCode");
                }
                if ((Long) eJson.get("organizationId") != null) {
                        Long orgId = (Long) eJson.get("organizationId");
                        DhVhrOrganization orgs = (DhVhrOrganization) TTNSQuery.getOrgInfo(DataUtils.convertLongToInt(orgId,0));
                        if(orgs == null)
                            continue;
                }
                LOGGER.info("Update dh_User with employeeCode: " + employeeCode1 + "(" + (Long) eJson.get("employeeId") + ")" + "--orgId:" + (Long) eJson.get("organizationId"));
                List list2 = new ArrayList();
                int empId = -111;
                try {
                    SQLQuery query2 = session.createSQLQuery(" SELECT id FROM  dh_user as e  where e.employeeId = :employeeId");
                    query2.setParameter("employeeId", DataUtils.convertLongToInt((Long) eJson.get("employeeId"), 0));
                    list2 = query2.list();
                    Iterator it = list2.iterator();
                    while (it.hasNext()) {
                        empId = (int) it.next();
                    }
                } catch (RuntimeException e) {
                    LOGGER.error("Khong ton tai Id nao co EmployId = " + (Long) eJson.get("employeeId") + " " + e);
                }
                
                if (empId != -111) { //Phai lay duoc Id thi moi chien
                    DhUser dhUser = new DhUser();
                    dhUser.setId(empId);
                    int status = DataUtils.convertLongToInt((Long) eJson.get("status"), 0);

                    dhUser.setEmployeeId(DataUtils.convertLongToInt((Long) eJson.get("employeeId"), 0));
                    String employeeCode = String.valueOf( eJson.get("employeeCode"));
                    if (employeeCode != null) {
                        dhUser.setEmployeeCode(employeeCode);
                    } else {
                        dhUser.setEmployeeCode("-1");
                    }
                    String lastName = "";
                    String fullName = fullName = (String) eJson.get("fullName");
                    if ((String) eJson.get("fullName") != null) {
                        dhUser.setFullname((String) eJson.get("fullName"));
                        dhUser.setFullnameAscii(LocDauTiengVietUtl.perform((String) eJson.get("fullName")));
                        String[] fName = fullName.split(" ");
                        lastName = fName[fName.length - 1];
                        dhUser.setLastname(lastName);
                    } else {
                        dhUser.setFullname((String) eJson.get("employeeCode"));
                        dhUser.setFullnameAscii((String) eJson.get("employeeCode"));
                        dhUser.setLastname((String) eJson.get("employeeCode"));
                    }
                    String email = String.valueOf( eJson.get("email"));

                    if (email != null) {
                        dhUser.setEmail(email);
                    } else {
                        dhUser.setEmail(" "); // null thi add " "
                    }
                    if (String.valueOf( eJson.get("mobileNumber")) != null) {
                        dhUser.setPhoneNumber(DataUtils.standardizeMobileNumber(String.valueOf( eJson.get("mobileNumber"))));
                    }
                    if ((Long) eJson.get("gender") != null) {
                        int gender = DataUtils.convertLongToInt((Long) eJson.get("gender"), -1);
                        if (gender == 1) {
                            dhUser.setSex(1);
                        } else {
                            dhUser.setSex(2);
                        }
                    } else {
                        dhUser.setSex(-1);
                    }
                    if (type == "vhr") {
                        if ((Long) eJson.get("dateOfBirth") != null) {
                            Date dateOfBirth;
                            dateOfBirth = sdfDate.parse(String.valueOf(convertTimeStamptoDateTime((Long) eJson.get("dateOfBirth"))));
                            dhUser.setBirthday(dateOfBirth);
                        }
                    } else if (eJson.containsKey("dateOfBirth")) {
                        Date dateOfBirth = sdfDate.parse((String) eJson.get("dateOfBirth"));
                        dhUser.setBirthday(dateOfBirth);
                    }
                    String username1 = null; // username = phan dau email
                    if (email != null) {
                        if (email.contains("@viettel.com.vn")) {
                            String[] listEmail = email.split("@");
                            username1 = listEmail[0];

                        } else if (employeeCode != null) {
                            username1 = (String) eJson.get("employeeCode");
                        } else {
                            username1 = "-1";
                        }
                    } else if (employeeCode != null) {
                        username1 = employeeCode;
                    } else {
                        username1 = "-1";
                    }
                    dhUser.setAvatar(avatarUrl + (Long) eJson.get("employeeId") + ".jpg");
                    dhUser.setAvatarSmall(avatarUrl + (Long) eJson.get("employeeId") + ".jpg");
                    dhUser.setAvatar90(avatarUrl + (Long) eJson.get("employeeId") + ".jpg");
                    dhUser.setAvatar150(avatarUrl + (Long) eJson.get("employeeId") + ".jpg");
                    dhUser.setAvatarFull(fullAvatarUrl + (Long) eJson.get("employeeId") + ".jpg"); // HuyVT2 tam gem lai de chay phan dong bo du lieu truoc
                    dhUser.setUsername(username1);
                    dhUser.setMarrial(0);
                    dhUser.setMarrialWith(0);
                    dhUser.setType(defaultValue);
                    dhUser.setEmailActivation(true);
                    Date date = new Date();
                    dhUser.setRegisterDate(date);
                    dhUser.setLastVisitDate(date);
                    dhUser.setServer(0);
                    dhUser.setPrivacyViewProfile(defaultValue);
                    dhUser.setPrivacyViewOnlineStatus(defaultValue);
                    dhUser.setPrivacyViewStatusMsg(defaultValue);
                    dhUser.setPrivacyViewAvatar(defaultValue);
                    //dhUser.setPrivacyViewCommentLike(defaultValue2);
                    dhUser.setPrivacyPostProfile(defaultValue);
                    dhUser.setPrivacyComment(defaultValue2);
                    dhUser.setPrivacyReceiveMessage(defaultValue);
                    dhUser.setPrivacyVisitHomePage(defaultValue1);
                    dhUser.setPrivacyShowPreview(true);
                    dhUser.setPrivacyAllowFindWifi(true);
                    //dhUser.setPrivacyAllowFindViaEmail(true);
                    //dhUser.setPrivacyAllowFindViaFacebook(true); 
                    dhUser.setPluginUrlToPhoto(false);
                    dhUser.setPluginPhotoZoom(false);
                    dhUser.setBrowser(false);
                    //dhUser.setOnXu();
                    dhUser.setOnline(defaultValue);
                    dhUser.setChatServer(0);
                    dhUser.setApplicationState(1);
                    dhUser.setApplicationCurrentStateTime(DataUtils.getSysTimestamp());
                    dhUser.setLastDevice(3);
                    dhUser.setPlatform(defaultValue);
                    //dhUser.setCallHasRingbackTone();
                    //dhUser.setPushNotiFriendRequest(); 
                    //dhUser.setFacebookUserId();
                    //dhUser.setProvince();
                    dhUser.setPlatformVersion("");
                    dhUser.setAppVersion("");
                    dhUser.setScreenSize("");
                    dhUser.setDeviceName("");
                    dhUser.setAudioCodecs("");
                    dhUser.setCountryCode("84"); //Tam thoi fix VN 84
                    dhUser.setRegisterIp("10.60.105.4");
                    dhUser.setModified(DataUtils.getSysTimestamp());
                    dhUser.setLastSyncTime(timeUpdate);
                    if (status == 1) { //update du lieu
                        try {
                            session.saveOrUpdate(dhUser);
                        } catch (Exception e) { //Tranh bi loi duplicate do du lieu test
                            LOGGER.error("Bi duplication EmployeeId:" + (Long) eJson.get("employeeId") + " " + e);
                        }
                    } else if (status != 0) { //xoa khoi dhUser
                        session.delete(dhUser);
                    }
                    LOGGER.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX - update user: " + empId + " employeeCode : " + employeeCode + " username: " + username1);
                }else{
                    // neu chua co trong bang dh_user thi check trang thai để insert
                    int status = DataUtils.convertLongToInt((Long) eJson.get("status"), 0);
                    if(status == 1){// trang thai lam viec
                        insertDhUser(jContent, timeUpdate, type);
                    }
                }
            }
            transaction.commit();
        } catch (java.text.ParseException | HibernateException ex) {
            transaction.rollback();
            LOGGER.error("Insert employee error: " + ex);
        } finally {
            if (session != null) {
                session.close();
            }
            LOGGER.info("-------------------------- Close:");
        }
    }

    
    private static void insertDhUser(org.json.simple.JSONArray jContent, long timeUpdate, String type) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        //convert chuan format date de insert vao CSDL 
        SimpleDateFormat sdfDate;
        if(type == "vhr")
            sdfDate = new SimpleDateFormat("yyyy-MM-dd");
        else
            sdfDate = new SimpleDateFormat("dd/MM/yyyy");
        String avatarUrl = Config.avatarUrl;
        String fullAvatarUrl = Config.fullAvatarUrl;
        try {
            byte defaultValue = 0;
            byte defaultValue1 = 1;
            byte defaultValue2 = 2;
            for (Object object : jContent) {
                
                org.json.simple.JSONObject eJson = (org.json.simple.JSONObject) object;
                //System.out.println(eJson.toString() + "\n");
                String employeeCode1 = String.valueOf(eJson.get("employeeCode"));
                String eId =  eJson.get("employeeId").toString();
                if("180073".equals(employeeCode1)){
                    LOGGER.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX - da tim thay employeeCode");
                }
//                LOGGER.info("Synchronize dh_User with employeeCode: " + (String) eJson.get("employeeCode") + "(" + (Long) eJson.get("employeeId") + ")");
                if ((Long) eJson.get("organizationId") != null) {
                        Long orgId = (Long) eJson.get("organizationId");
                        DhVhrOrganization orgs = (DhVhrOrganization) TTNSQuery.getOrgInfo(DataUtils.convertLongToInt(orgId,0));
                        if(orgs == null)
                            continue;
                }
                List list2 = new ArrayList();
                int empId = -111;
                try {
                    SQLQuery query2 = session.createSQLQuery(" SELECT id FROM  dh_user as e  where e.employeeId = :employeeId");
                    query2.setParameter("employeeId", DataUtils.convertLongToInt((Long) eJson.get("employeeId"), 0));
                    list2 = query2.list();
                    Iterator it = list2.iterator();
                    while (it.hasNext()) {
                        empId = (int) it.next();
                    }
                } catch (RuntimeException e) {
                    LOGGER.error("Khong ton tai Id nao co EmployId = " + (Long) eJson.get("employeeId") + " " + e);
                    return;
                }
                DhUser dhUser = new DhUser();
                if (empId != -111) {
                    dhUser.setId(empId);
                }
                dhUser.setEmployeeId(DataUtils.convertLongToInt((Long) eJson.get("employeeId"), 0));
                String employeeCode = String.valueOf(eJson.get("employeeCode"));
                if (employeeCode != null) {
                    dhUser.setEmployeeCode(employeeCode);
                } else {
                    dhUser.setEmployeeCode("-1");
                }
                String lastName = "";
                String fullName = fullName = (String) eJson.get("fullName");
                if ((String) eJson.get("fullName") != null) {
                    dhUser.setFullname((String) eJson.get("fullName"));
                    dhUser.setFullnameAscii(LocDauTiengVietUtl.perform((String) eJson.get("fullName")));
                    String[] fName = fullName.split(" ");
                    lastName = fName[fName.length - 1];
                    dhUser.setLastname(lastName);
                } else {
                    dhUser.setFullname((String) eJson.get("employeeCode"));
                    dhUser.setFullnameAscii((String) eJson.get("employeeCode"));
                    dhUser.setLastname((String) eJson.get("employeeCode"));
                }
                String email = String.valueOf(eJson.get("email"));
                if (email != null) {
                    dhUser.setEmail(email);
                } else {
                    dhUser.setEmail(" "); // null thi add " "
                }

                if (type == "vhr") {
                    if ((String) eJson.get("mobileNumber") != null) {

                        dhUser.setPhoneNumber(DataUtils.standardizeMobileNumber((String) eJson.get("mobileNumber")));

                        //dhUser.setPhoneNumber((String) eJson.get("mobileNumber"));
                    }
                } else {
                    if (eJson.containsKey("mobileNumber")){
                        dhUser.setPhoneNumber( String.valueOf(eJson.get("mobileNumber")));
                    }
                }
                if ((Long) eJson.get("gender") != null) {
                    int gender = DataUtils.convertLongToInt((Long) eJson.get("gender"), -1);
                    switch (gender) {
                        case 1:
                            dhUser.setSex(1);
                            break;
                        case 2:
                            dhUser.setSex(2);
                            break;
                        default:
                            dhUser.setSex(-1);
                            break;
                    }

                } else {
                    dhUser.setSex(-1);
                }
                if (type == "vhr") {
                    if ((Long) eJson.get("dateOfBirth") != null) {
                        Date dateOfBirth;
                        dateOfBirth = sdfDate.parse(String.valueOf(convertTimeStamptoDateTime((Long) eJson.get("dateOfBirth"))));
                        dhUser.setBirthday(dateOfBirth);
                    }
                } else {
                    if (eJson.containsKey("dateOfBirth") ) {
                        Date dateOfBirth = sdfDate.parse((String) eJson.get("dateOfBirth"));
                        dhUser.setBirthday(dateOfBirth);
                    }
                }
                String username1 = null; // username = phan dau email
                if (email != null) {
                    if (email.contains("@viettel.com.vn") || email.contains("@viettelpost.com.vn")) {
                        String[] listEmail = email.split("@");
                        username1 = listEmail[0];

                    } else if (employeeCode != null) {
                        username1 = String.valueOf(eJson.get("employeeCode"));
                    } else {
                        username1 = "-1";
                    }
                } else if (employeeCode != null) {
                    username1 = String.valueOf(eJson.get("employeeCode"));
                } else {
                    username1 = "-1";
                }
                dhUser.setAvatar(avatarUrl + (Long) eJson.get("employeeId") + ".jpg");
                dhUser.setAvatarSmall(avatarUrl + (Long) eJson.get("employeeId") + ".jpg");
                dhUser.setAvatar90(avatarUrl + (Long) eJson.get("employeeId") + ".jpg");
                dhUser.setAvatar150(avatarUrl + (Long) eJson.get("employeeId") + ".jpg");
                dhUser.setAvatarFull(fullAvatarUrl + (Long) eJson.get("employeeId") + ".jpg"); // HuyVT2 tam gem lai de chay phan dong bo du lieu truoc
                dhUser.setUsername(username1);
                dhUser.setMarrial(0);
                dhUser.setMarrialWith(0);
                dhUser.setType(defaultValue);
                dhUser.setEmailActivation(true);
                Date date = new Date();
                dhUser.setRegisterDate(date);
                dhUser.setLastVisitDate(date);
                dhUser.setServer(0);
                dhUser.setPrivacyViewProfile(defaultValue);
                dhUser.setPrivacyViewOnlineStatus(defaultValue);
                dhUser.setPrivacyViewStatusMsg(defaultValue);
                dhUser.setPrivacyViewAvatar(defaultValue);
                //dhUser.setPrivacyViewCommentLike(defaultValue2);
                dhUser.setPrivacyPostProfile(defaultValue);
                dhUser.setPrivacyComment(defaultValue2);
                dhUser.setPrivacyReceiveMessage(defaultValue);
                dhUser.setPrivacyVisitHomePage(defaultValue1);
                dhUser.setPrivacyShowPreview(true);
                dhUser.setPrivacyAllowFindWifi(true);
                //dhUser.setPrivacyAllowFindViaEmail(true);
                //dhUser.setPrivacyAllowFindViaFacebook(true); 
                dhUser.setPluginUrlToPhoto(false);
                dhUser.setPluginPhotoZoom(false);
                dhUser.setBrowser(false);
                //dhUser.setOnXu();
                dhUser.setOnline(defaultValue);
                dhUser.setChatServer(0);
                dhUser.setApplicationState(1);
                dhUser.setApplicationCurrentStateTime(DataUtils.getSysTimestamp());
                dhUser.setLastDevice(3);
                dhUser.setPlatform(defaultValue);
                //dhUser.setCallHasRingbackTone();
                //dhUser.setPushNotiFriendRequest(); 
                //dhUser.setFacebookUserId();
                //dhUser.setProvince();
                dhUser.setPlatformVersion("");
                dhUser.setAppVersion("");
                dhUser.setScreenSize("");
                dhUser.setDeviceName("");
                dhUser.setAudioCodecs("");
                if(type == "vhr")
                    dhUser.setCountryCode("84"); //Tam thoi fix VN 84
                else
                    dhUser.setCountryCode("");
                dhUser.setRegisterIp("10.60.105.4");
                dhUser.setModified(DataUtils.getSysTimestamp());
                dhUser.setLastSyncTime(timeUpdate);

                try {
                    session.saveOrUpdate(dhUser);
                } catch (Exception e) { //Tranh bi loi duplicate do du lieu test
                    LOGGER.error("Bi duplication EmployeeId:" + (Long) eJson.get("employeeId") + " " + e);
                }
                LOGGER.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX - INSERT user: " + empId + " employeeCode : " + employeeCode + " username: " + username1);
            }
            transaction.commit();
        } catch (java.text.ParseException | HibernateException ex ) {
            transaction.rollback();
            LOGGER.error("Insert employee error: " + ex);
        }catch(Exception ex){
            LOGGER.error("Insert employee error: " + ex);
        }finally {
            if (session != null) {
                session.close();
            }
            LOGGER.info("-------------------------- Close:");
        }
    }
}
