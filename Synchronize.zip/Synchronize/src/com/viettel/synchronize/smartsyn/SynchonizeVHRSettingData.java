package com.viettel.synchronize.smartsyn;

import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.WriteResult;
import org.joda.time.DateTime;
import com.viettel.synchronize.common.Config;
import com.viettel.synchronize.common.Constant;
import com.viettel.synchronize.util.HibernateUtil;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.json.simple.parser.JSONParser;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import com.viettel.synchronize.util.DataUtils;
import com.viettel.synchronize.util.MongodbConnection;
import java.util.HashMap;
import java.util.logging.Level;
import org.json.simple.parser.ParseException;

/**
 *
 * @author HuyVT2
 */
public class SynchonizeVHRSettingData implements Job {

    private static final Logger LOGGER = Logger.getLogger(SynchonizeVHRSettingData.class);
    private static final String URLWSWORKDAYTYPE = "api/v1/timeKeeping/workDayType";
    private static final String URLWSLISTWORKPLACE = "api/v1/register/inout/workplace?";
    private static final String URLWSLISTREASONOUT = "api/v1/register/inout/reason?";
    private static final String URLWSLISTWIFIDEVICE = "api/v1/timeKeeping/device?";
    private static final String URLVHREMPLOYEE = "api/v1/employee?";
    private static final String URLVHRORG = "api/v1/organization?";

    @Override
    public void execute(JobExecutionContext context)
            throws JobExecutionException {
        LOGGER.info("Proccesing Syschonize TTNS ... ");
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
//            syncWorkDayType(URLWSWORKDAYTYPE);
//            syncOrganizationVHR();
            LOGGER.info("Starting Synchronize ... ");
            Config.loadConfig();
            LOGGER.info("End Synchronize ... ");
            LOGGER.info("Start syncWorkDayType ... ");
            SynchonizeVHRSettingData.syncWorkDayType(URLWSWORKDAYTYPE);
            LOGGER.info("End syncWorkDayType ... ");

            LOGGER.info("Start syncListWorkPlace ... ");
            SynchonizeVHRSettingData.syncListWorkPlace(URLWSLISTWORKPLACE);
            LOGGER.info("End syncListWorkPlace ... ");

            LOGGER.info("Start syncListReasonOut ... ");
            SynchonizeVHRSettingData.syncListReasonOut(URLWSLISTREASONOUT);
            LOGGER.info("End syncListReasonOut ... ");

            LOGGER.info("Start syncListWifiDeviceFirstTime ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceFirstTime(urlWSListWifiDevice);
            LOGGER.info("End syncListWifiDeviceFirstTime ... ");

//            LOGGER.info("Start syncListWifiDeviceInsert ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceInsert(URLWSLISTWIFIDEVICE);
//            LOGGER.info("End syncListWifiDeviceInsert ... ");
//
//            LOGGER.info("Start syncListWifiDeviceUpdate ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceUpdate(URLWSLISTWIFIDEVICE);
//            LOGGER.info("End syncListWifiDeviceUpdate ... ");
//
//            LOGGER.info("Start syncListWifiDeviceDelete ... ");
//            SynchonizeVHRSettingData.syncListWifiDeviceDelete(URLWSLISTWIFIDEVICE);
//            LOGGER.info("End syncListWifiDeviceDelete ... ");

        } catch (Exception e) {
            //rollback .....
            LOGGER.info("Error occur: " + e);
        } finally {
            if (session != null) {
                session.close();
            }
            //StatisticManager.getInstance().getStatisticModel().incNoTransactionMySQL();
        }
    }

    public static DateTime convertTimeStamptoDateTime(long time) {
        DateTime date = new DateTime(time);
        return date;

    }

    public static int pushWifiDeviceToDB(org.json.simple.JSONArray jsonArray, String method) {

        List<BasicDBObject> lstWifiDevices = new ArrayList<>();
        List<BasicDBObject> lstDeleteWifiDevices = new ArrayList<>();
        List<Long> lstWifiDeviceIds = new ArrayList<>();
        WriteResult dbc = null;
//        WriteResult dbc1 = null;
        java.util.Date currentDate = new java.util.Date();
        long sysDate = currentDate.getTime() / 1000;
        switch (method) {
            case "ALL":
                for (int i = 0; i < jsonArray.size(); i++) {
                    org.json.simple.JSONObject jo = (org.json.simple.JSONObject) jsonArray.get(i);
                    Long timekeepingDeviceId = (Long) jo.get("timekeepingDeviceId");
                    String name = (String) jo.get("name");
                    String address = (String) jo.get("address");
                    String macAddress = (String) jo.get("macAddress");
                    String serialNumber = (String) jo.get("serialNumber");
                    Long type = (Long) jo.get("type");
                    Long createTime = (Long) jo.get("createTime");
                    BasicDBObject wifiDevice = new BasicDBObject();
                    wifiDevice.put("_id", DataUtils.getVHRWifiDeviceSequense());
                    wifiDevice.put("timekeepingDeviceId", timekeepingDeviceId);
                    wifiDevice.put("name", name);
                    wifiDevice.put("address", address);
                    wifiDevice.put("macAddress", macAddress);
                    wifiDevice.put("serialNumber", serialNumber);
                    wifiDevice.put("type", type);
                    wifiDevice.put("createTime", createTime);
                    wifiDevice.put("lastUpdateTimeInSO", sysDate);
                    wifiDevice.put("soType", "ALL");
                    lstWifiDevices.add(wifiDevice);
                }
                if (lstWifiDevices != null && lstWifiDevices.size() > 0) {
                    dbc = MongodbConnection.getInstance().getVHRWifiDeviceConnection().insert(lstWifiDevices);
                }
                break;
            case "DELETE": // thay doi trang thai cac ban ghi co ID lay ve thanh delete
                for (int i = 0; i < jsonArray.size(); i++) {
                    BasicDBObject DeletedwifiDevice = new BasicDBObject();
                    DeletedwifiDevice.put("_id", DataUtils.getVHRWifiDeviceSequense());
                    Long timekeepingDeviceId = (Long) jsonArray.get(i);
                    DeletedwifiDevice.put("timekeepingDeviceId", timekeepingDeviceId);
                    DeletedwifiDevice.put("soType", "DELETE");
                    DeletedwifiDevice.put("lastUpdateTimeInSO", sysDate);
                    lstWifiDeviceIds.add(timekeepingDeviceId);
                    lstDeleteWifiDevices.add(DeletedwifiDevice);
                }
                BasicDBObject query = new BasicDBObject();
                query.put("timekeepingDeviceId", new BasicDBObject("$in", lstWifiDeviceIds));
                /*dbc1 = */
                MongodbConnection.getInstance().getVHRDeleteWifiDeviceConnection().insert(lstDeleteWifiDevices);
                dbc = MongodbConnection.getInstance().getVHRWifiDeviceConnection().remove(query);
                break;
            case "INSERT": // insert moi vao DB
                for (int i = 0; i < jsonArray.size(); i++) {
                    org.json.simple.JSONObject jo = (org.json.simple.JSONObject) jsonArray.get(i);
                    Long timekeepingDeviceId = (Long) jo.get("timekeepingDeviceId");
                    String name = (String) jo.get("name");
                    String address = (String) jo.get("address");
                    String macAddress = (String) jo.get("macAddress");
                    String serialNumber = (String) jo.get("serialNumber");
                    Long type = (Long) jo.get("type");
                    Long createTime = (Long) jo.get("createTime");
                    BasicDBObject wifiDevice = new BasicDBObject();
                    wifiDevice.put("_id", DataUtils.getVHRWifiDeviceSequense());
                    wifiDevice.put("timekeepingDeviceId", timekeepingDeviceId);
                    wifiDevice.put("name", name);
                    wifiDevice.put("address", address);
                    wifiDevice.put("macAddress", macAddress);
                    wifiDevice.put("serialNumber", serialNumber);
                    wifiDevice.put("type", type);
                    wifiDevice.put("createTime", createTime);
                    wifiDevice.put("lastUpdateTimeInSO", sysDate);
                    wifiDevice.put("soType", "INSERT");
                    lstWifiDevices.add(wifiDevice);
                }
                dbc = MongodbConnection.getInstance().getVHRWifiDeviceConnection().insert(lstWifiDevices);
                break;
            case "UPDATE": // update thong tin
                for (int i = 0; i < jsonArray.size(); i++) {
                    org.json.simple.JSONObject jo = (org.json.simple.JSONObject) jsonArray.get(i);
                    Long timekeepingDeviceId = (Long) jo.get("timekeepingDeviceId");
                    String name = (String) jo.get("name");
                    String address = (String) jo.get("address");
                    String macAddress = (String) jo.get("macAddress");
                    String serialNumber = (String) jo.get("serialNumber");
                    Long type = (Long) jo.get("type");
                    Long createTime = (Long) jo.get("createTime");
                    BasicDBObject wifiDevice = new BasicDBObject();
                    wifiDevice.put("_id", DataUtils.getVHRWifiDeviceSequense());
                    wifiDevice.put("timekeepingDeviceId", timekeepingDeviceId);
                    wifiDevice.put("name", name);
                    wifiDevice.put("address", address);
                    wifiDevice.put("macAddress", macAddress);
                    wifiDevice.put("serialNumber", serialNumber);
                    wifiDevice.put("type", type);
                    wifiDevice.put("createTime", createTime);
                    wifiDevice.put("lastUpdateTimeInSO", sysDate);
                    wifiDevice.put("soType", "UPDATE");
                    lstWifiDevices.add(wifiDevice);
                    lstWifiDeviceIds.add(timekeepingDeviceId);
                }
                //Step 1: Xoa list
                BasicDBObject query1 = new BasicDBObject();
                query1.put("timekeepingDeviceId", new BasicDBObject("$in", lstWifiDeviceIds));
                /*dbc1 = */
                MongodbConnection.getInstance().getVHRWifiDeviceConnection().remove(query1);
                // Step 2: Insert list
                dbc = MongodbConnection.getInstance().getVHRWifiDeviceConnection().insert(lstWifiDevices);
                break;
            default:
                break;
        }
        if (dbc != null) {
            // Danh dau thoi gian da doc 
            BasicDBObject set = new BasicDBObject();
            BasicDBObject searchQuery = new BasicDBObject().append("_id", "VHR");
            set.append("lastSyncTime", sysDate);
            BasicDBObject update = new BasicDBObject();
            update.put("$set", set);
            MongodbConnection.getInstance().getVHRTimeSyncConnection().update(searchQuery, update);
        }
        return dbc == null ? 0 : dbc.getN();

    }

//Mau ban tin tra ve cua TTNS - 09092016
//"stt":20,
//"dataSource":"CROWNE",
//"originId":22,
//"workPlaceId":17,
//"code":null,
//"name":"TANG 20",
//"parentId":null,
//"address":null,
//"createUser":null,
//"createDate":1425357179000,
//"modifyUser":null,
//"modifyDate":1427168505000
    public static int pushWorkPlaceToDB(org.json.simple.JSONArray jsonArray) {

        List<BasicDBObject> lstWorkPlace = new ArrayList<>();
        for (int i = 0; i < jsonArray.size(); i++) {
            org.json.simple.JSONObject jo = (org.json.simple.JSONObject) jsonArray.get(i);
            Long stt = (Long) jo.get("stt");
            String dataSource = (String) jo.get("dataSource");
            Long originId = (Long) jo.get("originId");
            Long workPlaceId = (Long) jo.get("workPlaceId");
            String code = (String) jo.get("code");
            String name = (String) jo.get("name");
            Long parentId = (Long) jo.get("parentId");
            String address = (String) jo.get("address");
            String createUser = (String) jo.get("createUser");
            Long createDate = (Long) jo.get("createDate");
            String modifyUser = (String) jo.get("modifyUser");
            Long modifyDate = (Long) jo.get("modifyDate");
            BasicDBObject workPlace = new BasicDBObject();
            workPlace.put("_id", DataUtils.getVHRWifiDeviceSequense());
            workPlace.put("stt", stt);
            workPlace.put("dataSource", dataSource);
            workPlace.put("originId", originId);
            workPlace.put("workPlaceId", workPlaceId);
            workPlace.put("code", code);
            workPlace.put("name", name);
            workPlace.put("parentId", parentId);
            workPlace.put("address", address);
            workPlace.put("createUser", createUser);
            workPlace.put("createDate", createDate);
            workPlace.put("modifyUser", modifyUser);
            workPlace.put("modifyDate", modifyDate);
            lstWorkPlace.add(workPlace);
        }
        WriteResult dbc = MongodbConnection.getInstance().getVHRWorkPlaceConnection().insert(lstWorkPlace);
        return dbc.getN();

    }

//    {
//    "reasonOutId": 261,
//    "code": "Test",
//    "name": "something",
//    "workdayTypeId": 458,
//    "timeHoursStart": null,
//    "timeMinuteStart": null,
//    "timeHoursEnd": null,
//    "timeMinuteEnd": null,
//    "workHours": 5,
//    "createdTime": null
//  }
    public static int pushReasonOutToDB(org.json.simple.JSONArray jsonArray) {

        List<BasicDBObject> lstReasonOut = new ArrayList<>();
        for (int i = 0; i < jsonArray.size(); i++) {
            org.json.simple.JSONObject jo = (org.json.simple.JSONObject) jsonArray.get(i);
            Long reasonOutId = (Long) jo.get("reasonOutId");
            String code = (String) jo.get("code");
            String name = (String) jo.get("name");
            Long workdayTypeId = (Long) jo.get("workdayTypeId");
            Long timeHoursStart = (Long) jo.get("timeHoursStart");
            Long timeMinuteStart = (Long) jo.get("timeMinuteStart");
            Long timeHoursEnd = (Long) jo.get("timeHoursEnd");
            Long timeMinuteEnd = (Long) jo.get("timeMinuteEnd");
            Long workHours = (Long) jo.get("workHours");
            Long createdTime = (Long) jo.get("createdTime");

            BasicDBObject reasonOut = new BasicDBObject();
            reasonOut.put("_id", DataUtils.getVHRReasonOutSequense());
            reasonOut.put("reasonOutId", reasonOutId);
            reasonOut.put("code", code);
            reasonOut.put("name", name);
            reasonOut.put("workdayTypeId", workdayTypeId);
            reasonOut.put("timeHoursStart", timeHoursStart);
            reasonOut.put("timeMinuteStart", timeMinuteStart);
            reasonOut.put("timeHoursEnd", timeHoursEnd);
            reasonOut.put("timeMinuteEnd", timeMinuteEnd);
            reasonOut.put("workHours", workHours);
            reasonOut.put("createdTime", createdTime);
            lstReasonOut.add(reasonOut);
        }
        WriteResult dbc = MongodbConnection.getInstance().getVHRReasonOutConnection().insert(lstReasonOut);
        return dbc.getN();

    }

    public static void deleteOldData(String sType) {

        BasicDBObject document = new BasicDBObject();

        if (null != sType) switch (sType) {
            case "ro":
                MongodbConnection.getInstance().getVHRReasonOutConnection().remove(document);
                break;
            case "wdt":
                MongodbConnection.getInstance().getVHRWorkDayTypeConnection().remove(document);
                break;
            case "wp":
                MongodbConnection.getInstance().getVHRWorkPlaceConnection().remove(document);
                break;
            case "wifiF":
                MongodbConnection.getInstance().getVHRWifiDeviceConnection().remove(document);
                break;
            default:
                break;
        }
    }

    public static int pushWorkDayTypeToDB(org.json.simple.JSONArray jsonArray) {
        List<BasicDBObject> lstWorkDayType = new ArrayList<>();
        for (int i = 0; i < jsonArray.size(); i++) {
            org.json.simple.JSONObject jo = (org.json.simple.JSONObject) jsonArray.get(i);
            Long workdayTypeId = (Long) jo.get("workdayTypeId");
            String code = (String) jo.get("code");
            String name = (String) jo.get("name");
            String description = (String) jo.get("description");
            Long isActive = (Long) jo.get("isActive");
            double insuranceTypeId = -100;
            if (jo.get("insuranceTypeId") != null) {
                insuranceTypeId = (double) jo.get("insuranceTypeId");
            }

            Long affairMode = -100l;
            if (jo.get("affairMode") != null) {
                affairMode = (Long) jo.get("affairMode");
            }

            Long shiftMode = -100l;
            if (jo.get("shiftMode") != null) {
                shiftMode = (Long) jo.get("shiftMode");
            }
            Long overtimeMode = (Long) jo.get("overtimeMode");
            Long isReturn = (Long) jo.get("isReturn");
            BasicDBObject workDayType = new BasicDBObject();
            workDayType.put("_id", DataUtils.getVHRWorkDayTypeSequense());
            workDayType.put("workdayTypeId", workdayTypeId);
            workDayType.put("code", code);
            workDayType.put("name", name);
            workDayType.put("description", description);
            workDayType.put("isActive", isActive);
            workDayType.put("insuranceTypeId", insuranceTypeId);
            workDayType.put("affairMode", affairMode);
            workDayType.put("shiftMode", shiftMode);
            workDayType.put("overtimeMode", overtimeMode);
            workDayType.put("isReturn", isReturn);
            lstWorkDayType.add(workDayType);
        }
        WriteResult dbc = MongodbConnection.getInstance().getVHRWorkDayTypeConnection().insert(lstWorkDayType);
        return dbc.getN();

    }

    //    06092016_HuyVT2: Lay thong tin noi den
    public static int syncListReasonOut(String urlReasonOut) {
        HashMap map = new HashMap();
        map.put("type", "ALL");
        map.put("syncTime", DataUtils.getSysTimestamp().toString());
        String strReasonOut = TTNSQuery.getResultFromVHRParam(urlReasonOut, map);
        JSONParser jsonParser = new JSONParser();
        int i = -1;
        if (strReasonOut != null && !strReasonOut.isEmpty()) {
            try {
                org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) jsonParser.parse(strReasonOut);
                System.out.println(jsonArray);
                // push to DB
                deleteOldData("ro");
                i = pushReasonOutToDB(jsonArray);
            } catch (ParseException ex) {
                java.util.logging.Logger.getLogger(SynchonizeVHRSettingData.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return i;

    }

//    06092016_HuyVT2: Lay thong tin noi den
    public static int syncListWorkPlace(String urlWSWorkPlace) throws org.json.simple.parser.ParseException {
        HashMap map = new HashMap();
        map.put("type", "ALL");
        map.put("syncTime", DataUtils.getSysTimestamp().toString());
        String strWorkPlace = TTNSQuery.getResultFromVHRParam(urlWSWorkPlace, map);
        LOGGER.info("Result syncListWorkPlace : " + strWorkPlace);
        JSONParser jsonParser = new JSONParser();
        int i = -1;
        if (strWorkPlace != null && !strWorkPlace.isEmpty()) {
            org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) jsonParser.parse(strWorkPlace);
            System.out.println(jsonArray);
            // push to DB
            deleteOldData("wp");
            i = pushWorkPlaceToDB(jsonArray);
        }

        return i;

    }

    public static int syncListWifiDeviceDelete(String urlWSWifiDevice) throws org.json.simple.parser.ParseException {
        HashMap map = new HashMap();
        map.put("type", "DELETE");
        long timesync = getLastSyncTimeVHR(Constant.SETTING) * 1000;
        map.put("syncTime", String.valueOf(timesync));
//        map.put("syncTime", DataUtils.getSysTimestamp().toString());
        String strWifiDevice = TTNSQuery.getResultFromVHRParam(urlWSWifiDevice, map);
        JSONParser jsonParser = new JSONParser();
        int i = -1;
        if (strWifiDevice != null && !strWifiDevice.isEmpty()) {
            org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) jsonParser.parse(strWifiDevice);
            System.out.println(jsonArray);
            i = pushWifiDeviceToDB(jsonArray, "DELETE");
        }
        return i;
    }

    public static int syncListWifiDeviceUpdate(String urlWSWifiDevice) throws org.json.simple.parser.ParseException {
        HashMap map = new HashMap();
        map.put("type", "UPDATE");
        long timesync = getLastSyncTimeVHR(Constant.SETTING) * 1000;
        map.put("syncTime", String.valueOf(timesync));
//        map.put("syncTime", DataUtils.getSysTimestamp().toString());
        String strWifiDevice = TTNSQuery.getResultFromVHRParam(urlWSWifiDevice, map);
        JSONParser jsonParser = new JSONParser();
        int i = -1;
        if (strWifiDevice != null && !strWifiDevice.isEmpty()) {
            org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) jsonParser.parse(strWifiDevice);
            System.out.println(jsonArray);
            i = pushWifiDeviceToDB(jsonArray, "UPDATE");
        }
        return i;

    }

    public static Long getLastSyncTimeVHR(String vhrSyncData) {

        BasicDBObject matchFields = new BasicDBObject();

        if (null != vhrSyncData) switch (vhrSyncData) {
            case Constant.ORG:
                matchFields.put("_id", new BasicDBObject("$eq", "VHR_ORG"));
                break;
            case Constant.USER:
                matchFields.put("_id", new BasicDBObject("$eq", "VHR_USER"));
                break;
            case Constant.SETTING:
                matchFields.put("_id", new BasicDBObject("$eq", "VHR_SETTING"));
                break;
            default:
                break;
        }
        BasicDBObject match = new BasicDBObject("$match", matchFields);
        BasicDBObject projectFields = new BasicDBObject();
        projectFields.put("_id", 0);
        projectFields.put("lastSyncTime", 1);
        BasicDBObject project = new BasicDBObject("$project", projectFields);
        AggregationOutput output = MongodbConnection.getInstance().getVHRTimeSyncConnection().aggregate(match, project);
        JSONParser jsonParser = new JSONParser();
        if (output == null) {
            return 0l;
        }
        Long temp = 0l;
        for (DBObject result : output.results()) {
            try {
                org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject) jsonParser.parse(result.toString());
                temp = (Long) jsonObject.get("lastSyncTime");
            } catch (ParseException ex) {
                LOGGER.error(SynchonizeVHRSettingData.class.getName() + " " + ex);
            }
        }
        return temp;
    }

    public static int syncListWifiDeviceInsert(String urlWSWifiDevice) throws org.json.simple.parser.ParseException {
        HashMap map = new HashMap();
        map.put("type", "INSERT");
        //get lastSyncTime
        long timesync = getLastSyncTimeVHR(Constant.SETTING) * 1000;
        map.put("syncTime", String.valueOf(timesync));
        String strWifiDevice = TTNSQuery.getResultFromVHRParam(urlWSWifiDevice, map);
        JSONParser jsonParser = new JSONParser();
        int i = -1;
        if (strWifiDevice != null && !strWifiDevice.isEmpty()) {
            org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) jsonParser.parse(strWifiDevice);
            System.out.println(jsonArray);
            i = pushWifiDeviceToDB(jsonArray, "INSERT");
        }
        return i;
    }

    public static int syncListWifiDeviceFirstTime(String urlWSWifiDevice) throws org.json.simple.parser.ParseException {
        HashMap map = new HashMap();
        map.put("type", "ALL");
//        map.put("syncTime", DataUtils.getSysTimestamp().toString());
        map.put("syncTime", "0");
        String strWifiDevice = TTNSQuery.getResultFromVHRParam(urlWSWifiDevice, map);
        LOGGER.info("Result syncListWifiDeviceFirstTime : " + strWifiDevice);
        JSONParser jsonParser = new JSONParser();
        int i = -1;
        if (strWifiDevice != null && !strWifiDevice.isEmpty() && strWifiDevice.length() > 0) {
            org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) jsonParser.parse(strWifiDevice);
            System.out.println(jsonArray);
            deleteOldData("wifiF");
            i = pushWifiDeviceToDB(jsonArray, "ALL");
        }

        return i;

    }

//    30082016_HuyVT2: Lay thong tin loai nghi khac
    public static int syncWorkDayType(String urlWSWorkDayType) throws org.json.simple.parser.ParseException {

        String strWorkDayType = TTNSQuery.getResultFromVHRNotParam(urlWSWorkDayType);
        LOGGER.info("syncWorkDayType: " + strWorkDayType);
        JSONParser jsonParser = new JSONParser();
        int i = -1;
        if (strWorkDayType != null && !strWorkDayType.isEmpty()) {
            org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) jsonParser.parse(strWorkDayType);
            System.out.println(jsonArray);
            deleteOldData("wdt");
            // push to DB
            i = pushWorkDayTypeToDB(jsonArray);
            LOGGER.info("Add item at: " + i);
//            Long changeName = (Long) jsonObject.remove("_id");
//            jsonObject.put("postId", changeName);
//            int isTagged = 0;
//            int isFollowed = 0;
//            org.json.simple.JSONArray json = (org.json.simple.JSONArray) jsonObject.get("members");
        }

        return i;

    }
}
