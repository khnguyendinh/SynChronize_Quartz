package com.viettel.synchronize.util;

import com.viettel.logkpi.LogKpiModel;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

/**
 *
 * @author HuydN2
 */
public class HttpUtil {

    private static final org.apache.log4j.Logger LOGGER = org.apache.log4j.Logger.getLogger("HttpUtil");
    public static String httpGet(String url) {
        String res = null;

        HttpClient httpclient = new HttpClient() {
            @Override
            public HttpParams getParams() {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public ClientConnectionManager getConnectionManager() {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public HttpResponse execute(HttpUriRequest hur) throws IOException, ClientProtocolException {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public HttpResponse execute(HttpUriRequest hur, HttpContext hc) throws IOException, ClientProtocolException {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public HttpResponse execute(HttpHost hh, HttpRequest hr) throws IOException, ClientProtocolException {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public HttpResponse execute(HttpHost hh, HttpRequest hr, HttpContext hc) throws IOException, ClientProtocolException {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public <T> T execute(HttpUriRequest hur, ResponseHandler<? extends T> rh) throws IOException, ClientProtocolException {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public <T> T execute(HttpUriRequest hur, ResponseHandler<? extends T> rh, HttpContext hc) throws IOException, ClientProtocolException {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public <T> T execute(HttpHost hh, HttpRequest hr, ResponseHandler<? extends T> rh) throws IOException, ClientProtocolException {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public <T> T execute(HttpHost hh, HttpRequest hr, ResponseHandler<? extends T> rh, HttpContext hc) throws IOException, ClientProtocolException {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        try {
            httpclient = new DefaultHttpClient();
        } catch (Exception e) {
            LOGGER.error(e);
        }

        try {
            HttpGet httpGet = new HttpGet(url);
            httpGet.setHeader(HttpHeaders.CONNECTION, "close");

            HttpResponse response = httpclient.execute(httpGet);
            if (response.getStatusLine().getStatusCode() == 200) {
                HttpEntity resEntity = response.getEntity();
                if (resEntity != null) {
                    byte[] resBytes = EntityUtils.toByteArray(resEntity);
                    res = new String(resBytes);
                    EntityUtils.consume(resEntity);
                }
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
        } finally {
            try {
                httpclient.getConnectionManager().shutdown();
            } catch (Exception ignore) {
                LOGGER.error(ignore);
            }
        }

        return res;
    }

/// HaiVH2
    /**
     * Represents an HTTP connection
     */
    private static volatile HttpURLConnection httpConn;

    /**
     * Makes an HTTP request using GET method to the specified URL.
     *
     * @param requestURL the URL of the remote server
     * @return An HttpURLConnection object
     * @throws IOException thrown if any I/O error occurred
     */
    public static HttpURLConnection sendGetRequest(String requestURL, String accessToken) {
        try {
            URL url = new URL(requestURL);
            httpConn = (HttpURLConnection) url.openConnection();
            httpConn.setRequestProperty("Authorization", "Bearer " + accessToken);
            httpConn.setUseCaches(false);

            httpConn.setDoInput(true); // true if we want to read server's response
            httpConn.setDoOutput(false); // false indicates this is a GET request
        } catch (IOException e) {
            LOGGER.error(e);
        }
        return httpConn;
    }

    public static HttpURLConnection sendGetRequest(String requestURL, String accessToken, Map<String, String> mapParam) {

        try {
            String param = "";
            for (Map.Entry<String, String> e : mapParam.entrySet()) {
                String key = e.getKey();
                String value = e.getValue();
                param += "&" + key + "=" + value;
                // httpConn.setRequestProperty(key, value);
            }
            param = param.substring(1, param.length());
            requestURL = requestURL + param;
            URL url = new URL(requestURL);

            httpConn = (HttpURLConnection) url.openConnection();
            httpConn.setRequestProperty("Authorization", "Bearer " + accessToken);
            httpConn.setUseCaches(false);
            httpConn.setDoInput(true); // true if we want to read server's response
            httpConn.setDoOutput(false); // false indicates this is a GET request

        } catch (IOException e) {
            LOGGER.error(e);
        }
        return httpConn;
    }

    
     public static String postRequest(String requestUrl,Map<String, String> mapParam){
        String response = "";
        try{
        URL url = new URL(requestUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(3000);
        conn.setReadTimeout(3000);
        conn.setDoOutput(true);
        conn.setDoInput(true);
        conn.setUseCaches(false);
        conn.setAllowUserInteraction(false);
        conn.setRequestProperty("Content-Type",
                    "application/x-www-form-urlencoded; charset=utf-8");
            //httpConn.setRequestProperty("Accept-Charset", "UTF-8");

            // Create the form content
        OutputStream out = conn.getOutputStream();
        Writer writer = new OutputStreamWriter(out, "UTF-8");
        for (Map.Entry<String, String> e : mapParam.entrySet()) {
            writer.write(e.getKey());
            writer.write("=");
            //writer.write(e.getValue());
            writer.write(URLEncoder.encode(e.getValue(), "UTF-8"));
            writer.write("&");
        }
        writer.close();
        out.close();

        //PHuongTH5: khong can check null o day
        InputStream  inputStream = conn.getInputStream();
//        if (conn != null) {
//            inputStream = conn.getInputStream();
//        } else {
//            throw new IOException("Connection is not established.");
//        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                inputStream, "UTF-8"));

        response = reader.readLine();
        reader.close();
        } catch (IOException e) {
            LOGGER.info(e);
            //e.printStackTrace();
        }       
        return response;
    }
    
    
    public static HttpURLConnection sendGetRequest(String requestURL) {
        try {
            URL url = new URL(requestURL);
            httpConn = (HttpURLConnection) url.openConnection();
            httpConn.setUseCaches(false);

            httpConn.setDoInput(true); // true if we want to read server's response
            httpConn.setDoOutput(false); // false indicates this is a GET request
        } catch (IOException e) {
            LOGGER.error(e);
        }
        return httpConn;
    }
    
    public static String postRequestByJson(String requestUrl, JSONObject jObject) {
        String response = "";
        try {
            URL url = new URL(requestUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(30000);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setAllowUserInteraction(false);
            conn.setRequestProperty("Authorization", "Bearer " + " dsfsdgdsgs");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            OutputStream os = conn.getOutputStream();
            if(jObject != null && jObject.toString() != null && jObject.toString().getBytes("UTF-8") != null){
                os.write(jObject.toString().getBytes("UTF-8"));
            }
            os.close();

            InputStream inputStream;
            inputStream = conn.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
            response = reader.readLine();
            reader.close();
            if(inputStream != null)
                inputStream.close();
        } catch (Exception ex) {
            //Liemnt10: log kpi error
            LOGGER.error(ex);
        }
        return response;
    }
    
    /**
     * @return a String of the server's response
     */
    public static String readRespone() {
        String response = null;
        try {
            InputStream inputStream ;
            if (httpConn != null) {
                inputStream = httpConn.getInputStream();
            } else {
                throw new IOException("Connection is not established.");
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    inputStream));

            response = reader.readLine();
            reader.close();
        } catch (IOException e) {
            LOGGER.error(e);
        }
        return response;
    }

    /**
     * Closes the connection if opened
     */
    public static void disconnect() {
        if (httpConn != null) {
            httpConn.disconnect();
        }
    }
}
