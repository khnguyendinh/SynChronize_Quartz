package com.viettel.synchronize.util;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.viettel.synchronize.common.Config;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author truongbx3
 */
public class DataUtils {

    private static final org.apache.log4j.Logger LOGGER = org.apache.log4j.Logger.getLogger("DataUtils");

    //Liemnt10: lay OrgId
    public static List<String> splitId(String stringId) {
        String afPath = ",";
        String[] bePath = stringId.split(afPath);
        List<String> lstPath = new ArrayList<>();
        for (String bePath1 : bePath) {
            if (bePath1 != null && bePath1.length() != 0) {
                lstPath.add(bePath1);
            }
        }
        return lstPath;
    }

    public static Date convertStringToTime(String date) throws ParseException {
        String pattern = "dd/MM/yyyy";
        if (date == null || "".equals(date.trim())) {
            return null;
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
        return dateFormat.parse(date);

    }

    public static Long getSysTimestamp() {
        return (System.currentTimeMillis() / 1000);
    }

    /**
     * Convert from Long to Integer
     *
     * @param value
     * @param defaultValue
     * @return
     */
    public static int convertLongToInt(Long value, int defaultValue) {
        if (value != null) {
            try {
                return value.intValue();
            } catch (Exception e) {
                LOGGER.error(e);
            }
        }
        return defaultValue;
    }

    /**
     * chuan hoa so dien thoai
     *
     * @param mobile
     * @return
     */
    public static String standardizeMobileNumber(String mobile) {
        String mobileStandard = "";
        for (int index = 0; index < mobile.length(); index++) {
            String charMobile = mobile.substring(index, index + 1);
            if ("9".equals(charMobile) || "8".equals(charMobile) || "7".equals(charMobile) || "6".equals(charMobile) || "5".equals(charMobile)
                    || "4".equals(charMobile) || "3".equals(charMobile) || "2".equals(charMobile) || "1".equals(charMobile) || "0".equals(charMobile)) {
                mobileStandard += charMobile;
            }
        }
        try {
            //TODO: add vao config
            if (mobileStandard.length() < 15) {
                for (int index = 0; index < mobileStandard.length(); index++) {
                    if ("9".equals(mobileStandard.substring(index, index + 1))) {
                        mobileStandard = "84" + mobileStandard.substring(index);
                        break;
                    } else if ("1".equals(mobileStandard.substring(index, index + 1))) {
                        mobileStandard = "84" + mobileStandard.substring(index);
                        break;
                    } else if ("8".equals(mobileStandard.substring(index, index + 1))) {
                        mobileStandard = "84" + mobileStandard.substring(index);
                        break;
                    }
                }
            } else {
                for (int index = 0; index < mobileStandard.length(); index++) {
                    if ("9".equals(mobileStandard.substring(index, index + 1))) {
                        mobileStandard = "84" + mobileStandard.substring(index, index + 9);
                        break;
                    } else if ("1".equals(mobileStandard.substring(index, index + 1))) {
                        mobileStandard = "84" + mobileStandard.substring(index, index + 10);
                        break;
                    } else if ("8".equals(mobileStandard.substring(index, index + 1))) {
                        mobileStandard = "84" + mobileStandard.substring(index, index + 9);
                        break;
                    }
                }
            }
        } catch (Exception ex) {
            LOGGER.error(ex);
            return mobileStandard;
        }
        if(mobileStandard.length() >= 11)
            return mobileStandard;
        else
            return mobile;
    }

    /**
     * chuan hoa so dien thoai thu 2 (co nhung nguoi co nhieu hon 1 so dien
     * thoai)
     *
     * @param mobile
     * @return
     */
    public static String standardizeMobileNumber2(String mobile) {
        String mobileStandard2 = "";
        for (int index = 0; index < mobile.length(); index++) {
            String charMobile = mobile.substring(index, index + 1);
            if ("9".equals(charMobile) || "8".equals(charMobile) || "7".equals(charMobile) || "6".equals(charMobile) || "5".equals(charMobile) || "4".equals(charMobile)
                    || "3".equals(charMobile) || "2".equals(charMobile) || "1".equals(charMobile) || "0".equals(charMobile)) {
                mobileStandard2 += charMobile;
            }
        }

        if (mobileStandard2.length() < 15) {
            return null;
        } else {
            // Co so dien thoai thu 2

            for (int index = 0; index < mobileStandard2.length(); index++) {
                if ("9".equals(mobileStandard2.substring(index, index + 1))) {
                    for (int index2 = index + 9; index2 < mobileStandard2.length(); index2++) {
                        if ("9".equals(mobileStandard2.substring(index2, index2 + 1))) {
                            mobileStandard2 = "84" + mobileStandard2.substring(index2);
                            break;
                        } else if ("1".equals(mobileStandard2.substring(index2, index2 + 1))) {
                            mobileStandard2 = "84" + mobileStandard2.substring(index2);
                            break;
                        }
                    }
                } else if ("1".equals(mobileStandard2.substring(index, index + 1))) {
                    for (int index2 = index + 10; index2 < mobileStandard2.length(); index2++) {
                        if ("9".equals(mobileStandard2.substring(index2, index2 + 1))) {
                            mobileStandard2 = "84" + mobileStandard2.substring(index2);
                            break;
                        } else if ("1".equals(mobileStandard2.substring(index2, index2 + 1))) {
                            mobileStandard2 = "84" + mobileStandard2.substring(index2);
                            break;
                        }
                    }
                }
            }

            return mobileStandard2;
        }
    }

    public static Long getVHRWorkDayTypeSequense() {

        BasicDBObject find = new BasicDBObject();
        find.put("_id", "vhrWorkDayType_seq");
        BasicDBObject update = new BasicDBObject();
        update.put("$inc", new BasicDBObject("seq", 1));
        DBObject obj = MongodbConnection.getInstance().getChatGroupSEQConnection().findAndModify(find, update);
        return (Long) obj.get("seq");
    }

    public static Long getVHRWifiDeviceSequense() {
        BasicDBObject find = new BasicDBObject();
        find.put("_id", "vhrWifiDevice_seq");
        BasicDBObject update = new BasicDBObject();
        update.put("$inc", new BasicDBObject("seq", 1));
        DBObject obj = MongodbConnection.getInstance().getChatGroupSEQConnection().findAndModify(find, update);
        return (Long) obj.get("seq");
    }

    public static Long getVHRWorkPlaceSequense() {
        BasicDBObject find = new BasicDBObject();
        find.put("_id", "vhrWorkPlace_seq");
        BasicDBObject update = new BasicDBObject();
        update.put("$inc", new BasicDBObject("seq", 1));
        DBObject obj = MongodbConnection.getInstance().getChatGroupSEQConnection().findAndModify(find, update);
        return (Long) obj.get("seq");
    }

    public static Long getVHRReasonOutSequense() {
        BasicDBObject find = new BasicDBObject();
        find.put("_id", "vhrReasonOut_seq");
        BasicDBObject update = new BasicDBObject();
        update.put("$inc", new BasicDBObject("seq", 1));
        DBObject obj = MongodbConnection.getInstance().getChatGroupSEQConnection().findAndModify(find, update);
        return (Long) obj.get("seq");
    }

    //Liemnt10: spit Field in String Log
    public static List<String> splitLogKpi(String strLineLog) {
        String afPath = "\\|\\|";
        String[] bePath = strLineLog.split(afPath);
        List<String> lstPath = new ArrayList<>();
        for (String bePath1 : bePath) {
            if (bePath1 != null && bePath1.length() != 0) {
                lstPath.add(bePath1);
            }
        }
        return lstPath;
    }
    
//    public static void main(String[] args) {
//         List<String> lstOrgId = splitId("1");
//          for (String strId : lstOrgId) { //Lay ra cai ID Org
//              System.out.println("KET QUA DAY == " +strId);
//          }
//         
//    }
}
