package com.viettel.synchronize.util;

/**
 *
 * @author HuydN2
 */
public class UserRelationship {

    //Cac kieu friend
    public static final int REL_TYPE_NO_FRIEND = 0;
    public static final int REL_TYPE_REQUEST_FRIEND = 1;
    public static final int REL_TYPE_FRIEND = 2;
    //Cac kieu block
    public static final int REL_TYPE_NO_BLOCK = 0;
    public static final int REL_TYPE_BLOCK_MESSAGE = 3;
    public static final int REL_TYPE_BLOCK_HOMEPAGE = 4;
    public static final int REL_TYPE_BLOCK_MESSAGE_AND_HOMEPAGE = 5;
    //Cac kieu rieng tu
    public static final int PRIVACY_EVERYONE = 0;
    public static final int PRIVACY_FRIENDS_OF_FRIENDS = 1;
    public static final int PRIVACY_FRIENDS_ONLY = 2;
    public static final int PRIVACY_SPECIFIC_PEOPLE = 3;
    public static final int PRIVACY_ONLY_ME = 4;
    /**
     * ID cua toi, nguoi dang login
     */
    private int meUserId;
    /**
     * ID nguoi toi muon check: toi co phai la ban ko, toi co bi nguoi nay block
     * ko
     */
    private int checkUserId;
    /**
     * REL_TYPE_NO_FRIEND, REL_TYPE_REQUEST_FRIEND, REL_TYPE_FRIEND
     */
    private int friendType = REL_TYPE_NO_FRIEND;
    /**
     * Kieu block: REL_TYPE_NO_BLOCK, REL_TYPE_BLOCK_MESSAGE,
     * REL_TYPE_BLOCK_HOMEPAGE, REL_TYPE_BLOCK_MESSAGE_AND_HOMEPAGE
     */
    private int blockType = REL_TYPE_NO_BLOCK;
    //////////Quyen rieng tu cua nguoi nay (checkUserId)///////////////////
    private int privacyViewProfile;
    private int privacyPostProfile;
    private int privacyComment;
    private int privacyReceiveMessage;

    private boolean targetUserNotExist = false;

    public int getBlockType() {
        return blockType;
    }

    public void setBlockType(int blockType) {
        this.blockType = blockType;
    }

    public int getCheckUserId() {
        return checkUserId;
    }

    public void setCheckUserId(int checkUserId) {
        this.checkUserId = checkUserId;
    }

    public int getFriendType() {
        return friendType;
    }

    public void setFriendType(int friendType) {
        this.friendType = friendType;
    }

    public int getMeUserId() {
        return meUserId;
    }

    public void setMeUserId(int meUserId) {
        this.meUserId = meUserId;
    }

    public int getPrivacyComment() {
        return privacyComment;
    }

    public void setPrivacyComment(int privacyComment) {
        this.privacyComment = privacyComment;
    }

    public int getPrivacyPostProfile() {
        return privacyPostProfile;
    }

    public void setPrivacyPostProfile(int privacyPostProfile) {
        this.privacyPostProfile = privacyPostProfile;
    }

    public int getPrivacyReceiveMessage() {
        return privacyReceiveMessage;
    }

    public void setPrivacyReceiveMessage(int privacyReceiveMessage) {
        this.privacyReceiveMessage = privacyReceiveMessage;
    }

    public int getPrivacyViewProfile() {
        return privacyViewProfile;
    }

    public void setPrivacyViewProfile(int privacyViewProfile) {
        this.privacyViewProfile = privacyViewProfile;
    }

    public boolean isTargetUserNotExist() {
        return targetUserNotExist;
    }

    public void setTargetUserNotExist(boolean targetUserNotExist) {
        this.targetUserNotExist = targetUserNotExist;
    }
}
