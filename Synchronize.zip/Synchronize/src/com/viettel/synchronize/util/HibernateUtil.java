package com.viettel.synchronize.util;

import java.io.File;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;
import encoding.Encoding;
import org.apache.log4j.Logger;

/**
 * Hibernate Utility class with a convenient method to get Session Factory
 * object.
 *
 * @author congnt29
 */
public class HibernateUtil {

    private static final SessionFactory SESSION_FACTORY;
    private static final Logger LOGGER = Logger.getLogger(HibernateUtil.class);
    static {
        try {
            Configuration configuration = new Configuration();
            String configFile = System.getProperty("user.dir") + File.separator + "config" + File.separator + "hibernate.cfg.xml";
            configuration.configure(new File(configFile));
            configuration.setProperty("hibernate.connection.password", Encoding.getEncryptor().decrypt(configuration.getProperty("hibernate.connection.password")));
            configuration.setProperty("hibernate.connection.username", Encoding.getEncryptor().decrypt(configuration.getProperty("hibernate.connection.username")));
            configuration.setProperty("hibernate.connection.url", Encoding.getEncryptor().decrypt(configuration.getProperty("hibernate.connection.url")));
            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
            SESSION_FACTORY = configuration.buildSessionFactory(serviceRegistry);
        } catch (Throwable ex) {
            // Log the exception. 
            System.err.println("Initial SessionFactory creation failed." + ex);
            LOGGER.error(ex.getMessage(), ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return SESSION_FACTORY;
    }
}
