package com.viettel.synchronize.util;

/**
 *
 * @author HuydN2
 */
public class LocDauTiengVietUtl {

    public static final String SPECIAL_CHARACTERS = "àÀảẢãÃáÁạẠăĂằẰẳẲẵẴắẮặẶâÂầẦẩẨẫẪấẤậẬđĐèÈẻẺẽẼéÉẹẸêÊềỀểỂễỄếẾệỆìÌỉỈĩĨíÍịỊòÒỏỎõÕóÓọỌôÔồỒổỔỗỖốỐộỘơƠờỜởỞỡỠớỚợỢùÙủỦũŨúÚụỤưƯừỪửỬữỮứỨựỰýÝ:+\\<>\"*,!?%$=@#~[]`|^";
    public static final String REPLACEMENTS = "aAaAaAaAaAaAaAaAaAaAaAaAaAaAaAaAaAdDeEeEeEeEeEeEeEeEeEeEeEiIiIiIiIiIoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOuUuUuUuUuUuUuUuUuUuUuUyY___\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";
    protected static final char[] CAC_KY_TY_TIENG_VIET = SPECIAL_CHARACTERS.toCharArray();
    protected static final char[] CAC_KY_TY_TIENG_VIET_DA_BO_DAU = REPLACEMENTS.toCharArray();

    public static synchronized String perform(String string) {
        StringBuilder stringSau = new StringBuilder();

        char[] c1 = string.toCharArray();
        for (int i = 0; i < c1.length; i++) {
            //ky tu can thay the
            char kyTuCanThayThe = c1[i];
            //tim ky tu nay trong CAC_KY_TY_TIENG_VIET
            for (int j = 0; j < CAC_KY_TY_TIENG_VIET.length; j++) {
                char kyTuTiengViet = CAC_KY_TY_TIENG_VIET[j];
                if (kyTuTiengViet == kyTuCanThayThe) {
                    kyTuCanThayThe = CAC_KY_TY_TIENG_VIET_DA_BO_DAU[j];
                    break;
                }
            }
            stringSau.append(kyTuCanThayThe);
        }

        return stringSau.toString().trim();
    }
}
