package com.viettel.synchronize.util;

//import application.statistic.StatisticManager;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.viettel.synchronize.common.Config;
import encoding.Encoding;
import java.util.Arrays;

/**
 *
 * @author huyvt2
 */
public class MongodbConnection {

//    public DBCollection connection;
    public DBCollection vHRWorkDayTypeConnection;
    public DBCollection vHRWorkPlaceConnection;
    public DBCollection vHRWifiDeviceConnection;
    public DBCollection vHRSettingConnection;
    public DBCollection vHRDeleteWifiDeviceConnection;
    public DBCollection vHRReasonOutConnection;
    public DBCollection chatGroupConnection;
    public DBCollection userTempFileDownload;
    
    public DBCollection userBusinessStatConnection;
    public static volatile MongodbConnection mongoCollection;
    public Mongo mongo;
    public DB db;
    boolean auth = false;
    //private static final Logger LOGGER = Logger.getLogger("MongodbConnection");

    public static MongodbConnection getInstance() {
        if (mongoCollection == null) {
            mongoCollection = new MongodbConnection();
        }
        return mongoCollection;
    }

    public DBCollection getChatGroupSEQConnection() {
        if (chatGroupConnection == null) {
            chatGroupConnection = createChatGroupSEQConnection();
        }

        //PhuongTH5: Log statistic
        //  StatisticManager.getInstance().getStatisticModel().incNoTransactionMongoDB();
        return chatGroupConnection;
    }

    public DBCollection createChatGroupSEQConnection() {
        if (!auth) {
            createDBconnection();
        }
        chatGroupConnection = db.getCollection("ChatGroupSEQ");
        return chatGroupConnection;
    }

    public DBCollection getVHRWorkDayTypeConnection() {
        if (vHRWorkDayTypeConnection == null) {
            vHRWorkDayTypeConnection = createVHRWorkDayTypeConnection();
        }

        //PhuongTH5: Log statistic
//        StatisticManager.getInstance().getStatisticModel().incNoTransactionMongoDB();
        return vHRWorkDayTypeConnection;
    }

    public DBCollection getVHRWorkPlaceConnection() {
        if (vHRWorkPlaceConnection == null) {
            vHRWorkPlaceConnection = createVHRWorkPlaceConnection();
        }

        return vHRWorkPlaceConnection;
    }

    public DBCollection getVHRWifiDeviceConnection() {
        if (vHRWifiDeviceConnection == null) {
            vHRWifiDeviceConnection = createVHRWifiDeviceConnection();
        }

        return vHRWifiDeviceConnection;
    }
    
    
    public DBCollection getVHRTimeSyncConnection() {
        if (vHRSettingConnection == null) {
            vHRSettingConnection = createVHRTimeSyncConnection();
        }

        return vHRSettingConnection;
    }
    
    

    public DBCollection getVHRDeleteWifiDeviceConnection() {
        if (vHRDeleteWifiDeviceConnection == null) {
            vHRDeleteWifiDeviceConnection = createVHRDeleteWifiDeviceConnection();
        }

        return vHRDeleteWifiDeviceConnection;
    }

    public DBCollection getVHRReasonOutConnection() {
        if (vHRReasonOutConnection == null) {
            vHRReasonOutConnection = createVHRReasonOutConnection();
        }

        //PhuongTH5: Log statistic
//        StatisticManager.getInstance().getStatisticModel().incNoTransactionMongoDB();
        return vHRReasonOutConnection;
    }
    
    public DBCollection getUserTempFileDownload() {
        if (!auth) {
            createDBconnection();
        }
        userTempFileDownload = db.getCollection("TempFileDownload");
        return userTempFileDownload;
    }
    
    public DBCollection createVHRWorkDayTypeConnection() {
        if (!auth) {
            createDBconnection();
        }
        vHRWorkDayTypeConnection = db.getCollection("VHR_WorkDayType");
        return vHRWorkDayTypeConnection;

    }

    public DBCollection createVHRWorkPlaceConnection() {
        if (!auth) {
            createDBconnection();
        }
        vHRWorkPlaceConnection = db.getCollection("VHR_WorkPlace");
        return vHRWorkPlaceConnection;

    }

    public DBCollection createVHRWifiDeviceConnection() {
        if (!auth) {
            createDBconnection();
        }
        vHRWifiDeviceConnection = db.getCollection("VHR_WifiDevice");
        return vHRWifiDeviceConnection;

    }
    public DBCollection createVHRTimeSyncConnection() {
        if (!auth) {
            createDBconnection();
        }
        vHRSettingConnection = db.getCollection("VHR_TimeSync");
        return vHRSettingConnection;

    }

    public DBCollection createVHRDeleteWifiDeviceConnection() {
        if (!auth) {
            createDBconnection();
        }
        vHRDeleteWifiDeviceConnection = db.getCollection("VHR_DeleteWifiDevice");
        return vHRDeleteWifiDeviceConnection;

    }

    public DBCollection createVHRReasonOutConnection() {
        if (!auth) {
            createDBconnection();
        }
        vHRReasonOutConnection = db.getCollection("VHR_ReasonOut");
        return vHRReasonOutConnection;

    }
    
    public DBCollection getUserBusinessStatConnection() {

        if (userBusinessStatConnection == null) {
            userBusinessStatConnection = createUserBusinessStatConnection();
        }
        return userBusinessStatConnection;
    }
    public DBCollection createUserBusinessStatConnection() {

        if (!auth) {
            createDBconnection();
        }
        userBusinessStatConnection = db.getCollection("UserBusinessStatistic");
        return userBusinessStatConnection;
    }

    private void createDBconnection() {
        Config.loadConfig();
        MongoClient mongoClient;
        MongoCredential mongoCredential = MongoCredential
                .createScramSha1Credential(Encoding.getEncryptor().decrypt(Config.uname_nosql), Encoding.getEncryptor().decrypt(Config.db_nosql),
                        Encoding.getEncryptor().decrypt(Config.pass_nosql).toCharArray());
        mongoClient = new MongoClient(new ServerAddress(
                Encoding.getEncryptor().decrypt(Config.ip_nosql), Integer.parseInt(Encoding.getEncryptor().decrypt(Config.port_nosql))),
                Arrays.asList(mongoCredential));
        db = mongoClient.getDB(Encoding.getEncryptor().decrypt(Config.db_nosql));
        auth = true;
    }
}
