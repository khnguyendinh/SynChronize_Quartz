/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.synchronize.vhgs;

/**
 *
 * @author phuongth5
 */
public class ErrorCode {
    public static final String ERR_SYNCHRONIZE_NOT_SYNC_CODE = "Err_Synchronize_NotSync";
        public static final String ERR_SYNCHRONIZE_NOT_SYNC_MSG = "Loi ve dong bo thong tin nhan su";
    
    public static final String ERR_SYNCHRONIZE_SERVICE_TTNS_CODE = "Err_Synchronize_Service_TTNS";
    public static final String ERR_SYNCHRONIZE_SERVICE_TTNS_MSG = "Service dong bo thong tin nhan su dang khong tra ve, can kiem tra";
}
