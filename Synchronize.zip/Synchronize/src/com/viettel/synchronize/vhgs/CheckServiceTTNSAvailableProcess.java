/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.synchronize.vhgs;

import com.viettel.mmserver.base.ProcessThreadMX;
import com.viettel.synchronize.common.Config;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import javax.management.InstanceAlreadyExistsException;
import javax.management.MBeanRegistrationException;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;

/**
 *
 * @author phuongth5
 */
public class CheckServiceTTNSAvailableProcess extends ProcessThreadMX {
    public CheckServiceTTNSAvailableProcess(String threadName, String description, String MBeanName) {
        super(threadName, description);
        try {
            //Dang ky ten Mbean
            registerAgent(MBeanName);
        } catch (MalformedObjectNameException ex) {
            logger.error("register service agent error");
            logger.error("exception:" + ex.toString());
        } catch (InstanceAlreadyExistsException ex) {
            logger.error("register service agent error");
            logger.error("exception:" + ex.toString());
        } catch (MBeanRegistrationException ex) {
            logger.error("register service agent error");
            logger.error("exception:" + ex.toString());
        } catch (NotCompliantMBeanException ex) {
            logger.error("register service agent error");
            logger.error("exception:" + ex.toString());
        }
    }
    
    @Override
    protected void process() {
        // Chu y: Muon su dung duoc tinh nang canh bao tien trinh treo, nguoi lap trinh phai gan thoi diem bat dau cua ham process
        buStartTime = new Date();
        //Viet code thuc hien nghiep vu tai doan nay
        //Cac nghiep vu xu ly o day thuong la cac cong viec xu ly trong thoi gian ngan va co tinh lap di lap lai
        //Vi du cong viec in ra dong chu runing sau do sleep 1s
        try {
            logger.info("running CheckServiceTTNSAvailableProcess ... ");   
            
            boolean serviceLinkOk = isHttpUrlFound(Config.urlServiceVhr + Config.accessTokenUrl);
            if(!serviceLinkOk){
                //Error log mesage format: error_code(*) error_message error_description - (*) la bat buoc phai co
                String description = String.format("Service dong bo thong tin nhan su khong tim thay, can check lai");
                String errorMsg = String.format("ErrorCode:%s ErrorMessage:%s ErrorDescription:%s", 
                        ErrorCode.ERR_SYNCHRONIZE_SERVICE_TTNS_CODE, 
                        ErrorCode.ERR_SYNCHRONIZE_SERVICE_TTNS_MSG, 
                        description);
                logger.error(errorMsg);
            }
            else{
                logger.info(String.format("Check CheckServiceTTNSAvailableProcess is ok "));    
            }
            //Cho Thread sleep khoang thoi gian de check lai 
            Thread.sleep(Config.duration_CheckServiceTTNSAvailableProcess);
        } catch (InterruptedException ex) {
            logger.error(ex.getMessage());
        }
        //Khi thuc hien xong cong viec, can dat lai buStartTime
        buStartTime = null;
    }
    
    private boolean isHttpUrlFound(String urlStr){
        boolean result = false;
        HttpURLConnection connection = null;
        try{
            final URL url = new URL(urlStr);
            connection = (HttpURLConnection) url.openConnection();
            int responseCode = connection.getResponseCode();
            result = responseCode != HttpURLConnection.HTTP_NOT_FOUND;
        }
        catch (MalformedURLException e) { 
            // new URL() failed
            result = false;
        } 
        catch (IOException e) {   
            // openConnection() failed
            result = false;
        }
        finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return result;
    }
}
