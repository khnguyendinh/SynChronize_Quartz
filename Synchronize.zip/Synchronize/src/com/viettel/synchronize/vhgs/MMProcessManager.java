/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.synchronize.vhgs;

/**
 *
 * @author phuongth5
 */
public class MMProcessManager {
    private static MMProcessManager singleton;
    
    public static synchronized MMProcessManager getInstance(){
        if(singleton == null){
            singleton = new MMProcessManager();
        }
        return singleton;
    }
    
    private static CheckSyncServiceProcess checkSyncServiceProcess;
    private static CheckServiceTTNSAvailableProcess checkServiceTTNSAvailableProcess;
    
    private void init(){
        checkSyncServiceProcess = new CheckSyncServiceProcess("CheckSyncServiceProcess", 
                "Tien trinh kiem tra he thong khong dong bo thong tin nhan su trong 2 ngay", 
                "process:name=SmartOffice_Synchronize_CheckSyncServiceProcess");
        
        checkServiceTTNSAvailableProcess = new CheckServiceTTNSAvailableProcess("CheckServiceTTNSAvailableProcess", 
                "Tien trinh kiem tra service thong tin nhan su co chay duoc khong trong 1 ngay", 
                "process:name=SmartOffice_Synchronize_CheckServiceTTNSAvailableProcess");
    }
    
    public void start(){
        init();
        checkSyncServiceProcess.start();
        checkServiceTTNSAvailableProcess.start();
    }
    
    public void stop(){
        checkSyncServiceProcess.stop();
        checkServiceTTNSAvailableProcess.stop();
    }
}
