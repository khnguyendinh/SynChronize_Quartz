/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.synchronize.vhgs;

import com.viettel.mmserver.base.ProcessThreadMX;
import com.viettel.synchronize.common.Config;
import com.viettel.synchronize.common.Constant;
import static com.viettel.synchronize.smartsyn.SynchonizeVHRSettingData.getLastSyncTimeVHR;
import java.util.Date;
import javax.management.InstanceAlreadyExistsException;
import javax.management.MBeanRegistrationException;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;

/**
 *
 * @author phuongth5
 */
public class CheckSyncServiceProcess extends ProcessThreadMX {
    public CheckSyncServiceProcess(String threadName, String description, String MBeanName) {
        super(threadName, description);
        try {
            //Dang ky ten Mbean
            registerAgent(MBeanName);
        } catch (MalformedObjectNameException ex) {
            logger.error("register service agent error");
            logger.error("exception:" + ex.toString());
        } catch (InstanceAlreadyExistsException ex) {
            logger.error("register service agent error");
            logger.error("exception:" + ex.toString());
        } catch (MBeanRegistrationException ex) {
            logger.error("register service agent error");
            logger.error("exception:" + ex.toString());
        } catch (NotCompliantMBeanException ex) {
            logger.error("register service agent error");
            logger.error("exception:" + ex.toString());
        }
    }
    
    @Override
    protected void process() {
        // Chu y: Muon su dung duoc tinh nang canh bao tien trinh treo, nguoi lap trinh phai gan thoi diem bat dau cua ham process
        buStartTime = new Date();
        //Viet code thuc hien nghiep vu tai doan nay
        //Cac nghiep vu xu ly o day thuong la cac cong viec xu ly trong thoi gian ngan va co tinh lap di lap lai
        //Vi du cong viec in ra dong chu runing sau do sleep 1s
        try {
            logger.info("running CheckSyncServiceProcess ... ");   
            //Can kiem tra last updatetime trong MongoDB so voi thoi diem hien tai
            //Get last time sync save in DB
            long lastSyncTimeSetting = getLastSyncTimeVHR(Constant.SETTING) * 1000;
            long lastSyncTimeOrg = getLastSyncTimeVHR(Constant.ORG) * 1000;
            long lastSyncTimeUser = getLastSyncTimeVHR(Constant.USER) * 1000;
            
            //Time thoi diem check
            long currentTime = System.currentTimeMillis();
            StringBuilder contentMsg = new StringBuilder();
            boolean bNeedLog = false;
            if(currentTime - lastSyncTimeSetting >= Config.duration_CheckSyncServiceProcess){
                bNeedLog = true;
                contentMsg.append("Setting khong dong bo trong: ").
                        append((currentTime - lastSyncTimeSetting)/(3600*1000)).
                        append(" gio").append("\n");
            }
            
            if(currentTime - lastSyncTimeOrg >= Config.duration_CheckSyncServiceProcess){
                bNeedLog = true;
                contentMsg.append("Org khong dong bo trong: ").
                        append((currentTime - lastSyncTimeOrg)/(3600*1000)).
                        append(" gio").append("\n");
            }
            
            if(currentTime - lastSyncTimeUser >= Config.duration_CheckSyncServiceProcess){
                bNeedLog = true;
                contentMsg.append("User khong dong bo trong: ").
                        append((currentTime - lastSyncTimeUser)/(3600*1000)).
                        append(" gio").append("\n");
            }
            if(bNeedLog){
                //Error log mesage format: error_code(*) error_message error_description - (*) la bat buoc phai co
                String description = String.format("Noi dung loi: %s", contentMsg.toString());
                String errorMsg = String.format("ErrorCode:%s ErrorMessage:%s ErrorDescription:%s", 
                        ErrorCode.ERR_SYNCHRONIZE_NOT_SYNC_CODE, 
                        ErrorCode.ERR_SYNCHRONIZE_NOT_SYNC_MSG, 
                        description);
                logger.error(errorMsg);
            }
            else{
                logger.info(String.format("Check CheckWriteLogProcess is ok"));    
            }
            //Cho Thread sleep khoang thoi gian de check lai 
            Thread.sleep(Config.duration_CheckSyncServiceProcess);
        } catch (InterruptedException ex) {
            logger.error(ex.getMessage());
        }
        //Khi thuc hien xong cong viec, can dat lai buStartTime
        buStartTime = null;
    }
    
}
