/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.viettel.synchronize.vhgs;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import org.apache.log4j.Logger;

/**
 *
 * @author phuongth5
 */
public class NetworkChecker {
    private static final Logger LOGGER = Logger.getLogger(NetworkChecker.class);
    private static NetworkChecker singleton;
    
    public synchronized static NetworkChecker getInstance(){
        if(singleton == null){
            singleton = new NetworkChecker();
        }
        return singleton;
    }
    
    public boolean isOpenByURL(String IP, int port){
        if(IP == null){
            LOGGER.error("Wrong format tomcat check");
            return false;
        }
        String url = String.format("http://%s:%d", IP, port); 
        try {
            LOGGER.info("Check connect URL: " + IP + ":" + port);
            new URL(url).openConnection().connect();
        } catch (MalformedURLException e) { 
            // new URL() failed
            LOGGER.error("Error to load URL at: " + url + "\n" + e);
            return false;
        } 
        catch (IOException e) {   
            // openConnection() failed
            LOGGER.error("Error to open connection to: " + url + "\n" + e);
            return false;
        }
        return true;
    }
    
    public boolean isOpenBySocket(String ip, int port){
        boolean isUp = false;
        try {
            LOGGER.info("Check connect socket: " + ip + ":" + port);
            Socket socket = new Socket(ip, port);
            isUp = true;
            socket.close();
        }
        catch (IOException e)
        {
            LOGGER.error("Socket is down at " + ip + ":" + port +" Exception: " + e);
        }
        return isUp;
    }
    
    public boolean isHttpUrlFound(String urlStr){
        boolean result = false;
        HttpURLConnection connection = null;
        try{
            final URL url = new URL(urlStr);
            connection = (HttpURLConnection) url.openConnection();
            int responseCode = connection.getResponseCode();
            result = responseCode != HttpURLConnection.HTTP_NOT_FOUND;
        }
        catch (MalformedURLException e) { 
            // new URL() failed
            result = false;
        } 
        catch (IOException e) {   
            // openConnection() failed
            result = false;
        }
        finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return result;
    }
}
