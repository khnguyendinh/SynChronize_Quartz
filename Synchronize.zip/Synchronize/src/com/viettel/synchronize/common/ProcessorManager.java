package com.viettel.synchronize.common;

import com.viettel.synchronize.database.hibernate.DhVhrEmployee;
import java.util.concurrent.LinkedBlockingDeque;

/**
 *
 * @author congnt29
 */
public class ProcessorManager {

    private static ProcessorManager pm = new ProcessorManager();
    private static LinkedBlockingDeque<DhVhrEmployee> linkedBlockingDeque = new LinkedBlockingDeque<>();

    public static synchronized ProcessorManager getInstance() {
        if (pm == null) {
            pm = new ProcessorManager();
        }
        return pm;
    }
    
    public ProcessorManager() {
//        linkedBlockingDeque = new LinkedBlockingDeque<>();
    }

    public void put(DhVhrEmployee countrycodetable) throws InterruptedException {
        linkedBlockingDeque.put(countrycodetable);
    }

    public DhVhrEmployee take() throws InterruptedException {

        return linkedBlockingDeque.take();
    }
}
