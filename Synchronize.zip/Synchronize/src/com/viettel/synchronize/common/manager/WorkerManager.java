package com.viettel.synchronize.common.manager;

import com.viettel.synchronize.common.WorkerBase;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import org.apache.log4j.Logger;

/**
 *
 * @author huydaungoc@gmail.com
 * @since Nov 10, 2011
 * @version 1.0
 */
public class WorkerManager extends Thread {

    private static final Logger LOGGER = Logger.getLogger(WorkerManager.class);
    private static WorkerManager wokerManager = null;
    /**
     * Map: ten_lop_worker <-> Mang_cac_worker
     */
    private Map<String, CopyOnWriteArrayList<WorkerBase>> mapListWorkers = new ConcurrentHashMap<>();
    /**
     * Thoi gian toi da xu ly cong viec, tinh bang giay
     */
    private int maxTimeProcessJob = 120;
    private boolean running = true;

    public static synchronized WorkerManager getInstance() {
        if (wokerManager == null) {
            wokerManager = new WorkerManager();
        }
        return wokerManager;
    }

    public CopyOnWriteArrayList getListWorkers(Class workerType) {
        CopyOnWriteArrayList<WorkerBase> listWorkers = mapListWorkers.get(workerType.getName());
        if (listWorkers == null) {
            listWorkers = new CopyOnWriteArrayList<>();
            mapListWorkers.put(workerType.getName(), listWorkers);
        }
        return listWorkers;
    }

    public Map<String, CopyOnWriteArrayList<WorkerBase>> getMapListWorkers() {
        return mapListWorkers;
    }

    public void stopAllWorkers() {
        running = false;

        Set<String> typeWorkers = mapListWorkers.keySet();
        for (String typeWorker : typeWorkers) {
            CopyOnWriteArrayList<WorkerBase> listWorkers = mapListWorkers.get(typeWorker);
            for (WorkerBase worker : listWorkers) {
                worker.requestStop();
            }
        }
    }

    @Override
    public void run() {
        while (running) {
            try {
                Thread.sleep(10000);
            } catch (InterruptedException ex) {
            }

            Set<String> typeWorkers = mapListWorkers.keySet();
            for (String typeWorker : typeWorkers) {
                CopyOnWriteArrayList<WorkerBase> listWorkers = mapListWorkers.get(typeWorker);
                for (WorkerBase worker : listWorkers) {
                    if (worker.getProcessStartTime() > 0) {
                        long time = System.currentTimeMillis() - worker.getProcessStartTime();
                        LOGGER.info(worker.getName() + " process time: " + time);
                        if (time > maxTimeProcessJob * 1000) {
                            LOGGER.error(worker.getName() + " process job too long. Kill it ... : "
                                    + worker.getWorkerThread().getName());

                            listWorkers.remove(worker);

//							HuyWorker newworker = new HuyWorker(worker.getName());
//							TestWorker.appWorkerExecutor.execute(newworker);
                            worker.getWorkerThread().stop();
                        }
                    }
                }
            }
        }
    }
}
