package com.viettel.synchronize.common;

import com.viettel.synchronize.common.manager.WorkerManager;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import org.apache.log4j.Logger;

/**
 * @author huydaungoc@gmail.com
 * @since Nov 7, 2011
 * @version 1.0
 */
public abstract class WorkerBase implements Runnable {

    private static final Logger LOGGER = Logger.getLogger(WorkerBase.class);
    protected LinkedBlockingQueue<JobBase> jobQueue;
    protected List<WorkerBase> listWorkers = WorkerManager.getInstance().getListWorkers(getClass());
    protected boolean running = false;
    /**
     * Thoi diem bat dau xu ly cong viec
     */
    protected long processStartTime = 0;
    /**
     * Cong viec hien tai dang thuc hien
     */
    protected JobBase currentWork = null;
    protected String name;
    protected Thread workerThread;
    protected int batchJobSize = 1;

    /**
     * Ham nhan cong viec
     *
     * @param work
     * @throws java.lang.InterruptedException
     */
    public void receive(JobBase work) throws InterruptedException {
        jobQueue.put(work);
    }

    /**
     * Bo xu ly 1 cong viec
     *
     * @param job
     */
    protected abstract void process(JobBase job);

    /**
     * Bo xu ly nhieu cong viec
     *
     * @param jobs
     */
    protected abstract void process(List<JobBase> jobs);

    @Override
    public void run() {
        if (running) {
            return;
        }
        running = true;
        workerThread = Thread.currentThread();
        workerThread.setName(name);

        while (running) {
            try {
                JobBase job = (JobBase) jobQueue.take();

                currentWork = job;
                processStartTime = System.currentTimeMillis();
//                try {
                    if (batchJobSize == 1) {
                        process(job);
                    } else {
                        List<JobBase> jobs = new LinkedList<>();
                        jobs.add(job);
                        for (int i = 0; i < batchJobSize - 1; i++) {
                            JobBase job2 = jobQueue.poll();
                            if (job2 == null) {
                                break;
                            }
                            jobs.add(job2);
                        }
                        process(jobs);
                    }
//                } 
//                catch (Exception e) {
//                    LOGGER.error(this.getName() + " has error in process work", e);
//                }
                currentWork = null;
                processStartTime = 0;
            } catch (InterruptedException ex) {
                LOGGER.info("Interrupt After Wait");
            }
        }

        LOGGER.info(this.getName() + " has been stopped!");
    }

    public boolean isRunning() {
        return running;
    }

    public void requestStop() {
        LOGGER.info(this.getName() + " is stopping ...");
        running = false;
    }

    public List<WorkerBase> getListWorkers() {
        return listWorkers;
    }

    public long getProcessStartTime() {
        return processStartTime;
    }

    public LinkedBlockingQueue<JobBase> getQueue() {
        return jobQueue;
    }

    public JobBase getCurrentWork() {
        return currentWork;
    }

    public String getName() {
        return name;
    }

    public void setCurrentWork(JobBase currentWork) {
        this.currentWork = currentWork;
    }

    public int getBatchJobSize() {
        return batchJobSize;
    }

    public void setBatchJobSize(int batchJobSize) {
        this.batchJobSize = batchJobSize;
    }

    public Thread getWorkerThread() {
        return workerThread;
    }
}
