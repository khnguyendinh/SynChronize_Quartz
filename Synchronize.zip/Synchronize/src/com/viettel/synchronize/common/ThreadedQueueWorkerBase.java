package com.viettel.synchronize.common;

import java.util.concurrent.LinkedBlockingQueue;
import org.apache.log4j.Logger;

/**
 * Moi worker (1 thread) se co 1 jobQueue rieng
 *
 * @author huydaungoc@gmail.com
 * @since Sep 14, 2012
 * @version 1.0
 */
public abstract class ThreadedQueueWorkerBase extends WorkerBase {

    private static final Logger LOGGER = Logger.getLogger(ThreadedQueueWorkerBase.class);

    public ThreadedQueueWorkerBase() {
        listWorkers.add(this);
        jobQueue = new LinkedBlockingQueue<>();
    }

    public ThreadedQueueWorkerBase(String name) {
        this();
        this.name = name;
    }

    public ThreadedQueueWorkerBase(String name, int capacityBatch) {
        this();
        this.name = name;
        this.batchJobSize = capacityBatch;
    }
}
