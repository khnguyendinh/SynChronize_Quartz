package com.viettel.synchronize.common;

/**
 *
 * @author Dau Ngoc Huy
 */
public class StringUtil {

    /**
     * cat' 1 chuoi thanh toi da la maxChars ky tu, dam bao ko cat o giua~ tu
     *
     * @param string
     * @param maxChars
     * @return
     */
    public static String cutStringAfterWord(String string, int maxChars) {
        if (string.length() <= maxChars) {
            return string;
        }

        int pos = maxChars;
        for (int i = 0; i < 10 && i <= maxChars; i++) {
            char ch = string.charAt(maxChars - i);
            if (ch == ' ') {
                pos = maxChars - i;
                break;
            }
        }
        return string.substring(0, pos);
    }
}
