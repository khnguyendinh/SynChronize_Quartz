package com.viettel.synchronize.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 *
 * @author congnt29
 */
public class Config {

    public static final String APP_CONF_FILE_PATH = System.getProperty("user.dir") + File.separator + "config" + File.separator + "app.conf";
    public static final String LOG_CONF_FILE_PATH = System.getProperty("user.dir") + File.separator + "config" + File.separator + "log.conf";
    public static final String DATA_CONF_FILE_PATH = System.getProperty("user.dir") + File.separator + "config" + File.separator + "dataconfig.conf";

    public static volatile String vhrUrl;
    public static volatile String vhrAcc;
    public static volatile String vhrPass;
    public static volatile String avatarUrl;
    public static volatile int duration_SyncData_ByHour;

    //Thong tin cau hinh cho Dong bo TTNS
    public static volatile String uname_nosql;
    public static volatile String pass_nosql;
    public static volatile String db_nosql;
    public static volatile String ip_nosql;
    public static volatile String port_nosql;

    public static volatile int dbWorkerThreadCount;

    // HuyVT2 - Thong tin cau hinh cua VHR
    public static volatile String urlServiceVhr;
    public static volatile String accessTokenUrl;
    public static volatile String refreshTokenUrl;
    public static volatile String client_id;
    public static volatile String username;
    public static volatile String password;
    public static volatile String client_secret;

    private final static Logger LOGGER = Logger.getLogger(Config.class);
    public static String avatarNormalUrl;
    public static String avatarBigUrl;
    public static String avatarOrginalUrl;
    public static String fullAvatarUrl;
    public static volatile int duration_CheckSyncServiceProcess;
    public static volatile int duration_CheckServiceTTNSAvailableProcess;
    public static String threadName;
    public static String zooHost;
    public static String memberName;
    public static String groupName;
    public static String zooConnectInterval;

    //Liemnt10: Thoi gian xu ly LogKpi
    public static volatile int hoursOfLogKpi;
    public static volatile int minutesOfLogKpi;
    public static volatile int hoursOfVHR;
    public static volatile int minutesOfVHR;
    public static volatile int hoursOfPush;
    public static volatile int minutesOfPush;

    public static volatile String kpiFilePath;
    public static volatile String actionLogFilePath;
    public static volatile String nodeServer;
    public static volatile String orgIds;
    public static volatile String empCodes;
    public static volatile String titleNotify;
    public static volatile String contentNotify;
    public static volatile String dataNotify;

    public static synchronized void loadConfig() {
        try {
            LOGGER.info("run config");
            org.apache.log4j.PropertyConfigurator.configure(Config.LOG_CONF_FILE_PATH);

            Properties properties = new Properties();
            properties.load(new FileInputStream(APP_CONF_FILE_PATH));

            vhrUrl = encoding.Encoding.getEncryptor().decrypt(properties.getProperty("vhr_url", "").trim());
            vhrAcc = encoding.Encoding.getEncryptor().decrypt(properties.getProperty("vhr_acc", "").trim());
            vhrPass = encoding.Encoding.getEncryptor().decrypt(properties.getProperty("vhr_pass", "").trim());
            avatarUrl = properties.getProperty("avatarUrl", "").trim();
            fullAvatarUrl = properties.getProperty("fullAvatarUrl", "").trim();
            avatarNormalUrl = properties.getProperty("avatarNormalUrl", "").trim();
            avatarBigUrl = properties.getProperty("avatarBigUrl", "").trim();
            avatarOrginalUrl = properties.getProperty("avatarOrginalUrl", "").trim();

            duration_SyncData_ByHour = Integer.valueOf(properties.getProperty("duration_SyncData_ByHour", "24").trim());

            //HuyVT2 HA
            threadName = properties.getProperty("host", "smoSync_thread").trim();
            zooHost = properties.getProperty("zooHost", "10.58.71.190:9790").trim();
            memberName = properties.getProperty("memberName", "smoSyncThread").trim();
            groupName = properties.getProperty("groupName", "smoSyncThread").trim();
            zooConnectInterval = properties.getProperty("zooConnectInterval", "10000").trim();
            //Thong tin cau hinh cho Dong bo TTNS
            Properties dataConfig = new Properties();
            dataConfig.load(new FileInputStream(DATA_CONF_FILE_PATH));
            uname_nosql = dataConfig.getProperty("uname_nosql", "").trim();
            pass_nosql = dataConfig.getProperty("pass_nosql", "").trim();
            ip_nosql = dataConfig.getProperty("ip_nosql", "").trim();
            port_nosql = dataConfig.getProperty("port_nosql", "").trim();
            db_nosql = dataConfig.getProperty("db_nosql", "").trim();

            //HuyVT2 - Thong tin dong bo VHR 
            urlServiceVhr = properties.getProperty("vhr_ttns_url", "").trim();

            LOGGER.info("urlServiceVhr :" + urlServiceVhr);

            accessTokenUrl = properties.getProperty("access_token_url", "").trim();
            refreshTokenUrl = properties.getProperty("refresh_token_url", "").trim();
            client_id = properties.getProperty("client_id", "").trim();
            password = properties.getProperty("password", "").trim();
            username = properties.getProperty("username", "").trim();
            client_secret = properties.getProperty("client_secret", "").trim();

            duration_CheckSyncServiceProcess = Integer.valueOf(properties.getProperty("duration_CheckSyncServiceProcess", "172800000").trim());
            duration_CheckServiceTTNSAvailableProcess = Integer.valueOf(properties.getProperty("duration_CheckServiceTTNSAvailableProcess", "86400000").trim());

            //Liemnt10
            hoursOfLogKpi = Integer.valueOf(properties.getProperty("hours_of_logKpi", "23").trim());
            minutesOfLogKpi = Integer.valueOf(properties.getProperty("minutes_of_logKpi", "00").trim());
            hoursOfVHR = Integer.valueOf(properties.getProperty("hours_of_VHR", "23").trim());
            minutesOfVHR = Integer.valueOf(properties.getProperty("minutes_of_VHR", "59").trim());
            kpiFilePath = properties.getProperty("kpiFilePath", "").trim();
            actionLogFilePath = properties.getProperty("actionLogFilePath", "").trim();
            nodeServer = properties.getProperty("nodeServer", "").trim();
            orgIds = properties.getProperty("orgIds", "").trim();
            empCodes =properties.getProperty("empCodes", " ").trim();
            titleNotify = properties.getProperty("titleNotify", "").trim();
            contentNotify = properties.getProperty("contentNotify", "").trim();
            dataNotify = properties.getProperty("dataNotify", "").trim();
            hoursOfPush= Integer.valueOf(properties.getProperty("hours_of_Push", "16").trim());
            minutesOfPush= Integer.valueOf(properties.getProperty("minutes_of_Push", "00").trim());
            
            
            LOGGER.info("End of reading Config file");
        } catch (IOException | NumberFormatException ex) {
            LOGGER.error("load config error: " + ex);
            System.exit(1);
        }
    }
}
