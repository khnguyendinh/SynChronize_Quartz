package com.viettel.synchronize.common;

/**
 *
 * @author phuongth5
 */
public class Constant {
    public static final String VHR_USER = "VHR_USER";
    public static final String VHR_ORG = "VHR_ORG";
    public static final String VHR_SETTING = "VHR_SETTING";
    
    public static final String USER = "USER";
    public static final String ORG = "ORG";
    public static final String SETTING = "SETTING";
    
    public static final String LASTSYNCTIME = "lastSyncTime";
    
    //Liemnt10: cho viec PushNotify 
    public static final String SERVER_KEY_PUSH = "AAAADGrAonM:APA91bE0f8gMvu177L4buWM--FOlEAxhftP-t1HnWPz4E5dVMPy1kOHMyiS2_4KdvTeTdyqzRemvpd44MFhtts__PMTe6sENi2GU6EcWt34wK42jc9gaYkyEr-kw_g0hFiSA6-4DqJWs";
    public static final String TYPE_ANDROID = "ANDROID";
    public static final String TYPE_IOS = "IOS";
}
