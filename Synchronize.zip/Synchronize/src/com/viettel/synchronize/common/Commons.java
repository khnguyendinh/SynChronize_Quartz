package com.viettel.synchronize.common;

/**
 *
 * @author congnt29
 */
public class Commons {

    public static final boolean isRunning = true;
    public static final int line = 0;
    //public static ProcessorManager processorManager;
    public static final int count = 0;
}
