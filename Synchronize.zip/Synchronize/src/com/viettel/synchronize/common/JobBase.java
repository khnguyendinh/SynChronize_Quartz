package com.viettel.synchronize.common;

/**
 *
 * @author huydaungoc@gmail.com
 * @since Nov 7, 2011
 * @version 1.0
 */
public class JobBase {

    public static final int JOB_TYPE_SEND_OFFLINE_MSG = 1;
    public static final int JOB_TYPE_SUGGEST_FRIEND_ADDRESS_BOOK = 2;
    public static final int JOB_TYPE_SUGGEST_FRIEND_FACEBOOK_CONTACT = 3;
    public static final int JOB_TYPE_SUGGEST_FRIEND_ADDRESS_BOOK_LIKE_WHATSAPP = 4;

    protected int jobType;

    public int getJobType() {
        return jobType;
    }

    public void setJobType(int jobType) {
        this.jobType = jobType;
    }
}
