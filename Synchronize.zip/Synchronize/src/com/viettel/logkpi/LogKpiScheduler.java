package com.viettel.logkpi;

import com.viettel.synchronize.common.Config;
import com.viettel.synchronize.util.DataUtils;
import com.viettel.synchronize.util.HibernateUtil;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * Xu ly thong tin logKpi vao DB MySQL
 *
 * @since 06/2017
 * @author Liemnt10
 */
public class LogKpiScheduler implements Job {

    private static final Logger LOGGER = Logger.getLogger(LogKpiScheduler.class);

    @Override
    public void execute(JobExecutionContext jec) throws JobExecutionException {
        LOGGER.info("Proccesing read LogKPI File and insert to MySQL DB ... ");

        System.out.println("Chay vao Log KPi .....");
        try {
            //Lay ve truoc ngay hien tai mot ngay
            Calendar c = Calendar.getInstance();
            c.add(Calendar.DATE, -1);
            Date date = c.getTime();

            getActions(date);
        } catch (IOException ex) {
            LOGGER.info("co loi " + ex);
        }
    }

    private void getActions(Date logDate) throws FileNotFoundException, IOException {

        String pathLog = Config.kpiFilePath;
        String nodeServer = Config.nodeServer;
        String logFilePath = pathLog + "kpifull.log." + new SimpleDateFormat("yyyy-MM-dd").format(logDate);

        File fileLog = new File(logFilePath);

        if (fileLog.exists()) {
            BufferedReader br = new BufferedReader(new FileReader(fileLog));
            String strLine;
            LogKpiModel lkM = new LogKpiModel();
            lkM.setNode_Server(nodeServer);
            lkM.setFile_LogKpi("kpifull.log." + new SimpleDateFormat("yyyy-MM-dd").format(logDate));
            int idx = 0;
            try {
                while ((strLine = br.readLine()) != null) {
                    idx = idx + 1;
                    if (!"".equals(strLine)) {
                        //[AppWorker_4] 22/05/2017 00:03:26.154  INFO LoggerKpi: 
                        int firstPosition = strLine.indexOf("]", 2) + 42;
                        String newStr = strLine.substring(firstPosition, strLine.length());
                        List<String> lstKpiModel = DataUtils.splitLogKpi(newStr);

//                        for (String strLog : lstKpiModel) {
//                          if (!strLog.isEmpty() && strLog != null) {
//                          }
//                        } 
                        if (lstKpiModel.size() > 1 && lstKpiModel.get(0) != null && !lstKpiModel.get(0).isEmpty()) {
                            lkM.setTypeLog(lstKpiModel.get(0));
                        } else {
                            lkM.setTypeLog("N/A");
                        }
                        if (lstKpiModel.size() > 2 && lstKpiModel.get(1) != null && !lstKpiModel.get(1).isEmpty()) {
                            lkM.setIpPortParentNode(lstKpiModel.get(1));
                        } else {
                            lkM.setIpPortParentNode("N/A");
                        }
                        if (lstKpiModel.size() > 3 && lstKpiModel.get(2) != null && !lstKpiModel.get(2).isEmpty()) {
                            lkM.setApplicationCode(lstKpiModel.get(2));
                        } else {
                            lkM.setApplicationCode("N/A");
                        }
                        if (lstKpiModel.size() > 4 && lstKpiModel.get(3) != null && !lstKpiModel.get(3).isEmpty()) {
                            lkM.setSessionId(lstKpiModel.get(3));
                        } else {
                            lkM.setSessionId("N/A");
                        }
                        if (lstKpiModel.size() > 5 && lstKpiModel.get(4) != null && !lstKpiModel.get(4).isEmpty()) {
                            lkM.setStartTime(lstKpiModel.get(4));
                        } else {
                            lkM.setStartTime("0");
                        }
                        if (lstKpiModel.size() > 6 && lstKpiModel.get(5) != null && !lstKpiModel.get(5).isEmpty()) {
                            lkM.setEndTime(lstKpiModel.get(5));
                        } else {
                            lkM.setEndTime("0");
                        }
                        if (lstKpiModel.size() > 7 && lstKpiModel.get(6) != null && !lstKpiModel.get(6).isEmpty()) {
                            lkM.setIpPortCurrentNode(lstKpiModel.get(6));
                        } else {
                            lkM.setIpPortCurrentNode("N/A");
                        }
                        if (lstKpiModel.size() > 8 && lstKpiModel.get(7) != null && !lstKpiModel.get(7).isEmpty()) {
                            lkM.setActionName(lstKpiModel.get(7));
                        } else {
                            lkM.setActionName("N/A");
                        }
                        if (lstKpiModel.size() > 9 && lstKpiModel.get(8) != null && !lstKpiModel.get(8).isEmpty()) {
                            lkM.setRequestContent(lstKpiModel.get(8));
                        } else {
                            lkM.setRequestContent("N/A");
                        }
                        if (lstKpiModel.size() > 10 && lstKpiModel.get(9) != null && !lstKpiModel.get(9).isEmpty()) {
                            lkM.setServiceCode(lstKpiModel.get(9));
                        } else {
                            lkM.setServiceCode("N/A");
                        }
                        if (lstKpiModel.size() > 11 && lstKpiModel.get(10) != null && !lstKpiModel.get(10).isEmpty()) {
                            lkM.setDuration(Long.parseLong(lstKpiModel.get(10)));
                        } else {
                            lkM.setDuration(0);
                        }
                        if (lstKpiModel.size() > 12 && lstKpiModel.get(11) != null && !lstKpiModel.get(11).isEmpty()) {
                            lkM.setLevel(lstKpiModel.get(11));
                        } else {
                            lkM.setLevel("XXX");
                        }
                        insertLogToDB(lkM, idx);
                    }
                }
            } catch (Exception e) {
                LOGGER.info("ERROR WHILE READ FILE LOG - TAI DONG :" + idx + "- " + e);
                System.out.println("ERROR WHILE READ FILE LOG - TAI DONG :" + idx + "- " + e);
            }
            LOGGER.info("Finish processing execute LogKPI.");
            System.out.println("Finish processing execute LogKPI.");
            //Close the input stream
            br.close();
        } else {
            LOGGER.info("LogTimerTask: FILE LOG NOT EXISTS " + logFilePath);
            System.out.println("LogTimerTask: FILE LOG NOT EXISTS " + logFilePath);
        }
    }

    //Insert vao DB MySQL
    private void insertLogToDB(LogKpiModel lkM, int rowNum) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        if (lkM != null) {
            try {
                Transaction transaction = session.beginTransaction();

                SQLQuery query = session.createSQLQuery("INSERT INTO `Log_Full_KPI` (`Type_Log`, `Node_Port` ,`App_Code`,`Thread_Id`,`Start_Time`,`End_Time`,`IP`,`Action_Type`,`Request_Content`,"
                        + " `Function_Code` ,`Total_time` ,`Level`,`Node_Server`,`File_LogKpi`) "
                        + " VALUES (:Type_Log, :Node_Port, :App_Code, :Thread_Id, :Start_Time, :End_Time, :IP, :Action_Type, :Request_Content, :Function_Code "
                        + ", :Total_time, :Level, :Node_Server, :File_LogKpi)");
                if (lkM.getTypeLog().trim().equals("WARN")) {
                    query.setParameter("Type_Log", lkM.getTypeLog());
                    query.setParameter("Node_Port", lkM.getIpPortParentNode());
                    query.setParameter("App_Code", lkM.getApplicationCode());
                    query.setParameter("Thread_Id", lkM.getSessionId());
                    query.setParameter("Start_Time", lkM.getStartTime());
                    query.setParameter("End_Time", lkM.getEndTime());
                    query.setParameter("IP", lkM.getIpPortCurrentNode());
                    query.setParameter("Action_Type", lkM.getActionName());
                    query.setParameter("Request_Content", lkM.getRequestContent());
                    query.setParameter("Function_Code", lkM.getServiceCode());
                    query.setParameter("Total_time", lkM.getDuration());
                    query.setParameter("Level", lkM.getLevel());
                    query.setParameter("Node_Server", lkM.getNode_Server());
                    query.setParameter("File_LogKpi", lkM.getFile_LogKpi());
                } else {
                    query.setParameter("Type_Log", lkM.getTypeLog());
                    query.setParameter("Node_Port", "N/A");
                    query.setParameter("App_Code", lkM.getApplicationCode());
                    query.setParameter("Thread_Id", "N/A");
                    query.setParameter("Start_Time", lkM.getIpPortParentNode());
                    query.setParameter("End_Time", "N/A");
                    query.setParameter("IP", "N/A");
                    query.setParameter("Action_Type", "ERROR_CODE_" + lkM.getSessionId());
                    query.setParameter("Request_Content", lkM.getStartTime());
                    query.setParameter("Function_Code", "N/A");
                    query.setParameter("Total_time", Integer.valueOf(0));
                    query.setParameter("Level", lkM.getLevel());
                    query.setParameter("Node_Server", lkM.getNode_Server());
                    query.setParameter("File_LogKpi", lkM.getFile_LogKpi());
                }
                int kq = query.executeUpdate();
                transaction.commit();
            } catch (RuntimeException e) {
                System.out.println("CO LOI TAI LINE: " + rowNum + " KHI INSERT LOG TO DB..." + e);
                LOGGER.info("CO LOI TAI LINE: " + rowNum + " KHI INSERT LOG TO DB..." + e);
            } finally {
                if (session != null) {
                    session.close();
                }
            }
        }
    } 
}
