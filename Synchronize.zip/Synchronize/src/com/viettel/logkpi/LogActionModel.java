package com.viettel.logkpi;

/**
 *
 * @author liemnt10
 * @since 08/2017
 */
public class LogActionModel {

    private int staffId;

    private String loginName;

    private String function;

    private String ipServer;

    private String content;

    private long startTime;

    private long endTime;

    private String device;

    private String voffice;

    private long subTime;

    private String sqlCommand;

    private String file_logAction;
    
    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getFunction() {
        return function;
    }

    public String getIpServer() {
        return ipServer;
    }

    public void setIpServer(String ipServer) {
        this.ipServer = ipServer;
    }

    public void setFunction(String function) {
        this.function = function;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getVoffice() {
        return voffice;
    }

    public void setVoffice(String voffice) {
        this.voffice = voffice;
    }

    public long getSubTime() {
        return subTime;
    }

    public void setSubTime(long subTime) {
        this.subTime = subTime;
    }

    public String getSqlCommand() {
        return sqlCommand;
    }

    public void setSqlCommand(String sqlCommand) {
        this.sqlCommand = sqlCommand;
    }

    public String getFile_logAction() {
        return file_logAction;
    }

    public void setFile_logAction(String file_logAction) {
        this.file_logAction = file_logAction;
    }
}
