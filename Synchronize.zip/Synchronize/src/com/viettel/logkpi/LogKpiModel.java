package com.viettel.logkpi;

/**
 * Model Log for KPI-SQL
 *
 * @author liemnt10
 * @since 06/2017
 */
public class LogKpiModel {

    //Ma ung dung hoac Ma tien trinh
    private String applicationCode;

    private String serviceCode;
    //session tự tăng và là duy nhất cho mỗi giao dịch,
    //ma này phai khac với he thong khac
    private String sessionId;
    //IP, Port node cha 
    private String ipPortParentNode;
    //IP, Port node hiện tại
    private String ipPortCurrentNode;
    //Noi dung yeu cau xu ly
    private String requestContent;
    //ket qua phan hoi
    private String responseContent;
    //Tgian bat dau xu ly: YYYY/MM/DD hh:mi:ss:ms
    private String startTime;
    //Tgian ket thuc YYYY/MM/DD hh:mi:ss:ms
    private String endTime;
    //Tong thoi gian xu ly cua Nghiep vu (ms)
    private long duration;
    //Ma loi tra ve cua giao dich 
    private int errorCode;

    private String errorDescription;
    //KQ thuc hien gdich 1: that bat, 0: thanh cong
    private String transactionStatus;
    //Thao tác nghiệp vụ
    private String actionName;
    //Dùng để trace người dùng, mặc định null nếu không có 
    private String userName;
    //Là account của dịch vụ (VD : Ma HD)
    private String account;

    private String errorFullDescription;

    private String node_Server;

    private String file_LogKpi;

    private String typeLog;

    private String level;

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }
    
    public String getTypeLog() {
        return typeLog;
    }

    public void setTypeLog(String typeLog) {
        this.typeLog = typeLog;
    }

    public String getFile_LogKpi() {
        return file_LogKpi;
    }

    public void setFile_LogKpi(String file_LogKpi) {
        this.file_LogKpi = file_LogKpi;
    }

    public String getNode_Server() {
        return node_Server;
    }

    public void setNode_Server(String node_Server) {
        this.node_Server = node_Server;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public String getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getResponseContent() {
        return responseContent;
    }

    public void setResponseContent(String responseContent) {
        this.responseContent = responseContent;
    }

    public String getRequestContent() {
        return requestContent;
    }

    public void setRequestContent(String requestContent) {
        this.requestContent = requestContent;
    }

    public String getIpPortCurrentNode() {
        return ipPortCurrentNode;
    }

    public void setIpPortCurrentNode(String ipPortCurrentNode) {
        this.ipPortCurrentNode = ipPortCurrentNode;
    }

    public String getIpPortParentNode() {
        return ipPortParentNode;
    }

    public void setIpPortParentNode(String ipPortParentNode) {
        this.ipPortParentNode = ipPortParentNode;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getApplicationCode() {
        return applicationCode;
    }

    public void setApplicationCode(String applicationCode) {
        this.applicationCode = applicationCode;
    }

    public String checkNullString(String str) {
        if (str != null && !str.isEmpty()) {
            return str;
        } else {
            return "N/A";
        }
    }

    /**
     * @return the errorFullDescription
     */
    public String getErrorFullDescription() {
        return errorFullDescription;
    }

    /**
     * @param errorFullDescription the errorFullDescription to set
     */
    public void setErrorFullDescription(String errorFullDescription) {
        this.errorFullDescription = errorFullDescription;
    }
}
