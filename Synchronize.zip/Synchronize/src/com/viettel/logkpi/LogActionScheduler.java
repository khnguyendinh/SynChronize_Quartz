package com.viettel.logkpi;

import com.viettel.synchronize.common.Config;
import com.viettel.synchronize.util.DataUtils;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 *
 * @author liemnt10
 * @since 08/2017
 */
public class LogActionScheduler implements Job {

    private static final Logger LOGGER = Logger.getLogger(LogActionScheduler.class);

    @Override
    public void execute(JobExecutionContext jec) throws JobExecutionException {
        LOGGER.info("Proccesing read LogAction File and insert to MySQL DB ... ");

        System.out.println("Chay vao LogAction .....");
        try {
            //Lay ve truoc ngay hien tai mot ngay
            Calendar c = Calendar.getInstance();
            c.add(Calendar.DATE, -1);
            Date date = c.getTime();

            readLogActionFile(date);
        } catch (IOException ex) {
            LOGGER.info("co loi " + ex);
        }
    }

    private void readLogActionFile(Date logDate) throws FileNotFoundException, IOException {
        String pathLog = Config.actionLogFilePath;
        String nodeServer = Config.nodeServer;
        String logFilePath = pathLog + "actionfull.log." + new SimpleDateFormat("yyyy-MM-dd").format(logDate);

        File fileLog = new File(logFilePath);

        if (fileLog.exists()) {
            BufferedReader br = new BufferedReader(new FileReader(fileLog));
            String strLine;
            LogActionModel laM = new LogActionModel();
            laM.setIpServer(nodeServer);//Xem lai phan nay
            laM.setFile_logAction("actionfull.log." + new SimpleDateFormat("yyyy-MM-dd").format(logDate));
            int idx = 0;
            try {
                while ((strLine = br.readLine()) != null) {
                    idx = idx + 1;
                    if (!"".equals(strLine)) {
                        int firstPosition = strLine.indexOf("]", 2) + 42; //Thay lai so 42:=> [AppWorker_4] 22/05/2017 00:03:26.154  INFO LoggerKpi
                        String newStr = strLine.substring(firstPosition, strLine.length());
                        List<String> lstLaModel = DataUtils.splitLogKpi(newStr);
                        if (lstLaModel.size() > 1 && lstLaModel.get(0) != null && !lstLaModel.get(0).isEmpty()) {
                            laM.setStaffId(Integer.parseInt(lstLaModel.get(0)));
                        } else {
                            laM.setStaffId(0);
                        }
                        if (lstLaModel.size() > 2 && lstLaModel.get(1) != null && !lstLaModel.get(1).isEmpty()) {
                            laM.setLoginName(lstLaModel.get(1));
                        } else {
                            laM.setLoginName("N/A");
                        }
                        if (lstLaModel.size() > 3 && lstLaModel.get(2) != null && !lstLaModel.get(2).isEmpty()) {
                            laM.setFunction(lstLaModel.get(2));
                        } else {
                            laM.setFunction("N/A");
                        }
                         if (lstLaModel.size() > 4 && lstLaModel.get(3) != null && !lstLaModel.get(3).isEmpty()) {
                            laM.setIpServer(lstLaModel.get(3));
                        } else {
                            laM.setIpServer("N/A");
                        }
                    }
                }
            } catch (Exception e) {
                LOGGER.info("ERROR WHILE READ ACTION LOG FILE - TAI DONG :" + idx + "- " + e);
                System.out.println("ERROR WHILE READ ACTION LOG - TAI DONG :" + idx + "- " + e);
            }
            LOGGER.info("Finish processing execute ActionLog.");
            System.out.println("Finish processing execute ActionLog.");
            //Close the input stream
            br.close();
        } else {
            LOGGER.info("ACTION-LOG FILE NOT EXISTS: " + logFilePath);
            System.out.println("ACTION-LOG FILE NOT EXISTS: " + logFilePath);
        }
    }

}
